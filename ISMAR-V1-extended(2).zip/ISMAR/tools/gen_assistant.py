# -*- coding: utf-8 -*-
import json, sys, re, collections
sys.path.insert(0, '/home/claude/tools')
import gen_assistant_part1 as p1
import gen_assistant_part2 as p2

intents = p1.INTENTS
ids = [i["id"] for i in intents]
assert len(ids) == len(set(ids)), "duplicate ids: %s" % [k for k, v in collections.Counter(ids).items() if v > 1]

allr = []
for it in intents:
    for r in it["responses"]:
        allr.append(r)
uniq = set(allr)
print("intents:", len(intents))
print("responses total:", len(allr), "unique:", len(uniq))
dups = [k for k, v in collections.Counter(allr).items() if v > 1]
print("duplicates:", dups)
cats = collections.Counter()
for it in intents:
    cats[it["category"]] += len(it["responses"])
for c, n in cats.most_common():
    print("  %-28s %d" % (c, n))

# проверка плейсхолдеров
known = {"battery", "time", "date", "weekday", "name", "storage", "network", "charging", "expr", "result"}
for it in intents:
    for r in it["responses"]:
        for ph in re.findall(r"\{(\w+)\}", r):
            assert ph in known, (it["id"], ph)

out = {"version": 1, "intents": intents}
path = "/home/claude/ISMAR/app/src/main/assets/mini_assistant.json"
with open(path, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("written", path)
assert len(uniq) >= 500
