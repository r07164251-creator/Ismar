# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, '/home/claude/tools')
import gen_commands as g

def q(s):
    assert '"' not in s and '$' not in s and '\\' not in s, s
    return '"' + s + '"'

lines = []
lines.append("// ЭТОТ ФАЙЛ СГЕНЕРИРОВАН из tools/gen_commands.py — правьте шаблоны там (или здесь вручную).")
lines.append("package com.ismar.app.commands")
lines.append("")
lines.append("/**")
lines.append(" * Описание команды MINI.")
lines.append(" * Синтаксис шаблона: (а|б|в) — обязательный выбор, [а|б] — необязательная часть, {slot} — захват значения.")
lines.append(" */")
lines.append("class Cmd(val id: String, val cat: String, val title: String, val example: String, val patterns: List<String>)")
lines.append("")
lines.append("object CommandCatalog {")
lines.append("    val all: List<Cmd> = listOf(")
out = []
for (id, cat, title, ex, pats) in g.CMDS:
    body = ",\n".join("            " + q(p) for p in pats)
    out.append("        Cmd(%s, %s, %s, %s, listOf(\n%s\n        ))" % (q(id), q(cat), q(title), q(ex), body))
lines.append(",\n".join(out))
lines.append("    )")
lines.append("")
lines.append("    val categories: List<String> = all.map { it.cat }.distinct()")
lines.append("}")
path = "/home/claude/ISMAR/app/src/main/java/com/ismar/app/commands/CommandCatalog.kt"
open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("written", path, len(g.CMDS), "commands")
