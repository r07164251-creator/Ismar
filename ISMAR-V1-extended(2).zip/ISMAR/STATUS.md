# ISMAR V1 — статус до первой сборки

## Сохранённые исходные модули
- База MINI: `assets/mini_assistant.json` (731 ответ согласно исходному STATUS).
- Каталог команд: исходный `CommandCatalog.kt` (91 команда / 3431 формулировка согласно исходному STATUS).
- Существующие core/system/media/mini/assistant/commands/widgets-файлы сохранены.

## Добавлено в этом проходе
- Overlay: `IslandView`, `BoltView`, `PanelView`, `OverlayController`.
- Service: `OverlayService`, `BootReceiver`; запуск foreground service и реакции на включение/выключение экрана.
- Screens: `MainActivity`, `OnboardingActivity`, `ChatActivity`, `CommandsActivity`, `SettingsActivity`, `WidgetsActivity`, `PermissionActivity`.
- Widgets: `AssistantWidget`, `CommandsWidget`, `VoiceWidget`, `NotesWidget`, `CalcWidget`.
- Добавлены тесты калькулятора и README со сборкой/ограничениями.

## Что ещё обязательно проверить
- Проект пока не прошёл Android Gradle сборку в этой среде: Android SDK и Gradle здесь недоступны. Kotlin compiler без Android SDK не может проверить Android API-типы.
- Запустить GitHub Actions `Build ISMAR APK` и исправить реальные ошибки сборки, если они появятся.
- Проверить на устройстве разрешение overlay, работу окна панели с клавиатурой, автозапуск после перезагрузки, доступ к MediaSession, поведение на Android 14+, поворот экрана и энергосбережение.
- Редактор виджетов поддерживает добавление, удаление, drag-and-drop, изменение размера из доступных пресетов и основные параметры. Тонкая настройка внешнего вида каждого виджета может расширяться отдельно.

Не считать проект финальным до успешной сборки и тестирования на устройстве.
