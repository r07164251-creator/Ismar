package com.ismar.app.core

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

const val MATCH: Int = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP: Int = ViewGroup.LayoutParams.WRAP_CONTENT

object Pal {
    val BG: Int = 0xFF000000.toInt()
    val SURFACE: Int = 0xFF111114.toInt()
    val SURFACE2: Int = 0xFF1A1A1F.toInt()
    val STROKE: Int = 0xFF2A2A31.toInt()
    val TEXT: Int = 0xFFF5F5F7.toInt()
    val TEXT2: Int = 0xFFA1A1AA.toInt()
    val TEXT3: Int = 0xFF6B6B75.toInt()
    val ORANGE: Int = 0xFFFF7A1A.toInt()
    val AMBER: Int = 0xFFFFD21F.toInt()
    val GREEN: Int = 0xFF30D158.toInt()
    val RED: Int = 0xFFFF453A.toInt()
    val BLUE: Int = 0xFF0A84FF.toInt()
    val BONE: Int = 0xFFF2EFE9.toInt()

    val ACCENTS: IntArray = intArrayOf(
        0xFFFF7A1A.toInt(), 0xFF0A84FF.toInt(), 0xFF30D158.toInt(), 0xFFFF5C93.toInt(),
        0xFFBF5AF2.toInt(), 0xFF40C8E0.toInt(), 0xFFFFD21F.toInt(), 0xFFF5F5F7.toInt()
    )
    val ACCENT_NAMES: List<String> = listOf(
        "Оранжевый", "Синий", "Зелёный", "Розовый", "Фиолетовый", "Бирюзовый", "Жёлтый", "Белый"
    )

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val aa = Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k
        val rr = Color.red(a) + (Color.red(b) - Color.red(a)) * k
        val gg = Color.green(a) + (Color.green(b) - Color.green(a)) * k
        val bb = Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k
        return Color.argb(aa.toInt(), rr.toInt(), gg.toInt(), bb.toInt())
    }

    fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
}

object Fonts {
    val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val light: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val bold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)
    val cond: Typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
}

private val mainHandler = Handler(Looper.getMainLooper())

fun runMain(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post { block() }
}

fun toast(ctx: Context, msg: String) {
    runMain { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_SHORT).show() }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun View.dp(v: Int): Int = context.dp(v)
fun View.dpf(v: Float): Float = context.dpf(v)

fun rrect(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.RECTANGLE
    d.cornerRadius = radiusPx
    d.setColor(color)
    if (strokePx > 0) d.setStroke(strokePx, strokeColor)
    return d
}

fun ovalDrawable(color: Int): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.OVAL
    d.setColor(color)
    return d
}

fun Context.tv(s: CharSequence, sp: Float = 14f, color: Int = Pal.TEXT, font: Typeface = Fonts.regular): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    t.typeface = font
    t.includeFontPadding = false
    return t
}

fun Context.vbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    return l
}

fun lin(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(l, t, r, b)
    return p
}

fun frm(w: Int, h: Int, gravity: Int = 0, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): FrameLayout.LayoutParams {
    val p = FrameLayout.LayoutParams(w, h)
    p.gravity = gravity
    p.setMargins(l, t, r, b)
    return p
}

fun View.ripple(radiusPx: Float = 0f) {
    val mask = GradientDrawable()
    mask.setColor(0xFFFFFFFF.toInt())
    mask.cornerRadius = radiusPx
    foreground = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, mask)
}

fun View.onTap(block: () -> Unit) {
    isClickable = true
    setOnClickListener { block() }
}

fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/** Переключатель в стиле ISMAR. */
class ToggleView(ctx: Context) : View(ctx) {
    var on: Boolean = false
        set(v) {
            if (field != v) {
                field = v
                animateTo(if (v) 1f else 0f)
            }
        }
    var onChange: ((Boolean) -> Unit)? = null
    var accent: Int = Pal.ORANGE

    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var anim: ValueAnimator? = null

    init {
        isClickable = true
        setOnClickListener {
            on = !on
            onChange?.invoke(on)
        }
    }

    fun setInstant(v: Boolean) {
        anim?.cancel()
        // обходим setter, чтобы не запускать анимацию
        t = if (v) 1f else 0f
        onSilently(v)
        invalidate()
    }

    private fun onSilently(v: Boolean) {
        val saved = onChange
        onChange = null
        on = v
        anim?.cancel()
        t = if (v) 1f else 0f
        onChange = saved
    }

    private fun animateTo(target: Float) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(t, target)
        a.duration = 160
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(dp(50), dp(30))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = Pal.mix(0xFF3A3A42.toInt(), accent, t)
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        p.color = 0xFFFFFFFF.toInt()
        val pad = dpf(3f)
        val rad = h / 2f - pad
        val cx = lerp(pad + rad, w - pad - rad, t)
        c.drawCircle(cx, h / 2f, rad, p)
    }
}

/** Ползунок-«таблетка» (яркость, прогресс музыки, настройки). */
class PillSlider(ctx: Context, private val thin: Boolean = false) : View(ctx) {
    var progress: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var accent: Int = Pal.ORANGE
    var interactive: Boolean = true
    var onChange: ((Float, Boolean) -> Unit)? = null
    var onRelease: ((Float) -> Unit)? = null

    private var dragging = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onMeasure(w: Int, h: Int) {
        val hh = if (thin) dp(20) else dp(30)
        setMeasuredDimension(MeasureSpec.getSize(w), hh)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val th = if (thin) dpf(4f) else h
        val top = (h - th) / 2f
        p.style = Paint.Style.FILL
        p.color = 0xFF2A2A31.toInt()
        r.set(0f, top, w, top + th)
        c.drawRoundRect(r, th / 2f, th / 2f, p)
        val fillW = (w * progress).coerceAtLeast(if (thin) 0f else th)
        p.color = accent
        r.set(0f, top, fillW, top + th)
        c.drawRoundRect(r, th / 2f, th / 2f, p)
        if (thin && interactive) {
            p.color = 0xFFFFFFFF.toInt()
            c.drawCircle(w * progress, h / 2f, dpf(5f), p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                update(e.x)
            }
            MotionEvent.ACTION_MOVE -> if (dragging) update(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    parent?.requestDisallowInterceptTouchEvent(false)
                    onRelease?.invoke(progress)
                }
            }
        }
        return true
    }

    private fun update(x: Float) {
        val v = if (width <= 0) 0f else (x / width.toFloat()).coerceIn(0f, 1f)
        progress = v
        onChange?.invoke(v, true)
    }
}
