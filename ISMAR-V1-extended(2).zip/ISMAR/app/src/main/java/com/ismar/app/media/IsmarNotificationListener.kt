package com.ismar.app.media

import android.app.Notification
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.ismar.app.core.IslandBus
import com.ismar.app.core.IslandEvent
import com.ismar.app.core.K
import com.ismar.app.core.Prefs
import com.ismar.app.core.runMain
import com.ismar.app.system.SysInfo

/**
 * Нужен для двух вещей:
 *  1) чтение активных медиасессий (Spotify и другие плееры);
 *  2) необязательные баннеры «пришло уведомление» в островке (показываем только название приложения и заголовок).
 */
class IsmarNotificationListener : NotificationListenerService() {
    private val lastByPkg = HashMap<String, Long>()

    override fun onListenerConnected() {
        super.onListenerConnected()
        runMain { MusicMonitor.connect() }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        runMain { MusicMonitor.connect() }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!Prefs.b(K.ISLAND_NOTIFS) || !Prefs.b(K.ISLAND_EVENTS)) return
        val n = sbn.notification ?: return
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val cat = n.category
        if (cat == Notification.CATEGORY_TRANSPORT || cat == Notification.CATEGORY_PROGRESS ||
            cat == Notification.CATEGORY_SERVICE || cat == Notification.CATEGORY_SYSTEM
        ) return
        val now = SystemClock.elapsedRealtime()
        val last = lastByPkg[sbn.packageName] ?: 0L
        if (now - last < 4000L) return
        lastByPkg[sbn.packageName] = now
        val title = n.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val label = SysInfo.appLabel(this, sbn.packageName)
        IslandBus.post(IslandEvent("notif", label, title, 3200L))
    }
}
