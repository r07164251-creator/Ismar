package com.ismar.app.screens

import android.os.Bundle
import android.content.pm.PackageManager
import android.widget.*
import com.ismar.app.core.Perms

class PermissionActivity:android.app.Activity(){
 private var id=0
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);id=intent.getIntExtra("id",0);val perm=intent.getStringExtra("perm")?:run{finish();return};if(checkSelfPermission(perm)==PackageManager.PERMISSION_GRANTED){Perms.deliver(id,true);finish();return};requestPermissions(arrayOf(perm),REQ)}
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==REQ){Perms.deliver(id,grantResults.isNotEmpty()&&grantResults[0]==PackageManager.PERMISSION_GRANTED);finish()}}
 companion object{private const val REQ=77}
}
