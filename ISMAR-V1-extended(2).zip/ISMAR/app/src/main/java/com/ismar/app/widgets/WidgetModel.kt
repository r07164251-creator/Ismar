package com.ismar.app.widgets

import android.content.Context
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.ismar.app.core.Fonts
import com.ismar.app.core.Ic
import com.ismar.app.core.IconView
import com.ismar.app.core.Pal
import com.ismar.app.core.Store
import com.ismar.app.core.WidgetRec
import com.ismar.app.core.WRAP
import com.ismar.app.core.MATCH
import com.ismar.app.core.dp
import com.ismar.app.core.hbox
import com.ismar.app.core.lin
import com.ismar.app.core.ovalDrawable
import com.ismar.app.core.ripple
import com.ismar.app.core.rrect
import com.ismar.app.core.tv
import org.json.JSONObject

/** Настройка виджета: переключатель (choices == null) или выбор из вариантов. */
class Opt(val key: String, val title: String, val choices: List<String>?, val def: Int)

class WidgetType(
    val id: String,
    val title: String,
    val desc: String,
    val icon: Ic,
    val sizes: List<IntArray>,
    val defaultSize: Int,
    val defAccent: Int,
    val options: List<Opt>
)

object WidgetCatalog {
    val common: List<Opt> = listOf(
        Opt("accent", "Цвет акцента", Pal.ACCENT_NAMES, 0),
        Opt("style", "Фон виджета", listOf("Тёмный", "Стекло", "Контур", "Цветной"), 0),
        Opt("title", "Показывать заголовок", null, 1)
    )

    private fun s(vararg wh: Int): List<IntArray> {
        val out = ArrayList<IntArray>()
        var i = 0
        while (i < wh.size) {
            out.add(intArrayOf(wh[i], wh[i + 1]))
            i += 2
        }
        return out
    }

    val all: List<WidgetType> = listOf(
        WidgetType("apps", "Приложения", "Сетка установленных приложений и поиск по ним", Ic.APPS,
            s(2, 1, 2, 2, 2, 3), 1, 1, listOf(Opt("labels", "Подписи под иконками", null, 1))),
        WidgetType("commands", "Команды MINI", "Ввод и быстрый запуск команд, голос", Ic.CMD,
            s(2, 2, 2, 3), 0, 0, emptyList()),
        WidgetType("notes", "Заметки", "Быстрая заметка, сохраняется на телефоне", Ic.NOTE,
            s(1, 1, 2, 1, 2, 2, 2, 3), 2, 6, listOf(Opt("fontsize", "Размер текста", listOf("Мелкий", "Средний", "Крупный"), 1))),
        WidgetType("calc", "Калькулятор", "Простой калькулятор: + − × ÷ %", Ic.CALC,
            s(2, 2, 2, 3), 0, 4, emptyList()),
        WidgetType("battery", "Батарея", "Заряд, состояние и температура", Ic.BATTERY,
            s(1, 1, 2, 1, 2, 2), 0, 2, listOf(Opt("temp", "Показывать температуру", null, 1))),
        WidgetType("brightness", "Яркость", "Ползунок яркости экрана", Ic.SUN,
            s(2, 1, 2, 2), 0, 6, emptyList()),
        WidgetType("music", "Музыка", "Что играет (Spotify и другие) и управление", Ic.MUSIC,
            s(2, 1, 2, 2), 0, 3, emptyList()),
        WidgetType("assistant", "MINI Assistant", "Чат с MINI прямо в панели", Ic.CHAT,
            s(2, 2, 2, 3), 0, 0, emptyList()),
        WidgetType("clock", "Часы", "Цифровые или аналоговые часы с датой", Ic.CLOCK,
            s(1, 1, 2, 1, 2, 2), 1, 7, listOf(
                Opt("h24", "24-часовой формат", null, 1),
                Opt("secs", "Показывать секунды", null, 0),
                Opt("date", "Показывать дату", null, 1),
                Opt("face", "Вид часов", listOf("Цифровые", "Аналоговые"), 0)
            )),
        WidgetType("quick", "Быстрые настройки", "Фонарик, Wi‑Fi, Bluetooth, звук и другое", Ic.SLIDERS,
            s(2, 1, 2, 2), 1, 5, emptyList()),
        WidgetType("voice", "Голосовое управление", "Скажите команду — MINI выполнит", Ic.MIC,
            s(1, 1, 2, 1, 2, 2), 0, 0, emptyList()),
        WidgetType("favorites", "Избранные приложения", "Ваши любимые приложения под рукой", Ic.STAR,
            s(2, 1, 2, 2), 0, 6, emptyList())
    )

    fun type(id: String): WidgetType? {
        for (t in all) if (t.id == id) return t
        return null
    }

    fun newRec(t: WidgetType, pos: Int): WidgetRec {
        val sz = t.sizes[t.defaultSize.coerceIn(0, t.sizes.size - 1)]
        val cfg = JSONObject()
        cfg.put("accent", t.defAccent)
        return WidgetRec(-1L, t.id, sz[0], sz[1], pos, cfg)
    }

    fun create(ctx: Context, rec: WidgetRec, env: WidgetEnv): IsmarWidget {
        return when (rec.type) {
            "apps" -> AppsWidget(ctx, rec, env)
            "commands" -> CommandsWidget(ctx, rec, env)
            "notes" -> NotesWidget(ctx, rec, env)
            "calc" -> CalcWidget(ctx, rec, env)
            "battery" -> BatteryWidget(ctx, rec, env)
            "brightness" -> BrightnessWidget(ctx, rec, env)
            "music" -> MusicWidget(ctx, rec, env)
            "assistant" -> AssistantWidget(ctx, rec, env)
            "clock" -> ClockWidget(ctx, rec, env)
            "quick" -> QuickWidget(ctx, rec, env)
            "voice" -> VoiceWidget(ctx, rec, env)
            "favorites" -> FavoritesWidget(ctx, rec, env)
            else -> ClockWidget(ctx, rec, env)
        }
    }

    /** Первичный набор виджетов (выполняется один раз после первого запуска). */
    fun seedDefaults() {
        val ids = listOf(
            Triple("clock", 2, 1), Triple("battery", 1, 1), Triple("voice", 1, 1),
            Triple("music", 2, 1), Triple("brightness", 2, 1), Triple("quick", 2, 2), Triple("apps", 2, 2)
        )
        var pos = 0
        for ((id, w, h) in ids) {
            val t = type(id) ?: continue
            val r = newRec(t, pos++)
            r.w = w
            r.h = h
            Store.insertWidget(r)
        }
    }
}

/** Что виджету нужно от «хозяина» (панель, редактор, обучение). */
interface WidgetEnv {
    fun saveRec(rec: WidgetRec)
    fun showSheet(title: String, content: View)
    fun hideSheet()
    fun afterLaunch()
    fun openChat()
}

abstract class IsmarWidget(ctx: Context, val rec: WidgetRec, val env: WidgetEnv) : FrameLayout(ctx) {
    protected val padPx: Int = ctx.dp(14)

    protected fun accent(): Int {
        val t = WidgetCatalog.type(rec.type)
        val idx = rec.int("accent", t?.defAccent ?: 0).coerceIn(0, Pal.ACCENTS.size - 1)
        return Pal.ACCENTS[idx]
    }

    protected fun showTitle(): Boolean = rec.bool("title", true)

    /** (Пере)строить содержимое под текущий размер и настройки. */
    abstract fun build()

    open fun onShow() {}
    open fun onHide() {}

    fun resize(w: Int, h: Int) {
        rec.w = w
        rec.h = h
        build()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        onShow()
    }

    override fun onDetachedFromWindow() {
        onHide()
        super.onDetachedFromWindow()
    }

    protected fun small(): Boolean = rec.w <= 1 && rec.h <= 1
    protected fun big(): Boolean = rec.h >= 2

    fun header(title: String, ic: Ic): View? {
        if (!showTitle()) return null
        val row = context.hbox()
        row.gravity = android.view.Gravity.CENTER_VERTICAL
        val i = IconView(context, ic, accent())
        row.addView(i, lin(dp(14), dp(14)))
        val t = context.tv(title.uppercase(), 10.5f, Pal.TEXT2, Fonts.medium)
        t.letterSpacing = 0.08f
        row.addView(t, lin(WRAP, WRAP, 0f, dp(6), 0, 0, 0))
        return row
    }

    protected fun chip(text: String, onClick: () -> Unit): TextView {
        val t = context.tv(text, 12.5f, Pal.TEXT, Fonts.regular)
        t.setPadding(dp(11), dp(7), dp(11), dp(7))
        t.background = rrect(0x1FFFFFFF, dpf(14f), 0x22FFFFFF, 1)
        t.ripple(dpf(14f))
        t.setOnClickListener { onClick() }
        return t
    }

    protected fun roundButton(ic: Ic, sizeDp: Int, fill: Int, tint: Int, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(context)
        f.background = ovalDrawable(fill)
        val i = IconView(context, ic, tint)
        val pad = dp(sizeDp) / 4
        f.addView(i, FrameLayout.LayoutParams(dp(sizeDp) - pad * 2, dp(sizeDp) - pad * 2, android.view.Gravity.CENTER))
        f.ripple(dpf(999f))
        f.setOnClickListener { onClick() }
        return f
    }

    fun dpf(v: Float): Float = context.resources.displayMetrics.density * v

    fun root(): LinearLayout {
        val l = LinearLayout(context)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(padPx, padPx, padPx, padPx)
        return l
    }
}
