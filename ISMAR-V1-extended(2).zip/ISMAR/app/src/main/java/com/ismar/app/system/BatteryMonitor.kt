package com.ismar.app.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.util.concurrent.CopyOnWriteArrayList

class BatteryInfo(
    val level: Int,
    val plugged: Boolean,
    val charging: Boolean,
    val tempC: Float,
    val voltageMv: Int,
    val health: Int,
    val status: Int
) {
    fun statusText(): String = when {
        status == BatteryManager.BATTERY_STATUS_FULL -> "заряжена"
        charging -> "заряжается"
        plugged -> "подключена"
        else -> "от батареи"
    }

    fun healthText(): String = when (health) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "хорошее"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "перегрев"
        BatteryManager.BATTERY_HEALTH_COLD -> "холодная"
        BatteryManager.BATTERY_HEALTH_DEAD -> "изношена"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "перенапряжение"
        else -> "—"
    }
}

object BatteryMonitor {
    interface Listener {
        fun onBattery(info: BatteryInfo)
    }

    private val listeners = CopyOnWriteArrayList<Listener>()
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val info = parse(intent)
            for (l in listeners) l.onBattery(info)
        }
    }

    private fun parse(i: Intent?): BatteryInfo {
        if (i == null) return BatteryInfo(100, false, false, 0f, 0, 0, 0)
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val level = if (lvl < 0 || scale <= 0) 100 else lvl * 100 / scale
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val health = i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)
        return BatteryInfo(level, plugged, charging, temp, volt, health, status)
    }

    /** Читает последнее состояние батареи (sticky-broadcast), ничего не регистрируя. */
    fun read(ctx: Context): BatteryInfo {
        val i = ctx.applicationContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return parse(i)
    }

    fun add(ctx: Context, l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
        if (!registered) {
            SysInfo.register(ctx.applicationContext, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            registered = true
        }
        l.onBattery(read(ctx))
    }

    fun remove(ctx: Context, l: Listener) {
        listeners.remove(l)
        if (listeners.isEmpty() && registered) {
            try {
                ctx.applicationContext.unregisterReceiver(receiver)
            } catch (e: Exception) {
            }
            registered = false
        }
    }
}
