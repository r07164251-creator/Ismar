package com.ismar.app.widgets

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.ismar.app.commands.AppResolver
import com.ismar.app.core.AnalogClockView
import com.ismar.app.core.Fonts
import com.ismar.app.core.Ic
import com.ismar.app.core.IconView
import com.ismar.app.core.dp
import com.ismar.app.core.MATCH
import com.ismar.app.core.Perms
import com.ismar.app.core.PillSlider
import com.ismar.app.core.Pal
import com.ismar.app.core.RingView
import com.ismar.app.core.ToggleView
import com.ismar.app.core.WRAP
import com.ismar.app.core.WidgetRec
import com.ismar.app.core.fmtTime
import com.ismar.app.core.hbox
import com.ismar.app.core.lin
import com.ismar.app.core.ovalDrawable
import com.ismar.app.core.ripple
import com.ismar.app.core.roundedImage
import com.ismar.app.core.rrect
import com.ismar.app.core.toast
import com.ismar.app.core.tv
import com.ismar.app.core.vbox
import com.ismar.app.media.MusicMonitor
import com.ismar.app.media.MusicState
import com.ismar.app.system.BatteryInfo
import com.ismar.app.system.BatteryMonitor
import com.ismar.app.system.Brightness
import com.ismar.app.system.SysInfo
import com.ismar.app.system.Torch

// ======================================================= Часы

class ClockWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : IsmarWidget(ctx, rec, env) {
    private var timeView: TextView? = null
    private var dateView: TextView? = null
    private var analog: AnalogClockView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            update()
            schedule()
        }
    }

    init {
        build()
    }

    override fun build() {
        removeAllViews()
        timeView = null
        dateView = null
        analog = null
        val h24 = rec.bool("h24", true)
        val secs = rec.bool("secs", false)
        val showDate = rec.bool("date", true)
        val analogFace = rec.int("face", 0) == 1
        val col = root()
        if (!small()) {
            val hd = header("Часы", Ic.CLOCK)
            if (hd != null) col.addView(hd, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(4)))
        }
        if (analogFace) {
            val ac = AnalogClockView(context)
            ac.accent = accent()
            ac.seconds = secs
            analog = ac
            val size = if (small()) dp(96) else if (rec.h >= 2) dp(170) else dp(92)
            if (rec.h == 1 && rec.w >= 2) {
                val row = context.hbox()
                row.gravity = Gravity.CENTER_VERTICAL
                row.addView(ac, lin(size, size))
                if (showDate) {
                    val d = context.tv("", 15f, Pal.TEXT2)
                    dateView = d
                    row.addView(d, lin(WRAP, WRAP, 1f, dp(16), 0, 0, 0))
                }
                col.addView(row, lin(MATCH, MATCH))
            } else {
                col.gravity = Gravity.CENTER_HORIZONTAL
                col.addView(ac, lin(size, size))
                if (showDate && !small()) {
                    val d = context.tv("", 14f, Pal.TEXT2)
                    dateView = d
                    col.addView(d, lin(WRAP, WRAP, 0f, 0, dp(8), 0, 0))
                }
            }
        } else {
            val timeSp = if (small()) 30f else if (rec.h >= 2) 64f else 44f
            val t = context.tv("", timeSp, Pal.TEXT, Fonts.light)
            timeView = t
            col.gravity = if (small()) Gravity.CENTER else Gravity.CENTER_VERTICAL
            col.addView(t, lin(WRAP, WRAP))
            if (showDate && !small()) {
                val d = context.tv("", if (rec.h >= 2) 16f else 13.5f, Pal.TEXT2)
                dateView = d
                col.addView(d, lin(WRAP, WRAP, 0f, 0, dp(4), 0, 0))
            }
        }
        addView(col, MATCH, MATCH)
        update()
    }

    private fun update() {
        timeView?.text = SysInfo.timeText(rec.bool("h24", true), rec.bool("secs", false))
        dateView?.text = SysInfo.dateText().replaceFirstChar { it.uppercase() }
        analog?.invalidate()
    }

    private fun schedule() {
        val now = System.currentTimeMillis()
        val delay = if (rec.bool("secs", false)) 1000L - now % 1000L else 60_000L - now % 60_000L
        handler.postDelayed(tick, delay + 20L)
    }

    override fun onShow() {
        handler.removeCallbacks(tick)
        update()
        schedule()
    }

    override fun onHide() {
        handler.removeCallbacks(tick)
    }
}

// ======================================================= Батарея

class BatteryWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : IsmarWidget(ctx, rec, env), BatteryMonitor.Listener {
    private var ring: RingView? = null
    private var bigTv: TextView? = null
    private var l1: TextView? = null
    private var l2: TextView? = null
    private var l3: TextView? = null
    private var last: BatteryInfo? = null

    init {
        build()
    }

    override fun build() {
        removeAllViews()
        val col = root()
        if (!small()) {
            val hd = header("Батарея", Ic.BATTERY)
            if (hd != null) col.addView(hd, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(6)))
        }
        val r = RingView(context)
        ring = r
        bigTv = null
        l1 = null
        l2 = null
        l3 = null
        if (small()) {
            col.addView(r, lin(MATCH, MATCH))
        } else if (rec.h == 1) {
            val row = context.hbox()
            row.gravity = Gravity.CENTER_VERTICAL
            r.strokeDp = 6f
            row.addView(r, lin(dp(78), dp(78)))
            val c = context.vbox()
            val b = context.tv("", 30f, Pal.TEXT, Fonts.light)
            val a = context.tv("", 13f, Pal.TEXT2)
            val t = context.tv("", 12f, Pal.TEXT3)
            bigTv = b; l1 = a; l2 = t
            c.addView(b, lin(WRAP, WRAP))
            c.addView(a, lin(WRAP, WRAP, 0f, 0, dp(2), 0, 0))
            c.addView(t, lin(WRAP, WRAP, 0f, 0, dp(2), 0, 0))
            row.addView(c, lin(WRAP, WRAP, 1f, dp(14), 0, 0, 0))
            col.addView(row, lin(MATCH, MATCH))
        } else {
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.addView(r, lin(dp(120), dp(120)))
            val a = context.tv("", 15f, Pal.TEXT, Fonts.medium)
            val t = context.tv("", 12.5f, Pal.TEXT2)
            val v = context.tv("", 12.5f, Pal.TEXT2)
            l1 = a; l2 = t; l3 = v
            col.addView(a, lin(WRAP, WRAP, 0f, 0, dp(10), 0, 0))
            col.addView(t, lin(WRAP, WRAP, 0f, 0, dp(4), 0, 0))
            col.addView(v, lin(WRAP, WRAP, 0f, 0, dp(2), 0, 0))
        }
        addView(col, MATCH, MATCH)
        val bi = last
        if (bi != null) render(bi)
    }

    override fun onBattery(info: BatteryInfo) {
        last = info
        render(info)
    }

    private fun render(i: BatteryInfo) {
        val r = ring ?: return
        r.progress = i.level / 100f
        r.color = when {
            i.plugged -> Pal.GREEN
            i.level <= 10 -> Pal.RED
            i.level <= 20 -> Pal.AMBER
            else -> accent()
        }
        r.label = i.level.toString() + "%"
        if (small()) r.sub = if (i.plugged) "заряжается" else ""
        bigTv?.text = i.level.toString() + "%"
        val showTemp = rec.bool("temp", true)
        if (rec.h == 1 && rec.w >= 2) {
            l1?.text = i.statusText().replaceFirstChar { it.uppercase() }
            l2?.text = if (showTemp) "Температура " + "%.1f".format(i.tempC) + "°C" else ""
        } else if (rec.h >= 2) {
            r.label = i.level.toString() + "%"
            l1?.text = i.statusText().replaceFirstChar { it.uppercase() }
            l2?.text = (if (showTemp) "Температура " + "%.1f".format(i.tempC) + "°C · " else "") + "Состояние: " + i.healthText()
            l3?.text = "Напряжение " + "%.2f".format(i.voltageMv / 1000f) + " В"
        }
    }

    override fun onShow() {
        BatteryMonitor.add(context, this)
    }

    override fun onHide() {
        BatteryMonitor.remove(context, this)
    }
}

// ======================================================= Яркость

class BrightnessWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : IsmarWidget(ctx, rec, env) {
    private var slider: PillSlider? = null
    private var pct: TextView? = null
    private var permBox: View? = null
    private var ctrlBox: View? = null
    private var lastApply = 0L
    private var autoToggle: ToggleView? = null

    init {
        build()
    }

    override fun build() {
        removeAllViews()
        val col = root()
        val hd = header("Яркость", Ic.SUN)
        if (hd != null) col.addView(hd, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(8)))
        col.gravity = Gravity.CENTER_VERTICAL

        val ctrl = context.vbox()
        val row = context.hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(IconView(context, Ic.SUN, accent()), lin(dp(22), dp(22)))
        val s = PillSlider(context)
        s.accent = accent()
        slider = s
        row.addView(s, lin(0, WRAP, 1f, dp(10), 0, dp(10), 0))
        val p = context.tv("", 13f, Pal.TEXT, Fonts.medium)
        pct = p
        row.addView(p, lin(dp(40), WRAP))
        ctrl.addView(row, lin(MATCH, WRAP))
        s.onChange = { f, user ->
            if (user) {
                p.text = (f * 100).toInt().toString() + "%"
                val now = System.currentTimeMillis()
                if (now - lastApply > 60L) {
                    lastApply = now
                    Brightness.set(context, 1 + (f * 254).toInt())
                }
            }
        }
        s.onRelease = { f -> Brightness.set(context, 1 + (f * 254).toInt()) }

        if (rec.h >= 2) {
            val chips = context.hbox()
            for (v in intArrayOf(25, 50, 75, 100)) {
                val c = chip("$v%") {
                    Brightness.set(context, Math.max(1, v * 255 / 100))
                    syncFromSystem()
                }
                c.gravity = Gravity.CENTER
                chips.addView(c, lin(0, WRAP, 1f, dp(3), 0, dp(3), 0))
            }
            ctrl.addView(chips, lin(MATCH, WRAP, 0f, 0, dp(14), 0, 0))
            val ar = context.hbox()
            ar.gravity = Gravity.CENTER_VERTICAL
            ar.addView(context.tv("Автояркость", 13.5f, Pal.TEXT), lin(0, WRAP, 1f))
            val t = ToggleView(context)
            t.accent = accent()
            autoToggle = t
            t.onChange = { on ->
                if (!Brightness.setAuto(context, on)) toast(context, "Не удалось изменить автояркость")
                syncFromSystem()
            }
            ar.addView(t, lin(WRAP, WRAP))
            ctrl.addView(ar, lin(MATCH, WRAP, 0f, 0, dp(14), 0, 0))
        }
        ctrlBox = ctrl
        col.addView(ctrl, lin(MATCH, WRAP))

        val perm = context.vbox()
        perm.addView(context.tv("Для регулировки яркости Android просит отдельное разрешение «Изменение системных настроек».", 12.5f, Pal.TEXT2), lin(MATCH, WRAP))
        val b = chip("Разрешить") { Perms.openWriteSettings(context) }
        perm.addView(b, lin(WRAP, WRAP, 0f, 0, dp(8), 0, 0))
        permBox = perm
        col.addView(perm, lin(MATCH, WRAP))

        addView(col, MATCH, MATCH)
        syncFromSystem()
    }

    private fun syncFromSystem() {
        val can = Brightness.canWrite(context)
        permBox?.visibility = if (can) View.GONE else View.VISIBLE
        ctrlBox?.visibility = if (can) View.VISIBLE else View.GONE
        val pc = Brightness.percent(context)
        slider?.progress = pc / 100f
        pct?.text = "$pc%"
        autoToggle?.setInstant(Brightness.isAuto(context))
    }

    override fun onShow() {
        syncFromSystem()
    }
}

// ======================================================= Музыка

class MusicWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : IsmarWidget(ctx, rec, env), MusicMonitor.Listener {
    private var art: ImageView? = null
    private var title: TextView? = null
    private var artist: TextView? = null
    private var app: TextView? = null
    private var progress: PillSlider? = null
    private var time: TextView? = null
    private var playIcon: IconView? = null
    private var playerBox: View? = null
    private var emptyBox: View? = null
    private var emptyText: TextView? = null
    private var emptyBtn: TextView? = null
    private var cur: MusicState? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            if (cur?.playing == true) handler.postDelayed(this, 1000L)
        }
    }

    init {
        build()
    }

    private fun controls(playSize: Int): LinearLayout {
        val row = context.hbox()
        row.gravity = Gravity.CENTER
        row.addView(roundButton(Ic.PREV, 34, 0, Pal.TEXT) { MusicMonitor.prev() }, lin(dp(36), dp(36)))
        val play = FrameLayout(context)
        play.background = ovalDrawable(0xFFF5F5F7.toInt())
        val pi = IconView(context, Ic.PLAY, 0xFF000000.toInt())
        playIcon = pi
        play.addView(pi, FrameLayout.LayoutParams(dp(playSize) / 2, dp(playSize) / 2, Gravity.CENTER))
        play.ripple(dpf(999f))
        play.setOnClickListener { MusicMonitor.playPause() }
        row.addView(play, lin(dp(playSize), dp(playSize), 0f, dp(6), 0, dp(6), 0))
        row.addView(roundButton(Ic.NEXT, 34, 0, Pal.TEXT) { MusicMonitor.next() }, lin(dp(36), dp(36)))
        return row
    }

    override fun build() {
        removeAllViews()
        val col = root()
        val hd = header("Музыка", Ic.MUSIC)
        if (hd != null && rec.h >= 2) col.addView(hd, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(8)))

        val player = context.vbox()
        val a = context.roundedImage(14)
        art = a
        val t = context.tv("", if (rec.h >= 2) 16f else 14f, Pal.TEXT, Fonts.medium)
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        val ar = context.tv("", 12.5f, Pal.TEXT2)
        ar.maxLines = 1
        ar.ellipsize = android.text.TextUtils.TruncateAt.END
        val ap = context.tv("", 11f, Pal.TEXT3)
        title = t; artist = ar; app = ap
        val pr = PillSlider(context, true)
        pr.accent = accent()
        progress = pr
        pr.onRelease = { f ->
            val s = cur
            if (s != null && s.durMs > 0L) MusicMonitor.seekTo((f * s.durMs).toLong())
        }
        val tm = context.tv("", 10.5f, Pal.TEXT3)
        time = tm

        if (rec.h >= 2) {
            val top = context.hbox()
            top.gravity = Gravity.CENTER_VERTICAL
            top.addView(a, lin(dp(96), dp(96)))
            val c = context.vbox()
            c.addView(t, lin(MATCH, WRAP))
            c.addView(ar, lin(MATCH, WRAP, 0f, 0, dp(3), 0, 0))
            c.addView(ap, lin(MATCH, WRAP, 0f, 0, dp(3), 0, 0))
            top.addView(c, lin(0, WRAP, 1f, dp(14), 0, 0, 0))
            player.addView(top, lin(MATCH, WRAP))
            player.addView(pr, lin(MATCH, WRAP, 0f, 0, dp(14), 0, 0))
            player.addView(tm, lin(WRAP, WRAP, 0f, 0, 0, 0, dp(2)))
            player.addView(controls(52), lin(MATCH, WRAP, 0f, 0, dp(6), 0, 0))
        } else {
            val top = context.hbox()
            top.gravity = Gravity.CENTER_VERTICAL
            top.addView(a, lin(dp(58), dp(58)))
            val c = context.vbox()
            c.addView(t, lin(MATCH, WRAP))
            c.addView(ar, lin(MATCH, WRAP, 0f, 0, dp(2), 0, 0))
            c.addView(pr, lin(MATCH, WRAP, 0f, 0, dp(4), 0, 0))
            top.addView(c, lin(0, WRAP, 1f, dp(10), 0, dp(6), 0))
            top.addView(controls(38), lin(WRAP, WRAP))
            player.addView(top, lin(MATCH, WRAP))
            col.gravity = Gravity.CENTER_VERTICAL
        }
        playerBox = player
        col.addView(player, lin(MATCH, WRAP))

        val empty = context.vbox()
        empty.gravity = Gravity.CENTER_VERTICAL
        val et = context.tv("", 13f, Pal.TEXT2)
        emptyText = et
        empty.addView(et, lin(MATCH, WRAP))
        val eb = chip("") { }
        emptyBtn = eb
        empty.addView(eb, lin(WRAP, WRAP, 0f, 0, dp(10), 0, 0))
        emptyBox = empty
        col.addView(empty, lin(MATCH, MATCH))

        addView(col, MATCH, MATCH)
        render(cur)
    }

    override fun onMusic(s: MusicState?) {
        cur = s
        render(s)
    }

    private fun render(s: MusicState?) {
        val access = MusicMonitor.access
        if (!access) {
            playerBox?.visibility = View.GONE
            emptyBox?.visibility = View.VISIBLE
            emptyText?.text = "Чтобы видеть музыку Spotify и других плееров, включите для ISMAR «Доступ к уведомлениям»."
            emptyBtn?.text = "Разрешить доступ"
            emptyBtn?.setOnClickListener { Perms.openNotifAccess(context) }
            return
        }
        if (s == null) {
            playerBox?.visibility = View.GONE
            emptyBox?.visibility = View.VISIBLE
            emptyText?.text = "Сейчас ничего не играет."
            emptyBtn?.text = "Открыть Spotify"
            emptyBtn?.setOnClickListener {
                val sp = AppResolver.findAlias(context, "спотифай")
                if (sp != null && AppResolver.launch(context, sp.pkg)) env.afterLaunch()
                else toast(context, "Spotify не установлен — откройте любой плеер")
            }
            return
        }
        emptyBox?.visibility = View.GONE
        playerBox?.visibility = View.VISIBLE
        title?.text = s.title
        artist?.text = if (s.artist.isEmpty()) s.album else s.artist
        app?.text = s.appName
        if (s.art != null) art?.setImageBitmap(s.art) else art?.setImageDrawable(null)
        playIcon?.set(if (s.playing) Ic.PAUSE else Ic.PLAY)
        updateProgress()
        handler.removeCallbacks(tick)
        if (s.playing && isShown) handler.postDelayed(tick, 1000L)
    }

    private fun updateProgress() {
        val s = cur ?: return
        progress?.progress = s.progress()
        time?.text = if (s.durMs > 0L) fmtTime(s.positionNow()) + " / " + fmtTime(s.durMs) else fmtTime(s.positionNow())
    }

    override fun onShow() {
        MusicMonitor.add(context, this)
        MusicMonitor.connect()
    }

    override fun onHide() {
        handler.removeCallbacks(tick)
        MusicMonitor.remove(this)
    }
}

// ======================================================= Быстрые настройки

class QuickWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : IsmarWidget(ctx, rec, env) {
    private var torchCircle: FrameLayout? = null
    private var torchIcon: IconView? = null

    init {
        build()
    }

    private fun openSettings(action: String) {
        val i = Intent(action)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(i)
            env.afterLaunch()
        } catch (e: Exception) {
            toast(context, "Не удалось открыть настройки")
        }
    }

    private fun tile(ic: Ic, label: String, onTap: () -> Unit, isTorch: Boolean = false): View {
        val v = context.vbox()
        v.gravity = Gravity.CENTER
        val circle = FrameLayout(context)
        circle.background = ovalDrawable(0x1FFFFFFF)
        val i = IconView(context, ic, Pal.TEXT)
        circle.addView(i, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        circle.ripple(dpf(999f))
        circle.setOnClickListener { onTap() }
        v.addView(circle, lin(dp(42), dp(42)))
        val t = context.tv(label, 10.5f, Pal.TEXT2)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        v.addView(t, lin(WRAP, WRAP, 0f, 0, dp(5), 0, 0))
        if (isTorch) {
            torchCircle = circle
            torchIcon = i
        }
        return v
    }

    private fun paintTorch() {
        val on = Torch.on
        torchCircle?.background = ovalDrawable(if (on) Pal.AMBER else 0x1FFFFFFF)
        torchIcon?.set(Ic.TORCH, if (on) 0xFF000000.toInt() else Pal.TEXT)
    }

    override fun build() {
        removeAllViews()
        Torch.watch(context)
        val col = root()
        if (rec.h >= 2) {
            val hd = header("Быстрые настройки", Ic.SLIDERS)
            if (hd != null) col.addView(hd, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(10)))
        }
        val tiles = ArrayList<View>()
        tiles.add(tile(Ic.TORCH, "Фонарик", {
            if (!Torch.available(context)) toast(context, "На этом устройстве нет вспышки")
            else if (!Torch.toggle(context)) toast(context, "Не удалось переключить фонарик")
            paintTorch()
        }, true))
        tiles.add(tile(Ic.WIFI, "Wi‑Fi", { openSettings(Settings.ACTION_WIFI_SETTINGS) }))
        tiles.add(tile(Ic.BLUETOOTH, "Bluetooth", { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }))
        tiles.add(tile(Ic.VOLUME, "Звук", { openSettings(Settings.ACTION_SOUND_SETTINGS) }))
        if (rec.h >= 2) {
            tiles.add(tile(Ic.PHONE, "Экран", { openSettings(Settings.ACTION_DISPLAY_SETTINGS) }))
            tiles.add(tile(Ic.STAR, "Авиарежим", { openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }))
            tiles.add(tile(Ic.SEARCH, "Геопозиция", { openSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS) }))
            tiles.add(tile(Ic.BATTERY, "Экономия", { openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS) }))
        }
        col.gravity = Gravity.CENTER_VERTICAL
        var idx = 0
        while (idx < tiles.size) {
            val row = context.hbox()
            for (k in 0 until 4) {
                val t = if (idx + k < tiles.size) tiles[idx + k] else View(context)
                row.addView(t, lin(0, WRAP, 1f))
            }
            col.addView(row, lin(MATCH, WRAP, 0f, 0, if (idx > 0) dp(12) else 0, 0, 0))
            idx += 4
        }
        addView(col, MATCH, MATCH)
        paintTorch()
    }

    override fun onShow() {
        paintTorch()
    }
}
