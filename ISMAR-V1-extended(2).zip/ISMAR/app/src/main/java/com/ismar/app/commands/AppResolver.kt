package com.ismar.app.commands

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import com.ismar.app.assistant.TextNorm
import java.util.concurrent.Executors

class AppInfo(val label: String, val pkg: String, val norm: String)

/** Список установленных приложений, поиск по названию (с алиасами и опечатками), запуск, иконки. */
object AppResolver {
    private var cache: List<AppInfo>? = null
    private var cachedAt = 0L
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val icons = object : LruCache<String, Bitmap>(80) {}

    private val aliases: List<Pair<List<String>, List<String>>> = listOf(
        listOf("ютуб", "youtube", "ютьюб", "ютюб") to listOf("com.google.android.youtube", "app.revanced.android.youtube"),
        listOf("телеграм", "телеграмм", "telegram", "телега", "тг", "телегу") to listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"),
        listOf("ватсап", "вацап", "whatsapp", "вотсап", "ватсапп") to listOf("com.whatsapp", "com.whatsapp.w4b"),
        listOf("инстаграм", "инста", "instagram", "инсту") to listOf("com.instagram.android"),
        listOf("тикток", "tiktok", "тик ток") to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        listOf("вк", "вконтакте", "vk") to listOf("com.vkontakte.android"),
        listOf("спотифай", "spotify", "спотик") to listOf("com.spotify.music"),
        listOf("хром", "chrome", "гугл хром") to listOf("com.android.chrome"),
        listOf("фейсбук", "facebook") to listOf("com.facebook.katana"),
        listOf("твиттер", "twitter") to listOf("com.twitter.android"),
        listOf("дискорд", "discord") to listOf("com.discord"),
        listOf("вайбер", "viber") to listOf("com.viber.voip"),
        listOf("скайп", "skype") to listOf("com.skype.raider"),
        listOf("зум", "zoom") to listOf("us.zoom.videomeetings"),
        listOf("нетфликс", "netflix") to listOf("com.netflix.mediaclient"),
        listOf("твич", "twitch") to listOf("tv.twitch.android.app"),
        listOf("яндекс", "yandex") to listOf("ru.yandex.searchplugin"),
        listOf("яндекс браузер") to listOf("com.yandex.browser"),
        listOf("яндекс карты") to listOf("ru.yandex.yandexmaps"),
        listOf("яндекс музыка") to listOf("ru.yandex.music"),
        listOf("такси", "яндекс такси", "яндекс го") to listOf("ru.yandex.taxi", "ru.yandex.yandexgo"),
        listOf("сбер", "сбербанк") to listOf("ru.sberbankmobile"),
        listOf("тинькофф", "тинькоф", "т банк") to listOf("com.idamob.tinkoff.android", "ru.tinkoff.mb"),
        listOf("озон", "ozon") to listOf("ru.ozon.app.android"),
        listOf("вайлдберриз", "wildberries", "вб") to listOf("com.wildberries.ru"),
        listOf("авито", "avito") to listOf("com.avito.android"),
        listOf("гугл диск", "google drive", "диск") to listOf("com.google.android.apps.docs"),
        listOf("гугл фото", "google photos") to listOf("com.google.android.apps.photos"),
        listOf("заметки", "keep") to listOf("com.google.android.keep"),
        listOf("переводчик", "translate") to listOf("com.google.android.apps.translate"),
        listOf("стим", "steam") to listOf("com.valvesoftware.android.steam.community"),
        listOf("роблокс", "roblox") to listOf("com.roblox.client"),
        listOf("майнкрафт", "minecraft") to listOf("com.mojang.minecraftpe"),
        listOf("бравл старс", "brawl stars") to listOf("com.supercell.brawlstars"),
        listOf("клеш рояль", "clash royale") to listOf("com.supercell.clashroyale"),
        listOf("клеш оф кланс", "clash of clans") to listOf("com.supercell.clashofclans"),
        listOf("пабг", "pubg") to listOf("com.tencent.ig"),
        listOf("геншин", "genshin") to listOf("com.miHoYo.GenshinImpact"),
        listOf("стандофф", "standoff") to listOf("com.axlebolt.standoff2")
    )

    private val translit: Map<Char, String> = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ж' to "zh", 'з' to "z",
        'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p",
        'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "c", 'ч' to "ch",
        'ш' to "sh", 'щ' to "sh", 'ъ' to "", 'ы' to "y", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya"
    )

    fun invalidate() {
        cache = null
    }

    /** Загружает список приложений в фоне (первый вызов может занять заметное время). */
    fun listAsync(ctx: Context, cb: (List<AppInfo>) -> Unit) {
        val app = ctx.applicationContext
        pool.execute {
            val l = list(app)
            main.post { cb(l) }
        }
    }

    @Synchronized
    fun list(ctx: Context): List<AppInfo> {
        val now = System.currentTimeMillis()
        val c = cache
        if (c != null && now - cachedAt < 60_000L) return c
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<AppInfo>()
        val seen = HashSet<String>()
        try {
            for (ri in pm.queryIntentActivities(i, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue
                val label = ri.loadLabel(pm).toString()
                out.add(AppInfo(label, pkg, TextNorm.normalize(label)))
            }
        } catch (e: Exception) {
        }
        out.sortBy { it.label.lowercase() }
        cache = out
        cachedAt = now
        return out
    }

    private fun toLatin(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(translit[ch] ?: ch.toString())
        return sb.toString()
    }

    private fun installed(ctx: Context, pkg: String): AppInfo? {
        for (a in list(ctx)) if (a.pkg == pkg) return a
        return null
    }

    fun findAlias(ctx: Context, name: String): AppInfo? {
        val q = TextNorm.normalize(name)
        for ((names, pkgs) in aliases) {
            if (names.contains(q)) {
                for (p in pkgs) {
                    val a = installed(ctx, p)
                    if (a != null) return a
                }
            }
        }
        return null
    }

    /** Ищет приложение по произнесённому названию. Возвращает null, если такого нет. */
    fun find(ctx: Context, query: String): AppInfo? {
        var q = TextNorm.normalize(query)
        for (w in listOf("приложение ", "программу ", "программа ", "игру ", "игра ", "app ")) {
            if (q.startsWith(w)) q = q.removePrefix(w)
        }
        q = q.trim()
        if (q.isEmpty()) return null
        val alias = findAlias(ctx, q)
        if (alias != null) return alias
        val apps = list(ctx)
        for (a in apps) if (a.norm == q) return a
        for (a in apps) if (a.norm.startsWith(q) || (a.norm.length >= 3 && q.startsWith(a.norm))) return a
        if (q.length >= 3) for (a in apps) if (a.norm.contains(q)) return a
        val ql = toLatin(q)
        var best: AppInfo? = null
        var bestD = 99
        for (a in apps) {
            val al = toLatin(a.norm)
            val limit = if (q.length >= 8) 2 else if (q.length >= 5) 2 else 1
            val d = Math.min(TextNorm.lev(a.norm, q, limit), TextNorm.lev(al, ql, limit))
            if (d <= limit && d < bestD && q.length >= 4) {
                bestD = d
                best = a
            }
        }
        return best
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- иконки ----------

    fun cachedIcon(pkg: String): Bitmap? = icons.get(pkg)

    private fun render(ctx: Context, pkg: String, px: Int): Bitmap? {
        return try {
            val d = ctx.packageManager.getApplicationIcon(pkg)
            val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            d.setBounds(0, 0, px, px)
            d.draw(c)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    /** Загружает иконку в фоне и отдаёт результат в главном потоке. */
    fun loadIcon(ctx: Context, pkg: String, px: Int, cb: (Bitmap?) -> Unit) {
        val hit = icons.get(pkg)
        if (hit != null) {
            cb(hit)
            return
        }
        val app = ctx.applicationContext
        pool.execute {
            val b = render(app, pkg, px)
            if (b != null) icons.put(pkg, b)
            main.post { cb(b) }
        }
    }

    fun isInstalled(ctx: Context, pkg: String): Boolean {
        return try {
            ctx.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }
}
