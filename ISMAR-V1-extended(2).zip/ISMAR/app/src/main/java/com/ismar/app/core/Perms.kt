package com.ismar.app.core

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import com.ismar.app.screens.PermissionActivity

/** Проверка и запрос разрешений. Каждое разрешение запрашивается отдельно и в момент, когда оно нужно. */
object Perms {
    const val MIC = "android.permission.RECORD_AUDIO"
    const val CONTACTS = "android.permission.READ_CONTACTS"
    const val POST_NOTIF = "android.permission.POST_NOTIFICATIONS"

    private val callbacks = HashMap<Int, (Boolean) -> Unit>()
    private var nextId = 1

    fun has(ctx: Context, perm: String): Boolean {
        if (perm == POST_NOTIF && Build.VERSION.SDK_INT < 33) return true
        return ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
    }

    fun overlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun writeSettings(ctx: Context): Boolean = Settings.System.canWrite(ctx)

    fun notifAccess(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(ctx.packageName)
    }

    fun usage(ctx: Context): Boolean {
        return try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    /** Запрос runtime-разрешения через прозрачную PermissionActivity (работает и из службы). */
    fun request(ctx: Context, perm: String, cb: (Boolean) -> Unit) {
        if (has(ctx, perm)) {
            cb(true)
            return
        }
        val id = nextId++
        callbacks[id] = cb
        val i = Intent(ctx, PermissionActivity::class.java)
        i.putExtra("perm", perm)
        i.putExtra("id", id)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            callbacks.remove(id)
            cb(false)
        }
    }

    fun deliver(id: Int, granted: Boolean) {
        val cb = callbacks.remove(id)
        if (cb != null) cb(granted)
    }

    private fun launch(ctx: Context, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openOverlay(ctx: Context): Boolean =
        launch(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))

    fun openNotifAccess(ctx: Context): Boolean =
        launch(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    fun openWriteSettings(ctx: Context): Boolean =
        launch(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))

    fun openUsage(ctx: Context): Boolean =
        launch(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    fun openAppInfo(ctx: Context): Boolean =
        launch(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
}
