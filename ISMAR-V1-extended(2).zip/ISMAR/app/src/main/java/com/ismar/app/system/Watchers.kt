package com.ismar.app.system

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.ismar.app.core.Perms
import com.ismar.app.core.Prefs
import com.ismar.app.core.runMain

/**
 * Необязательный монитор звука. Работает только после разрешения микрофона и включения реакции.
 * Микрофон открывается кратковременно (≈125 мс раз в 2–4 секунды); звук нигде не записывается и не сохраняется —
 * считается только уровень громкости.
 */
class SoundMonitor(private val ctx: Context, private val cb: Callback) {
    interface Callback {
        fun onSpike()
        fun onLoud()
    }

    @Volatile
    private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        if (!Perms.has(ctx, Perms.MIC)) return
        running = true
        val t = Thread { loop() }
        t.isDaemon = true
        t.name = "ismar-sound"
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
    }

    private fun loop() {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) {
            running = false
            return
        }
        val buf = ShortArray(rate / 8)
        var baseline = -55.0
        var loudCount = 0
        while (running) {
            var rec: AudioRecord? = null
            try {
                rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, buf.size * 2)
                )
                if (rec.state == AudioRecord.STATE_INITIALIZED) {
                    rec.startRecording()
                    val n = rec.read(buf, 0, buf.size)
                    rec.stop()
                    if (n > 0) {
                        var sum = 0.0
                        for (i in 0 until n) {
                            val v = buf[i] / 32768.0
                            sum += v * v
                        }
                        val rms = Math.sqrt(sum / n)
                        val db = 20.0 * Math.log10(rms + 1e-9)
                        if (db - baseline > 20.0 && db > -28.0) {
                            runMain { cb.onSpike() }
                        }
                        if (db > -20.0) loudCount++ else loudCount = 0
                        if (loudCount >= 3) {
                            loudCount = 0
                            runMain { cb.onLoud() }
                        }
                        baseline = if (db < baseline + 6.0) baseline * 0.9 + db * 0.1 else baseline + 0.3
                    }
                }
            } catch (e: SecurityException) {
                running = false
            } catch (e: Exception) {
                // игнорируем: попробуем в следующем цикле
            } finally {
                try {
                    rec?.release()
                } catch (e: Exception) {
                }
            }
            try {
                Thread.sleep(if (Prefs.light(ctx)) 4000L else 2000L)
            } catch (e: InterruptedException) {
                running = false
            }
        }
    }
}

/**
 * Определяет приложение на переднем плане через UsageStatsManager.
 * Нужен специальный доступ «Данные об использовании»; без него ничего не делает.
 */
class ForegroundWatcher(private val ctx: Context, private val cb: Callback) {
    interface Callback {
        fun onSwitch(pkg: String, isGame: Boolean)
        fun onStay(pkg: String, stayedMs: Long)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastPkg: String? = null
    private var since = 0L
    private var homePkg: String? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                poll()
            } catch (e: Exception) {
            }
            handler.postDelayed(this, if (Prefs.light(ctx)) 45_000L else 20_000L)
        }
    }

    fun start() {
        if (running) return
        running = true
        homePkg = findHome()
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
    }

    fun reset() {
        lastPkg = null
    }

    private fun findHome(): String? {
        return try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        } catch (e: Exception) {
            null
        }
    }

    private fun poll() {
        if (!Perms.usage(ctx)) return
        val pkg = currentApp() ?: lastPkg ?: return
        val now = SystemClock.elapsedRealtime()
        if (pkg != lastPkg) {
            lastPkg = pkg
            since = now
            cb.onSwitch(pkg, isGame(pkg))
        } else {
            cb.onStay(pkg, now - since)
        }
    }

    @Suppress("DEPRECATION")
    private fun currentApp(): String? {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val ev = usm.queryEvents(end - 120_000L, end) ?: return null
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                val p = e.packageName
                if (p != null && p != ctx.packageName && p != homePkg && p != "com.android.systemui") last = p
            }
        }
        return last
    }

    @Suppress("DEPRECATION")
    private fun isGame(pkg: String): Boolean {
        return try {
            val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
            ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        } catch (e: Exception) {
            false
        }
    }
}
