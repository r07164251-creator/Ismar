package com.ismar.app.screens

import android.app.Activity
import android.view.Gravity
import android.widget.*
import com.ismar.app.core.*

open class IsmarActivity:Activity(){
 protected fun page(title:String):LinearLayout{val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));setBackgroundColor(Pal.BG)};val bar=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};val t=this@IsmarActivity.tv(title,23f,Pal.TEXT,Fonts.bold);bar.addView(t,LinearLayout.LayoutParams(0,WRAP,1f));val back=this@IsmarActivity.tv("‹",30f,Pal.TEXT);back.setOnClickListener{finish()};bar.addView(back);root.addView(bar,LinearLayout.LayoutParams(MATCH,dp(48)));return root}
 protected fun label(s:CharSequence,size:Float=14f,color:Int=Pal.TEXT,font:android.graphics.Typeface=Fonts.regular)=this.tv(s,size,color,font)
 protected fun button(text:String,click:()->Unit)=label(text,14f,Pal.TEXT,Fonts.medium).apply{gravity=Gravity.CENTER;setPadding(dp(14),dp(13),dp(14),dp(13));background=rrect(0xFF202026.toInt(),dpf(15f));setOnClickListener{click()}}
 protected fun addButton(root:LinearLayout,text:String,click:()->Unit){root.addView(button(text,click),LinearLayout.LayoutParams(MATCH,dp(48)).apply{topMargin=dp(9)})}
}
