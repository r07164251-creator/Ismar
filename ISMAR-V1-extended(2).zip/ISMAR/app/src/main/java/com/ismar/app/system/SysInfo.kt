package com.ismar.app.system

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SysInfo {
    private val ru: Locale = Locale.forLanguageTag("ru")

    /** Регистрация приёмника системных рассылок (с учётом требований Android 13+). */
    fun register(ctx: Context, r: BroadcastReceiver, f: IntentFilter) {
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            ctx.registerReceiver(r, f)
        }
    }

    fun timeText(is24: Boolean = true, seconds: Boolean = false): String {
        val pattern = if (is24) {
            if (seconds) "HH:mm:ss" else "HH:mm"
        } else {
            if (seconds) "h:mm:ss a" else "h:mm a"
        }
        return SimpleDateFormat(pattern, ru).format(Date())
    }

    fun dateText(): String = SimpleDateFormat("EEEE, d MMMM", ru).format(Date())

    fun dateLong(): String = SimpleDateFormat("EEEE, d MMMM yyyy", ru).format(Date())

    fun weekday(): String = SimpleDateFormat("EEEE", ru).format(Date())

    private fun gb(bytes: Long): String = "%.1f".format(bytes / 1073741824.0)

    fun storageText(): String {
        return try {
            val st = StatFs(Environment.getDataDirectory().path)
            "свободно " + gb(st.availableBytes) + " из " + gb(st.totalBytes) + " ГБ"
        } catch (e: Exception) {
            "память: нет данных"
        }
    }

    fun storageFreeShort(): String {
        return try {
            val st = StatFs(Environment.getDataDirectory().path)
            gb(st.availableBytes) + " ГБ свободно"
        } catch (e: Exception) {
            "—"
        }
    }

    fun ramPercent(ctx: Context): Int {
        return try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            if (mi.totalMem <= 0L) 0 else (100L - mi.availMem * 100L / mi.totalMem).toInt()
        } catch (e: Exception) {
            0
        }
    }

    fun network(ctx: Context): String {
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork
            if (n == null) return "нет сети"
            val caps = cm.getNetworkCapabilities(n)
            if (caps == null) return "нет сети"
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi‑Fi"
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "мобильная сеть"
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet"
            return "есть сеть"
        } catch (e: Exception) {
            return "неизвестно"
        }
    }

    fun hasInternet(ctx: Context): Boolean {
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(n) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            return false
        }
    }

    /** Короткая строка состояния для островка. */
    fun stateLine(ctx: Context): String {
        val b = BatteryMonitor.read(ctx)
        return storageFreeShort() + " · ОЗУ " + ramPercent(ctx) + "% · " + network(ctx) + " · " + "%.0f".format(b.tempC) + "°C"
    }

    /** Подробный отчёт для команды «состояние телефона». */
    fun report(ctx: Context): String {
        val b = BatteryMonitor.read(ctx)
        val sb = StringBuilder()
        sb.append("Батарея: ").append(b.level).append("% (").append(b.statusText()).append(")\n")
        sb.append("Температура батареи: ").append("%.1f".format(b.tempC)).append("°C\n")
        sb.append("ОЗУ занято: ").append(ramPercent(ctx)).append("%\n")
        sb.append("Память: ").append(storageText()).append("\n")
        sb.append("Сеть: ").append(network(ctx))
        return sb.toString()
    }

    fun appLabel(ctx: Context, pkg: String): String {
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            pkg
        } catch (e: Exception) {
            pkg
        }
    }
}
