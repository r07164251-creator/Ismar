package com.ismar.app.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.ismar.app.core.*
import com.ismar.app.mini.MiniView
import com.ismar.app.media.MusicMonitor
import com.ismar.app.system.BatteryMonitor

class IslandView(ctx: Context, private val onExpand: () -> Unit) : FrameLayout(ctx) {
    private val title = TextView(ctx)
    private val sub = TextView(ctx)
    private val mini = MiniView(ctx, true)
    init {
        background = GradientDrawable().apply { setColor(0xFF050506.toInt()); cornerRadius = ctx.dp(28).toFloat(); setStroke(ctx.dp(1),0xFF25252A.toInt()) }
        elevation = ctx.dpf(12f)
        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL; setPadding(ctx.dp(12),ctx.dp(7),ctx.dp(14),ctx.dp(7)) }
        row.addView(mini, LinearLayout.LayoutParams(ctx.dp(34),ctx.dp(34)))
        val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        title.setTextColor(Color.WHITE); title.textSize=12f; title.typeface=Fonts.medium; title.text="ISMAR"
        sub.setTextColor(0xFFAAAAAF.toInt()); sub.textSize=10f; sub.text="MINI готов к работе"
        texts.addView(title); texts.addView(sub)
        row.addView(texts,LinearLayout.LayoutParams(0,WRAP,1f))
        addView(row,LayoutParams(MATCH,WRAP))
        setOnClickListener { onExpand() }
        refresh()
    }
    fun refresh() {
        val b=BatteryMonitor.read(context)
        val m=MusicMonitor.state
        if (m != null && m.title.isNotBlank()) { title.text=m.title; sub.text=m.artist }
        else { title.text="ISMAR"; sub.text="${b.level}% · ${b.statusText()}" }
    }
}
