package com.ismar.app.widgets

import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import com.ismar.app.assistant.TextNorm
import com.ismar.app.commands.AppInfo
import com.ismar.app.commands.AppResolver
import com.ismar.app.core.Fonts
import com.ismar.app.core.Ic
import com.ismar.app.core.IconView
import com.ismar.app.core.dp
import com.ismar.app.core.MATCH
import com.ismar.app.core.Pal
import com.ismar.app.core.WRAP
import com.ismar.app.core.WidgetRec
import com.ismar.app.core.hbox
import com.ismar.app.core.lin
import com.ismar.app.core.ovalDrawable
import com.ismar.app.core.ripple
import com.ismar.app.core.rrect
import com.ismar.app.core.toast
import com.ismar.app.core.tv
import com.ismar.app.core.vbox
import org.json.JSONArray

/** Список приложений с поиском. multi = true — режим выбора нескольких (избранное). */
class AppPickerView(
    ctx: Context,
    private val multi: Boolean,
    private val selected: MutableSet<String>,
    private val onPick: (AppInfo, Boolean) -> Unit
) : LinearLayout(ctx) {
    private val listBox = LinearLayout(ctx)
    private val search = EditText(ctx)
    private var apps: List<AppInfo> = emptyList()

    init {
        orientation = VERTICAL
        search.hint = "Поиск приложения"
        search.setHintTextColor(Pal.TEXT3)
        search.setTextColor(Pal.TEXT)
        search.textSize = 15f
        search.isSingleLine = true
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.background = rrect(0xFF1A1A1F.toInt(), dpf(14f))
        search.setPadding(dp(14), dp(11), dp(14), dp(11))
        addView(search, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(10)))
        listBox.orientation = VERTICAL
        addView(listBox, lin(MATCH, WRAP))
        listBox.addView(context.tv("Загрузка списка приложений…", 13f, Pal.TEXT2))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                rebuild(s?.toString() ?: "")
            }
        })
        AppResolver.listAsync(context) { l ->
            apps = l
            rebuild("")
        }
    }

    private fun dpf(v: Float): Float = context.resources.displayMetrics.density * v

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density + 0.5f).toInt()

    private fun rebuild(query: String) {
        listBox.removeAllViews()
        val q = TextNorm.normalize(query)
        var n = 0
        for (a in apps) {
            if (q.isNotEmpty() && !a.norm.contains(q)) continue
            listBox.addView(row(a))
            n++
            if (n >= 400) break
        }
        if (n == 0) listBox.addView(context.tv("Ничего не найдено", 13f, Pal.TEXT2))
    }

    private fun row(a: AppInfo): View {
        val r = context.hbox()
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(4), dp(8), dp(4), dp(8))
        val iv = ImageView(context)
        iv.tag = a.pkg
        r.addView(iv, lin(dp(40), dp(40)))
        val cached = AppResolver.cachedIcon(a.pkg)
        if (cached != null) iv.setImageBitmap(cached)
        else AppResolver.loadIcon(context, a.pkg, 96) { b -> if (iv.tag == a.pkg && b != null) iv.setImageBitmap(b) }
        val t = context.tv(a.label, 15f, Pal.TEXT)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        r.addView(t, lin(0, WRAP, 1f, dp(14), 0, dp(8), 0))
        val check = IconView(context, Ic.CHECK, Pal.ORANGE)
        check.visibility = if (multi && selected.contains(a.pkg)) View.VISIBLE else View.INVISIBLE
        if (multi) r.addView(check, lin(dp(20), dp(20)))
        r.ripple(dpf(12f))
        r.setOnClickListener {
            if (multi) {
                val now = !selected.contains(a.pkg)
                if (now) selected.add(a.pkg) else selected.remove(a.pkg)
                check.visibility = if (now) View.VISIBLE else View.INVISIBLE
                onPick(a, now)
            } else {
                onPick(a, true)
            }
        }
        return r
    }
}

abstract class AppGridWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : IsmarWidget(ctx, rec, env) {
    protected fun readList(key: String): MutableList<String> {
        val out = ArrayList<String>()
        val arr = rec.cfg.optJSONArray(key) ?: return out
        for (i in 0 until arr.length()) out.add(arr.optString(i))
        return out
    }

    protected fun writeList(key: String, list: List<String>) {
        val arr = JSONArray()
        for (s in list) arr.put(s)
        rec.cfg.put(key, arr)
        env.saveRec(rec)
    }

    protected fun launchApp(pkg: String): Boolean {
        val ok = AppResolver.launch(context, pkg)
        if (ok) env.afterLaunch() else toast(context, "Не удалось открыть приложение")
        return ok
    }

    protected fun appCell(app: AppInfo, showLabel: Boolean, onClick: () -> Unit, onLong: (() -> Unit)?): View {
        val v = context.vbox()
        v.gravity = Gravity.CENTER
        v.setPadding(dp(2), dp(4), dp(2), dp(4))
        val iv = ImageView(context)
        iv.tag = app.pkg
        v.addView(iv, lin(dp(44), dp(44)))
        val cached = AppResolver.cachedIcon(app.pkg)
        if (cached != null) iv.setImageBitmap(cached)
        else AppResolver.loadIcon(context, app.pkg, 112) { b -> if (iv.tag == app.pkg && b != null) iv.setImageBitmap(b) }
        if (showLabel) {
            val t = context.tv(app.label, 10f, Pal.TEXT2)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            v.addView(t, lin(MATCH, WRAP, 0f, 0, dp(4), 0, 0))
        }
        v.ripple(dpf(12f))
        v.setOnClickListener { onClick() }
        if (onLong != null) v.setOnLongClickListener {
            onLong()
            true
        }
        return v
    }

    protected fun specialCell(ic: Ic, label: String, showLabel: Boolean, onClick: () -> Unit): View {
        val v = context.vbox()
        v.gravity = Gravity.CENTER
        v.setPadding(dp(2), dp(4), dp(2), dp(4))
        val f = FrameLayout(context)
        f.background = ovalDrawable(0x1FFFFFFF)
        f.addView(IconView(context, ic, accent()), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        v.addView(f, lin(dp(44), dp(44)))
        if (showLabel) {
            val t = context.tv(label, 10f, Pal.TEXT2)
            t.maxLines = 1
            t.gravity = Gravity.CENTER
            v.addView(t, lin(MATCH, WRAP, 0f, 0, dp(4), 0, 0))
        }
        v.ripple(dpf(12f))
        v.setOnClickListener { onClick() }
        return v
    }

    protected fun fillGrid(col: LinearLayout, cells: List<View>, perRow: Int) {
        var i = 0
        while (i < cells.size) {
            val row = context.hbox()
            for (k in 0 until perRow) {
                val c = if (i + k < cells.size) cells[i + k] else View(context)
                row.addView(c, lin(0, WRAP, 1f))
            }
            col.addView(row, lin(MATCH, WRAP, 0f, 0, if (i > 0) dp(6) else 0, 0, 0))
            i += perRow
        }
    }
}

// ======================================================= Приложения

class AppsWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : AppGridWidget(ctx, rec, env) {
    init {
        build()
    }

    override fun build() {
        removeAllViews()
        val col = root()
        if (rec.h >= 2) {
            val hd = header("Приложения", Ic.APPS)
            if (hd != null) col.addView(hd, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(8)))
        }
        col.gravity = Gravity.CENTER_VERTICAL
        val holder = context.vbox()
        col.addView(holder, lin(MATCH, WRAP))
        addView(col, MATCH, MATCH)
        AppResolver.listAsync(context) { all -> fill(holder, all) }
    }

    private fun fill(holder: LinearLayout, all: List<AppInfo>) {
        holder.removeAllViews()
        val perRow = 4
        val rows = if (rec.h >= 3) 3 else if (rec.h == 2) 2 else 1
        val capacity = perRow * rows
        val recents = readList("recent")
        val ordered = ArrayList<AppInfo>()
        for (p in recents) for (a in all) if (a.pkg == p) ordered.add(a)
        for (a in all) if (!recents.contains(a.pkg)) ordered.add(a)
        val showLabels = rec.bool("labels", true) && rows > 1
        val cells = ArrayList<View>()
        val take = Math.min(capacity - 1, ordered.size)
        for (i in 0 until take) {
            val a = ordered[i]
            cells.add(appCell(a, showLabels, {
                if (launchApp(a.pkg)) {
                    val l = readList("recent")
                    l.remove(a.pkg)
                    l.add(0, a.pkg)
                    writeList("recent", l.take(12))
                }
            }, null))
        }
        cells.add(specialCell(Ic.SEARCH, "Все", showLabels) {
            val picker = AppPickerView(context, false, HashSet()) { a, _ ->
                env.hideSheet()
                launchApp(a.pkg)
            }
            env.showSheet("Все приложения", picker)
        })
        fillGrid(holder, cells, perRow)
    }
}

// ======================================================= Избранные приложения

class FavoritesWidget(ctx: Context, rec: WidgetRec, env: WidgetEnv) : AppGridWidget(ctx, rec, env) {
    init {
        build()
    }

    override fun build() {
        removeAllViews()
        val col = root()
        if (rec.h >= 2) {
            val hd = header("Избранное", Ic.STAR)
            if (hd != null) col.addView(hd, lin(MATCH, WRAP, 0f, 0, 0, 0, dp(8)))
        }
        col.gravity = Gravity.CENTER_VERTICAL
        val holder = context.vbox()
        col.addView(holder, lin(MATCH, WRAP))
        addView(col, MATCH, MATCH)
        AppResolver.listAsync(context) { all -> fill(holder, all) }
    }

    private fun openPicker() {
        val sel = HashSet<String>(readList("pkgs"))
        val picker = AppPickerView(context, true, sel) { _, _ ->
            val ordered = ArrayList<String>()
            for (p in readList("pkgs")) if (sel.contains(p)) ordered.add(p)
            for (p in sel) if (!ordered.contains(p)) ordered.add(p)
            writeList("pkgs", ordered.take(8))
            build()
        }
        env.showSheet("Избранные приложения (до 8)", picker)
    }

    private fun fill(holder: LinearLayout, all: List<AppInfo>) {
        holder.removeAllViews()
        val pkgs = readList("pkgs")
        val apps = ArrayList<AppInfo>()
        for (p in pkgs) for (a in all) if (a.pkg == p) apps.add(a)
        if (apps.isEmpty()) {
            holder.addView(context.tv("Выберите приложения, которые нужны чаще всего.", 13f, Pal.TEXT2), lin(MATCH, WRAP))
            holder.addView(chip("Выбрать приложения") { openPicker() }, lin(WRAP, WRAP, 0f, 0, dp(10), 0, 0))
            return
        }
        val rows = if (rec.h >= 2) 2 else 1
        val perRow = 4
        val showLabels = rows > 1
        val cells = ArrayList<View>()
        for (a in apps.take(perRow * rows - 1)) {
            cells.add(appCell(a, showLabels, { launchApp(a.pkg) }, {
                val l = readList("pkgs")
                l.remove(a.pkg)
                writeList("pkgs", l)
                toast(context, "Убрано из избранного: " + a.label)
                build()
            }))
        }
        cells.add(specialCell(Ic.PLUS, "Ещё", showLabels) { openPicker() })
        fillGrid(holder, cells, perRow)
    }
}
