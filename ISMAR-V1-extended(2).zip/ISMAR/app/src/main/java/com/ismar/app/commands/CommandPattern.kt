package com.ismar.app.commands

/**
 * Мини-язык шаблонов команд. Чистый Kotlin.
 *   (а|б|в)  — обязательная альтернатива
 *   [а|б]    — необязательная часть
 *   {slot}   — захват значения ({n} — число, {tel} — номер телефона, остальное — любой текст)
 */
object CommandPattern {
    private class Parser(val s: String) {
        var pos = 0

        private fun product(a: List<String>, b: List<String>): List<String> {
            val out = ArrayList<String>(a.size * b.size)
            for (x in a) for (y in b) out.add(x + y)
            return out
        }

        fun parse(closing: Char?): List<String> {
            val all = ArrayList<String>()
            var cur: List<String> = listOf("")
            loop@ while (pos < s.length) {
                val c = s[pos]
                when {
                    c == '|' -> {
                        all.addAll(cur)
                        cur = listOf("")
                        pos++
                    }
                    closing != null && c == closing -> break@loop
                    c == '(' -> {
                        pos++
                        val inner = parse(')')
                        pos++
                        cur = product(cur, inner)
                    }
                    c == '[' -> {
                        pos++
                        val inner = parse(']')
                        pos++
                        cur = product(cur, inner + "")
                    }
                    else -> {
                        val st = pos
                        while (pos < s.length && "|()[]".indexOf(s[pos]) < 0) pos++
                        cur = product(cur, listOf(s.substring(st, pos)))
                    }
                }
            }
            all.addAll(cur)
            return all
        }
    }

    private val spacesRe = Regex("\\s+")
    private val slotRe = Regex("\\{(\\w+)\\}")
    private val junkRe = Regex("[^\\p{L}\\p{N}_\\s%+@._:/-]")

    /** Раскрывает шаблон во все конкретные формулировки. */
    fun expand(pattern: String): List<String> {
        val res = Parser(pattern).parse(null)
        val seen = LinkedHashSet<String>()
        for (v in res) {
            val t = spacesRe.replace(v, " ").trim()
            if (t.isNotEmpty()) seen.add(t)
        }
        return ArrayList(seen)
    }

    class Compiled(val regex: Regex, val slots: List<String>, val literalLen: Int, val order: Int)

    private fun slotRegex(name: String): String = when (name) {
        "n" -> "(\\d{1,3})"
        "tel" -> "(\\+?\\d[\\d ]{3,})"
        else -> "(.+?)"
    }

    fun compile(order: Int, variant: String): Compiled {
        val sb = StringBuilder("^")
        val slots = ArrayList<String>()
        var lit = 0
        var last = 0
        for (m in slotRe.findAll(variant)) {
            val l = variant.substring(last, m.range.first)
            sb.append(Regex.escape(l))
            lit += l.length
            slots.add(m.groupValues[1])
            sb.append(slotRegex(m.groupValues[1]))
            last = m.range.last + 1
        }
        val t = variant.substring(last)
        sb.append(Regex.escape(t))
        lit += t.length
        sb.append("\$")
        return Compiled(Regex(sb.toString()), slots, lit, order)
    }

    private val fill = setOf("пожалуйста", "плиз", "pls", "please", "мини", "mini", "ну", "эй", "слушай", "пжлст")
    private val lead = setOf("а", "и", "можешь", "можно", "сможешь")

    /** Приводит произнесённую/набранную фразу к виду, в котором её ждут шаблоны. */
    fun normalizeInput(raw: String): String {
        var s = raw.lowercase().replace('ё', 'е')
        s = s.replace("настройки мини", "настройки ismar").replace("настройки mini", "настройки ismar")
        s = s.replace("%", " % ")
        s = junkRe.replace(s, " ")
        s = spacesRe.replace(s, " ").trim()
        var toks = s.split(' ')
            .map { it.trim('.', ',', ':', '-', '_', '/') }
            .filter { it.isNotEmpty() }
            .filter { !fill.contains(it) }
        while (toks.isNotEmpty() &&
            (lead.contains(toks[0]) || (toks[0] == "ты" && toks.size > 1 && (toks[1] == "можешь" || toks[1] == "сможешь")))
        ) {
            toks = toks.drop(1)
        }
        return toks.joinToString(" ")
    }
}
