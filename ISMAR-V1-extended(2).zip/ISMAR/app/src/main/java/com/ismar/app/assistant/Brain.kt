package com.ismar.app.assistant

import android.content.Context
import com.ismar.app.core.K
import com.ismar.app.core.Prefs
import com.ismar.app.system.BatteryMonitor
import com.ismar.app.system.SysInfo

/** Android-обвязка для MiniBrain: загрузка базы ответов из assets и подстановка данных телефона. */
object Brain {
    private var brain: MiniBrain? = null

    private class Env(private val ctx: Context) : BrainEnv {
        override fun value(key: String): String? {
            return when (key) {
                "battery" -> BatteryMonitor.read(ctx).level.toString() + "%"
                "charging" -> if (BatteryMonitor.read(ctx).plugged) "заряжаюсь" else "работаю от батареи"
                "time" -> SysInfo.timeText()
                "date" -> SysInfo.dateText()
                "weekday" -> SysInfo.weekday()
                "name" -> Prefs.s(K.USER_NAME)
                "storage" -> SysInfo.storageText()
                "network" -> SysInfo.network(ctx)
                else -> null
            }
        }

        override fun saveName(name: String) {
            Prefs.setS(K.USER_NAME, name)
        }
    }

    @Synchronized
    fun get(ctx: Context): MiniBrain {
        val b = brain
        if (b != null) return b
        val app = ctx.applicationContext
        val json = app.assets.open("mini_assistant.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val nb = MiniBrain(MiniBrain.parse(json), Env(app))
        brain = nb
        return nb
    }
}
