package com.ismar.app.assistant

import org.json.JSONObject
import java.util.ArrayDeque

class Trigger(val tokens: List<String>, val prefix: BooleanArray, val points: Int) {
    companion object {
        fun parse(raw: String): Trigger {
            val parts = raw.trim().split(" ").filter { it.isNotEmpty() }
            val toks = ArrayList<String>()
            val pre = BooleanArray(parts.size)
            var pts = 0
            for ((i, p) in parts.withIndex()) {
                pre[i] = p.endsWith("*")
                val w = TextNorm.normalize(p.trimEnd('*'))
                toks.add(w)
                pts += w.length
            }
            pts += parts.size * 3
            return Trigger(toks, pre, pts)
        }
    }
}

class BrainIntent(
    val id: String,
    val category: String,
    val emotion: String,
    val priority: Int,
    val triggers: List<Trigger>,
    val responses: List<String>
)

class BrainReply(val text: String, val emotion: String, val intentId: String)

/** Источник значений для подстановок {battery}, {time}... и хранилище имени пользователя. */
interface BrainEnv {
    fun value(key: String): String?
    fun saveName(name: String)
}

/**
 * Локальный «разговорный движок» MINI. Без нейросети и интернета:
 * интенты с триггерами + база готовых ответов + контекст последних сообщений.
 * Чистый Kotlin (кроме org.json), поэтому покрыт юнит-тестами.
 */
class MiniBrain(private val intents: List<BrainIntent>, private val env: BrainEnv) {
    private class Match(val intent: BrainIntent, val score: Int, val start: Int, val end: Int)
    private class Turn(val norm: String, val intentId: String)

    private class Bag(val size: Int) {
        private var order = IntArray(0)
        private var pos = 0
        private var lastIdx = -1

        fun next(): Int {
            if (pos >= order.size) {
                val l = ArrayList<Int>()
                for (i in 0 until size) l.add(i)
                l.shuffle()
                if (size > 1 && l[0] == lastIdx) {
                    val t = l[0]; l[0] = l[l.size - 1]; l[l.size - 1] = t
                }
                order = l.toIntArray()
                pos = 0
            }
            lastIdx = order[pos]
            pos++
            return lastIdx
        }
    }

    private val byId = HashMap<String, BrainIntent>()
    private val bags = HashMap<String, Bag>()
    private val recent = ArrayDeque<String>()
    private val history = ArrayList<Turn>()
    private var repeatCount = 0
    private var lastFallbackUnknown = false

    private val supportIds = setOf("user_sad", "user_anxious", "user_tired", "user_angry", "support", "motivate")
    private val repeatable = setOf("joke", "fact", "random_phrase", "music_ask", "music_talk", "games_ask", "weather_talk", "user_bored")
    private val socialIds = setOf("greet_hello", "greet_morning", "greet_evening", "thanks", "compliment")
    private val nameRe = Regex("^(?:меня зовут|мое имя|зови меня|называй меня)\\s+(\\p{L}+)")

    init {
        for (i in intents) byId[i.id] = i
    }

    fun intentCount(): Int = intents.size

    fun responseCount(): Int {
        val all = HashSet<String>()
        for (i in intents) all.addAll(i.responses)
        return all.size
    }

    fun categoryCounts(): Map<String, Int> {
        val m = LinkedHashMap<String, Int>()
        for (i in intents) m[i.category] = (m[i.category] ?: 0) + i.responses.size
        return m
    }

    fun hasIntent(id: String): Boolean = byId.containsKey(id)

    /** Принудительный ответ из конкретного интента (для команд «расскажи шутку» и т.п.). */
    fun forced(id: String): BrainReply = pick(id, null)

    fun reply(raw: String): BrainReply {
        var norm = TextNorm.normalize(raw)
        if (norm.isEmpty()) return finish(norm, pickFallback())

        // повтор одного и того же сообщения
        val last = if (history.isEmpty()) null else history[history.size - 1]
        if (last != null && last.norm == norm) repeatCount++ else repeatCount = 0
        if (repeatCount >= 1) {
            val id = if (repeatCount == 1) "repeat_1" else if (repeatCount == 2) "repeat_2" else "repeat_3"
            return finish(norm, pick(id, null))
        }

        // имя пользователя
        val nm = nameRe.find(norm)
        if (nm != null) {
            val n = nm.groupValues[1].replaceFirstChar { it.uppercase() }
            env.saveName(n)
            return finish(norm, pick("name_set", mapOf("name" to n)))
        }

        // арифметика
        val math = Calc.fromText(raw)
        if (math != null) {
            val ex = math.first
            val res = Calc.format(math.second)
            return finish(norm, pick("math", mapOf("expr" to ex, "result" to res)))
        }

        var tokens = TextNorm.tokens(norm)
        var best = bestMatch(tokens, BooleanArray(tokens.size))
        if (best == null && TextNorm.looksLikeWrongLayout(raw)) {
            val fixed = TextNorm.normalize(TextNorm.fixLayout(raw))
            val t2 = TextNorm.tokens(fixed)
            val b2 = bestMatch(t2, BooleanArray(t2.size))
            if (b2 != null) {
                tokens = t2
                best = b2
                norm = fixed
            }
        }

        if (best == null) return finish(norm, pickFallback())

        var id = best.intent.id
        val lastId = lastRealIntent()

        // контекстные правила
        if (id == "more_generic" && lastId != null && repeatable.contains(lastId)) id = lastId
        if (id == "thanks" && wasRecentlySupport()) id = "thanks_after_support"
        if (id == "followup_you" && tokens.size > 5) return finish(norm, pickFallback())
        if (id == "name_ask" && env.value("name").isNullOrEmpty()) id = "name_unknown"

        var reply = pick(id, null)

        // «Привет, как дела?» — отвечаем на обе части
        run {
            val used = BooleanArray(tokens.size)
            for (k in best.start until best.end) used[k] = true
            val second = bestMatch(tokens, used)
            if (second != null && second.intent.id != best.intent.id && second.score >= 8 &&
                (socialIds.contains(best.intent.id) || socialIds.contains(second.intent.id))
            ) {
                val r2 = pick(second.intent.id, null)
                val first = if (best.start <= second.start) reply else r2
                val secondR = if (best.start <= second.start) r2 else reply
                reply = BrainReply(first.text + " " + secondR.text, secondR.emotion, secondR.intentId)
                return finish(norm, reply)
            }
        }
        return finish(norm, reply)
    }

    // ---------- внутренности ----------

    private fun finish(norm: String, r: BrainReply): BrainReply {
        history.add(Turn(norm, r.intentId))
        while (history.size > 10) history.removeAt(0)
        return r
    }

    private fun lastRealIntent(): String? {
        for (i in history.indices.reversed()) {
            val id = history[i].intentId
            if (!id.startsWith("repeat_") && !id.startsWith("fallback") && id != "more_generic") return id
        }
        return null
    }

    private fun wasRecentlySupport(): Boolean {
        var seen = 0
        for (i in history.indices.reversed()) {
            if (supportIds.contains(history[i].intentId)) return true
            seen++
            if (seen >= 3) break
        }
        return false
    }

    private fun tokMatch(t: Trigger, k: Int, tok: String): Boolean {
        val w = t.tokens[k]
        if (t.prefix[k]) return tok.startsWith(w)
        if (tok == w) return true
        if (w.length >= 5 && tok.length >= 4 && Math.abs(w.length - tok.length) <= 1 && TextNorm.lev(w, tok, 1) <= 1) return true
        return false
    }

    private fun scoreIntent(it: BrainIntent, tokens: List<String>, used: BooleanArray): Match? {
        var best: Match? = null
        for (t in it.triggers) {
            val n = t.tokens.size
            if (n == 0 || n > tokens.size) continue
            // короткие одиночные слова («да», «не», «ок») считаем только в коротких сообщениях
            if (n == 1 && t.tokens[0].length <= 4 && !t.prefix[0] && tokens.size > 3) continue
            for (s in 0..(tokens.size - n)) {
                var ok = true
                for (k in 0 until n) {
                    if (used[s + k] || !tokMatch(t, k, tokens[s + k])) {
                        ok = false
                        break
                    }
                }
                if (ok) {
                    var pts = t.points
                    if (n == tokens.size) pts += 4
                    val cur = best
                    if (cur == null || pts > cur.score) best = Match(it, pts, s, s + n)
                }
            }
        }
        return best
    }

    private fun bestMatch(tokens: List<String>, used: BooleanArray): Match? {
        var best: Match? = null
        var bestKey = -1
        for (it in intents) {
            if (it.triggers.isEmpty()) continue
            val m = scoreIntent(it, tokens, used) ?: continue
            if (m.score < 5) continue
            val key = m.score * 1000 + it.priority
            if (key > bestKey) {
                bestKey = key
                best = m
            }
        }
        return best
    }

    private fun pickFallback(): BrainReply {
        val useUnknown = if (lastFallbackUnknown) Math.random() < 0.35 else Math.random() < 0.6
        lastFallbackUnknown = useUnknown
        return pick(if (useUnknown) "fallback_unknown" else "fallback_unexpected", null)
    }

    private fun pick(id: String, extra: Map<String, String>?): BrainReply {
        val it = byId[id] ?: return BrainReply("Я тут!", "NEUTRAL", id)
        if (it.responses.isEmpty()) return BrainReply("Я тут!", "NEUTRAL", id)
        val bag = bags.getOrPut(id) { Bag(it.responses.size) }
        var idx = bag.next()
        var tries = 0
        while (tries < 3 && it.responses.size > 12 && recent.contains(it.responses[idx])) {
            idx = bag.next()
            tries++
        }
        val raw = it.responses[idx]
        recent.addLast(raw)
        while (recent.size > 12) recent.removeFirst()
        return BrainReply(fill(raw, extra), it.emotion, id)
    }

    private val phRe = Regex("\\{(\\w+)\\}")

    private fun fill(s: String, extra: Map<String, String>?): String {
        if (s.indexOf('{') < 0) return s
        return phRe.replace(s) { m ->
            val key = m.groupValues[1]
            (extra?.get(key)) ?: env.value(key) ?: ""
        }
    }

    companion object {
        fun parse(json: String): List<BrainIntent> {
            val root = JSONObject(json)
            val arr = root.getJSONArray("intents")
            val out = ArrayList<BrainIntent>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val tr = ArrayList<Trigger>()
                val ta = o.getJSONArray("triggers")
                for (j in 0 until ta.length()) tr.add(Trigger.parse(ta.getString(j)))
                val rs = ArrayList<String>()
                val ra = o.getJSONArray("responses")
                for (j in 0 until ra.length()) rs.add(ra.getString(j))
                out.add(
                    BrainIntent(
                        o.getString("id"), o.optString("category", ""), o.optString("emotion", "NEUTRAL"),
                        o.optInt("priority", 5), tr, rs
                    )
                )
            }
            return out
        }
    }
}
