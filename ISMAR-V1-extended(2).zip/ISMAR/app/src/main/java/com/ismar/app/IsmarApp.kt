package com.ismar.app

import android.app.Application
import com.ismar.app.core.Prefs
import com.ismar.app.core.Store
import com.ismar.app.commands.CommandEngine

class IsmarApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)
        Store.init(this)
        CommandEngine.warmUp()
    }

    companion object {
        lateinit var instance: IsmarApp
            private set
    }
}
