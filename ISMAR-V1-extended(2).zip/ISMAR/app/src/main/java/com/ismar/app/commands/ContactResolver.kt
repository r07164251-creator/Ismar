package com.ismar.app.commands

import android.content.Context
import android.provider.ContactsContract
import com.ismar.app.assistant.TextNorm

class Contact(val name: String, val number: String)

/** Поиск контакта по произнесённому имени («маме», «Андрею»). Требует разрешение READ_CONTACTS. */
object ContactResolver {
    private fun stem(w: String): String = if (w.length >= 4) w.dropLast(1) else w

    private fun score(nameTokens: List<String>, q: List<String>): Int {
        var total = 0
        for (qt in q) {
            val qs = stem(qt)
            var best = 0
            for (nt in nameTokens) {
                val ns = stem(nt)
                if (ns == qs) best = Math.max(best, 3)
                else if (ns.startsWith(qs) || qs.startsWith(ns)) best = Math.max(best, 1)
            }
            if (best == 0) return 0
            total += best
        }
        return total
    }

    private fun all(ctx: Context): List<Contact> {
        val out = ArrayList<Contact>()
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return out
        try {
            var n = 0
            while (cur.moveToNext() && n < 8000) {
                val name = cur.getString(0) ?: continue
                val num = cur.getString(1) ?: continue
                out.add(Contact(name, num))
                n++
            }
        } finally {
            cur.close()
        }
        return out
    }

    fun find(ctx: Context, query: String): Contact? {
        val q = TextNorm.tokens(TextNorm.normalize(query))
        if (q.isEmpty()) return null
        return best(all(ctx), q)
    }

    private fun best(list: List<Contact>, q: List<String>): Contact? {
        var best: Contact? = null
        var bestScore = 0
        for (c in list) {
            val s = score(TextNorm.tokens(TextNorm.normalize(c.name)), q)
            if (s > bestScore || (s == bestScore && s > 0 && best != null && c.name.length < best.name.length)) {
                bestScore = s
                best = c
            }
        }
        return best
    }

    /** «маме привет как дела» -> (контакт «Мама», «Привет как дела»). */
    fun findWithText(ctx: Context, rest: String): Pair<Contact, String>? {
        val tokens = TextNorm.tokens(TextNorm.normalize(rest))
        if (tokens.isEmpty()) return null
        val list = all(ctx)
        var k = Math.min(3, tokens.size)
        while (k >= 1) {
            val c = best(list, tokens.subList(0, k))
            if (c != null) {
                val text = tokens.subList(k, tokens.size).joinToString(" ")
                return Pair(c, text.replaceFirstChar { it.uppercase() })
            }
            k--
        }
        return null
    }
}
