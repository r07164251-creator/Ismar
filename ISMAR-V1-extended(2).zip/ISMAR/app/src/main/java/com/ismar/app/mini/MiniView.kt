package com.ismar.app.mini

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import com.ismar.app.core.Emotion
import com.ismar.app.core.Fonts
import com.ismar.app.core.K
import com.ismar.app.core.MiniBus
import com.ismar.app.core.Pal
import com.ismar.app.core.Prefs
import com.ismar.app.core.dp
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * MINI — маленький робот. Рисуется Canvas, анимация идёт только когда нужна
 * (в покое — лишь редкие моргания/взгляды), в облегчённом режиме частота кадров снижается.
 *
 * eyesOnly = true — только глаза (для свёрнутого островка).
 */
class MiniView(ctx: Context, private val eyesOnly: Boolean = false) : View(ctx), MiniBus.Listener {
    var followBus: Boolean = true

    private companion object {
        const val EW = 0
        const val EH = 1
        const val LID_IN = 2
        const val LID_OUT = 3
        const val LID_FLAT = 4
        const val ARC = 5
        const val M_CURVE = 6
        const val M_OPEN = 7
        const val M_W = 8
        const val YELLOW = 9
        const val DIM = 10
        const val EYE_Y = 11
        const val N = 12
        const val TWO_PI = 6.2831855f
    }

    private var emotion: Emotion = Emotion.NEUTRAL
    private val cur = FloatArray(N)
    private val tgt = FloatArray(N)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    private var eyeCol: Int = Pal.ORANGE
    private val screenColor: Int = if (eyesOnly) 0xFF000000.toInt() else 0xFF141418.toInt()

    private var blinkT = -1f
    private var nextBlink = 0L
    private var nextLook = 0L
    private var gx = 0f
    private var gy = 0f
    private var gtx = 0f
    private var gty = 0f
    private var lookHold = 0L
    private var tilt = 0f
    private var tiltT = 0f
    private var bob = 0f
    private var bobT = 0f
    private var shake = 0f
    private var shakeT = 0f
    private var mouthOsc = 0f
    private var zPhase = 0f
    private var time = 0f
    private var lastFrame = 0L
    private var shaderScale = -1f

    private val frameRunnable = Runnable { step() }

    init {
        setTargets(Emotion.NEUTRAL)
        for (i in 0 until N) cur[i] = tgt[i]
        refreshStyle()
    }

    fun refreshStyle() {
        val idx = Prefs.i(K.MINI_COLOR).coerceIn(0, Pal.ACCENTS.size - 1)
        eyeCol = Pal.ACCENTS[idx]
        invalidate()
    }

    fun setEmotion(e: Emotion) {
        emotion = e
        setTargets(e)
        if (e == Emotion.SCARED || e == Emotion.SURPRISED || e == Emotion.WAKING) blinkT = -1f
        kick()
    }

    private fun setTargets(e: Emotion) {
        tgt[EW] = 1f; tgt[EH] = 1f; tgt[LID_IN] = 0f; tgt[LID_OUT] = 0f; tgt[LID_FLAT] = 0f
        tgt[ARC] = 0f; tgt[M_CURVE] = 0.35f; tgt[M_OPEN] = 0f; tgt[M_W] = 1f
        tgt[YELLOW] = 0f; tgt[DIM] = 0f; tgt[EYE_Y] = 0f
        when (e) {
            Emotion.NEUTRAL -> {}
            Emotion.HAPPY -> { tgt[ARC] = 1f; tgt[M_CURVE] = 1f; tgt[M_OPEN] = 0.35f; tgt[M_W] = 1.2f }
            Emotion.SAD -> { tgt[LID_OUT] = 0.6f; tgt[EH] = 0.9f; tgt[M_CURVE] = -0.9f; tgt[M_W] = 0.8f; tgt[EYE_Y] = 0.08f }
            Emotion.ANGRY -> { tgt[LID_IN] = 0.65f; tgt[EH] = 0.95f; tgt[M_CURVE] = -0.55f; tgt[M_W] = 0.9f }
            Emotion.SURPRISED -> { tgt[EW] = 1.25f; tgt[EH] = 1.45f; tgt[M_OPEN] = 1f; tgt[M_CURVE] = 0f; tgt[M_W] = 0.55f }
            Emotion.SCARED -> { tgt[EW] = 0.8f; tgt[EH] = 1.5f; tgt[M_OPEN] = 0.5f; tgt[M_CURVE] = -0.2f; tgt[M_W] = 1f }
            Emotion.SLEEPING -> { tgt[EH] = 0.07f; tgt[M_CURVE] = 0.1f; tgt[M_W] = 0.6f }
            Emotion.WAKING -> { tgt[EH] = 1.2f; tgt[M_OPEN] = 0.4f; tgt[M_W] = 0.6f; tgt[M_CURVE] = 0f }
            Emotion.DANCING -> { tgt[ARC] = 1f; tgt[M_CURVE] = 1f; tgt[M_OPEN] = 0.6f; tgt[M_W] = 1.3f }
            Emotion.HUNGRY -> { tgt[LID_OUT] = 0.35f; tgt[LID_FLAT] = 0.1f; tgt[EH] = 0.9f; tgt[M_CURVE] = -0.1f; tgt[M_OPEN] = 0.5f; tgt[M_W] = 0.9f }
            Emotion.BORED -> { tgt[EH] = 0.8f; tgt[LID_FLAT] = 0.45f; tgt[M_CURVE] = 0f; tgt[M_W] = 0.7f }
            Emotion.CHARGING -> { tgt[YELLOW] = 1f; tgt[M_CURVE] = 0.7f }
            Emotion.FADING -> { tgt[DIM] = 0.75f; tgt[EH] = 0.8f; tgt[LID_FLAT] = 0.5f; tgt[M_CURVE] = -0.2f; tgt[M_W] = 0.6f }
            Emotion.ANNOYED -> { tgt[EH] = 0.85f; tgt[LID_FLAT] = 0.4f; tgt[M_CURVE] = -0.5f; tgt[M_W] = 0.8f }
            Emotion.THINKING -> { tgt[M_CURVE] = 0f; tgt[M_W] = 0.5f }
        }
    }

    // ---------- MiniBus.Listener ----------

    override fun onEmotion(e: Emotion) {
        if (followBus) setEmotion(e)
    }

    override fun onLook(x: Float, y: Float) {
        gtx = x
        gty = y
        lookHold = SystemClock.uptimeMillis() + 1600L
        kick()
    }

    override fun onBlink() {
        blinkT = 0f
        kick()
    }

    override fun onPause(paused: Boolean) {
        if (!paused) kick()
    }

    // ---------- жизненный цикл ----------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        refreshStyle()
        lastFrame = SystemClock.uptimeMillis()
        if (followBus) MiniBus.add(this)
        kick()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        MiniBus.remove(this)
        removeCallbacks(frameRunnable)
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) kick()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) kick()
    }

    override fun onMeasure(w: Int, h: Int) {
        val dw = if (eyesOnly) dp(60) else dp(96)
        val dh = if (eyesOnly) dp(24) else dp(96)
        setMeasuredDimension(resolveSize(dw, w), resolveSize(dh, h))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        buildShaders(scale())
    }

    private fun scale(): Float {
        val w = width.toFloat()
        val h = height.toFloat()
        return if (eyesOnly) h / 40f else min(w, h) / 100f
    }

    private fun buildShaders(s: Float) {
        if (s <= 0f || eyesOnly) return
        shaderScale = s
        glowPaint.shader = RadialGradient(
            0f, 0f, 62f * s,
            intArrayOf(Pal.alpha(Pal.AMBER, 200), Pal.alpha(Pal.AMBER, 0)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        headPaint.shader = LinearGradient(
            0f, -32f * s, 0f, 34f * s,
            Pal.BONE, 0xFFD6D0C6.toInt(), Shader.TileMode.CLAMP
        )
    }

    // ---------- кадровый цикл ----------

    private fun kick() {
        if (!isAttachedToWindow) return
        removeCallbacks(frameRunnable)
        postOnAnimation(frameRunnable)
    }

    private fun postFrame(delay: Long) {
        removeCallbacks(frameRunnable)
        if (delay <= 0L) postOnAnimation(frameRunnable) else postDelayed(frameRunnable, delay)
    }

    private fun step() {
        if (!isAttachedToWindow || !isShown || MiniBus.paused || windowVisibility != VISIBLE) return
        val now = SystemClock.uptimeMillis()
        var dt = (now - lastFrame) / 1000f
        lastFrame = now
        if (dt > 0.1f) dt = 0.1f
        if (dt <= 0f) dt = 0.016f
        time += dt

        val light = Prefs.light(context)
        val speed = 14f / Prefs.animScale()
        val k = 1f - exp(-dt * speed)
        var moving = false
        for (i in 0 until N) {
            val d = tgt[i] - cur[i]
            if (abs(d) > 0.003f) {
                cur[i] += d * k
                moving = true
            } else {
                cur[i] = tgt[i]
            }
        }

        // моргание
        val canBlink = Prefs.b(K.MINI_BLINK) && emotion != Emotion.SLEEPING && cur[ARC] < 0.5f
        if (blinkT >= 0f) {
            blinkT += dt / 0.2f
            if (blinkT >= 1f) {
                blinkT = -1f
                nextBlink = now + 2200L + (Math.random() * 3200.0).toLong()
            } else {
                moving = true
            }
        } else if (canBlink) {
            if (nextBlink == 0L) nextBlink = now + 1500L + (Math.random() * 2000.0).toLong()
            if (now >= nextBlink) {
                blinkT = 0f
                moving = true
            }
        }

        // взгляд
        val lookOk = Prefs.b(K.MINI_LOOK) && !light
        var periodic = false
        var slow = false
        var tt = 0f
        var bt = 0f
        var st = 0f
        mouthOsc = 0f
        when (emotion) {
            Emotion.DANCING -> {
                periodic = true
                tt = 11f * sin(time * 9f)
                bt = -2.5f * abs(sin(time * 9f))
                gtx = 0f; gty = 0f
            }
            Emotion.SCARED -> {
                periodic = true
                st = 0.9f * sin(time * 55f)
                gtx = 0.5f * sin(time * 31f); gty = 0f
            }
            Emotion.HUNGRY -> {
                periodic = true
                mouthOsc = 0.5f + 0.5f * sin(time * 7f)
            }
            Emotion.SLEEPING, Emotion.FADING -> {
                periodic = true; slow = true
                bt = 0.8f * sin(time * 1.6f)
                zPhase = (time * 0.45f) % 1f
                gtx = 0f; gty = 0f
            }
            Emotion.BORED -> {
                periodic = true; slow = true
                gtx = sin(time * 0.7f)
                gty = 0.2f
            }
            Emotion.THINKING -> {
                gtx = 0.8f; gty = -0.8f
            }
            else -> {
                if (lookOk && now >= lookHold) {
                    if (nextLook == 0L) nextLook = now + 1200L
                    if (now >= nextLook) {
                        gtx = ((Math.random() * 2.0) - 1.0).toFloat()
                        gty = (((Math.random() * 2.0) - 1.0) * 0.6).toFloat()
                        if (Math.random() < 0.35) {
                            gtx = 0f; gty = 0f
                        }
                        nextLook = now + 1800L + (Math.random() * 3200.0).toLong()
                    }
                } else if (now >= lookHold && !lookOk) {
                    gtx = 0f; gty = 0f
                }
            }
        }
        val kg = 1f - exp(-dt * 9f)
        if (abs(gtx - gx) > 0.01f || abs(gty - gy) > 0.01f) {
            gx += (gtx - gx) * kg
            gy += (gty - gy) * kg
            moving = true
        }
        tilt += (tt - tilt) * k
        bob += (bt - bob) * k
        shake += (st - shake) * k
        if (abs(tilt - tt) > 0.05f || abs(bob - bt) > 0.02f) moving = true

        invalidate()

        if (moving || (periodic && !slow)) {
            postFrame(if (light) 66L else 0L)
        } else if (periodic) {
            postFrame(if (light) 160L else 90L)
        } else {
            var wait = 4000L
            if (blinkT < 0f && canBlink) wait = min(wait, max(50L, nextBlink - now))
            if (lookOk && nextLook > 0L) wait = min(wait, max(50L, nextLook - now))
            postFrame(wait)
        }
    }

    // ---------- рисование ----------

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = scale()
        if (!eyesOnly && s != shaderScale) buildShaders(s)
        val dim = cur[DIM]
        val yel = cur[YELLOW]
        var col = Pal.mix(eyeCol, Pal.AMBER, yel)
        col = Pal.mix(col, 0xFF5A3A1E.toInt(), dim * 0.8f)

        c.save()
        val oy = if (eyesOnly) h / 2f else h / 2f + 7.5f * s
        c.translate(w / 2f + shake * s, oy + bob * s)
        c.rotate(tilt)
        if (!eyesOnly) drawHead(c, s, col, dim, yel)
        drawFace(c, s, col)
        c.restore()
    }

    private fun drawHead(c: Canvas, s: Float, col: Int, dim: Float, yel: Float) {
        if (yel > 0.02f) {
            glowPaint.alpha = (150f * yel).toInt()
            c.drawCircle(0f, 0f, 62f * s, glowPaint)
        }
        // уши
        p.style = Paint.Style.FILL
        p.color = col
        rect.set(-45f * s, -8f * s, -37f * s, 10f * s)
        c.drawRoundRect(rect, 3.5f * s, 3.5f * s, p)
        rect.set(37f * s, -8f * s, 45f * s, 10f * s)
        c.drawRoundRect(rect, 3.5f * s, 3.5f * s, p)
        // антенна
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.4f * s
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFFCFC9BF.toInt()
        c.drawLine(0f, -32f * s, 0f, -41f * s, p)
        p.style = Paint.Style.FILL
        p.color = col
        c.drawCircle(0f, -45f * s, 4.4f * s, p)
        // голова
        rect.set(-38f * s, -32f * s, 38f * s, 34f * s)
        headPaint.alpha = 255
        c.drawRoundRect(rect, 19f * s, 19f * s, headPaint)
        if (dim > 0.01f) {
            p.style = Paint.Style.FILL
            p.color = Pal.alpha(0xFF000000.toInt(), (170f * dim).toInt())
            c.drawRoundRect(rect, 19f * s, 19f * s, p)
        }
        // экран лица
        p.style = Paint.Style.FILL
        p.color = screenColor
        rect.set(-31f * s, -22f * s, 31f * s, 24f * s)
        c.drawRoundRect(rect, 12f * s, 12f * s, p)
        // zZz и капелька пота
        if (emotion == Emotion.SLEEPING || emotion == Emotion.FADING) drawZ(c, s, col)
        if (emotion == Emotion.SCARED) {
            p.style = Paint.Style.FILL
            p.color = 0xFF7CC4FF.toInt()
            c.drawCircle(33f * s, -12f * s, 2.5f * s, p)
            path.reset()
            path.moveTo(30.8f * s, -13f * s)
            path.lineTo(33f * s, -19f * s)
            path.lineTo(35.2f * s, -13f * s)
            path.close()
            c.drawPath(path, p)
        }
    }

    private fun drawZ(c: Canvas, s: Float, col: Int) {
        p.style = Paint.Style.FILL
        p.typeface = Fonts.medium
        for (i in 0 until 3) {
            val pr = (zPhase + i / 3f) % 1f
            val x = (30f + 12f * pr) * s
            val y = (-34f - 22f * pr) * s
            p.textSize = (6f + 6f * pr) * s
            p.color = Pal.alpha(col, (200f * sin(pr * 3.1415927f)).toInt())
            c.drawText("z", x, y, p)
        }
    }

    private fun drawFace(c: Canvas, s: Float, col: Int) {
        val baseY = if (eyesOnly) 0f else -4f
        val ey = (baseY + cur[EYE_Y] * 10f + gy * 2.2f) * s
        val dx = 13f * s
        val ox = gx * 3.2f * s
        val ew = 9f * cur[EW] * s
        var bf = 1f
        if (blinkT >= 0f) bf = 1f - 0.95f * sin(blinkT * 3.1415927f)
        val eh = max(1.6f * s, 15f * cur[EH] * s * bf)
        drawEye(c, -dx + ox, ey, ew, eh, true, s, col)
        drawEye(c, dx + ox, ey, ew, eh, false, s, col)
        if (!eyesOnly) drawMouth(c, s, col)
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float, ew: Float, eh: Float, left: Boolean, s: Float, col: Int) {
        val arc = cur[ARC]
        val top = cy - eh / 2f
        if (arc < 0.98f) {
            p.style = Paint.Style.FILL
            p.color = Pal.alpha(col, (255f * (1f - arc)).toInt())
            val r = min(ew, eh) / 2f
            rect.set(cx - ew / 2f, top, cx + ew / 2f, cy + eh / 2f)
            c.drawRoundRect(rect, r, r, p)
            if (arc < 0.5f) {
                p.color = screenColor
                val x0 = cx - ew / 2f - 1.5f * s
                val x1 = cx + ew / 2f + 1.5f * s
                val yT = top - 1.5f * s
                val li = cur[LID_IN]
                if (li > 0.01f) {
                    path.reset()
                    val drop = eh * li * 1.1f
                    if (left) {
                        path.moveTo(x0, yT); path.lineTo(x1, yT); path.lineTo(x1, top + drop)
                    } else {
                        path.moveTo(x1, yT); path.lineTo(x0, yT); path.lineTo(x0, top + drop)
                    }
                    path.close()
                    c.drawPath(path, p)
                }
                val lo = cur[LID_OUT]
                if (lo > 0.01f) {
                    path.reset()
                    val drop = eh * lo * 1.1f
                    if (left) {
                        path.moveTo(x1, yT); path.lineTo(x0, yT); path.lineTo(x0, top + drop)
                    } else {
                        path.moveTo(x0, yT); path.lineTo(x1, yT); path.lineTo(x1, top + drop)
                    }
                    path.close()
                    c.drawPath(path, p)
                }
                val lf = cur[LID_FLAT]
                if (lf > 0.01f) {
                    rect.set(x0, yT, x1, top + eh * lf)
                    c.drawRect(rect, p)
                }
            }
        }
        if (arc > 0.02f) {
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 3.4f * s
            p.color = Pal.alpha(col, (255f * arc).toInt())
            rect.set(cx - 5.5f * s, cy - 3.5f * s, cx + 5.5f * s, cy + 6.5f * s)
            c.drawArc(rect, 200f, 140f, false, p)
        }
    }

    private fun drawMouth(c: Canvas, s: Float, col: Int) {
        val y = 13f * s
        val mw = 14f * cur[M_W] * s
        val open = (cur[M_OPEN] + mouthOsc * 0.5f).coerceIn(0f, 1f)
        val strokeA = (1f - open * 3f).coerceIn(0f, 1f)
        val ovalA = (open * 3f).coerceIn(0f, 1f)
        if (strokeA > 0.02f) {
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 2.5f * s
            p.color = Pal.alpha(col, (255f * strokeA).toInt())
            path.reset()
            path.moveTo(-mw / 2f, y)
            path.quadTo(0f, y + 8f * s * cur[M_CURVE], mw / 2f, y)
            c.drawPath(path, p)
        }
        if (ovalA > 0.02f) {
            p.style = Paint.Style.FILL
            p.color = Pal.alpha(col, (255f * ovalA).toInt())
            val ow = 12f * cur[M_W] * s
            val oh = (2f + 10f * open) * s
            rect.set(-ow / 2f, y - oh * 0.3f, ow / 2f, y + oh * 0.7f)
            c.drawOval(rect, p)
        }
    }
}
