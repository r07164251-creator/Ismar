package com.ismar.app.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.FrameLayout
import com.ismar.app.core.*

class BoltView(ctx: Context, private val onClick: () -> Unit) : FrameLayout(ctx) {
    init {
        background=GradientDrawable().apply { shape=GradientDrawable.OVAL; setColor(0xFF17171C.toInt()); setStroke(ctx.dp(1),0xFF383840.toInt()) }
        elevation=ctx.dpf(10f)
        val icon=IconView(ctx,Ic.BOLT,Pal.ORANGE)
        addView(icon,LayoutParams(ctx.dp(24),ctx.dp(24),Gravity.CENTER))
        setOnClickListener { performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK); onClick() }
    }
}
