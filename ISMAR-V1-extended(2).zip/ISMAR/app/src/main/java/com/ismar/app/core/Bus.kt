package com.ismar.app.core

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

enum class Emotion(val ru: String) {
    NEUTRAL("спокойный"),
    HAPPY("радостный"),
    SAD("грустный"),
    ANGRY("злой"),
    SURPRISED("удивлённый"),
    SCARED("испуганный"),
    SLEEPING("спящий"),
    WAKING("только что проснулся"),
    DANCING("танцующий"),
    HUNGRY("голодный"),
    BORED("скучающий"),
    CHARGING("заряжается"),
    FADING("угасающий"),
    ANNOYED("недовольный"),
    THINKING("задумчивый");

    companion object {
        fun parse(s: String?): Emotion {
            if (s == null) return NEUTRAL
            for (e in values()) if (e.name.equals(s, ignoreCase = true)) return e
            return NEUTRAL
        }
    }
}

/**
 * Общая «нервная система» MINI. Любой MiniView подписывается здесь и показывает текущее состояние.
 * Постоянные состояния (зарядка, голод, сон...) — флаги; кратковременные реакции — react().
 */
object MiniBus {
    interface Listener {
        fun onEmotion(e: Emotion)
        fun onLook(x: Float, y: Float) {}
        fun onBlink() {}
        fun onPause(paused: Boolean) {}
    }

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()
    private var transient: Emotion? = null

    @Volatile
    var current: Emotion = Emotion.NEUTRAL
        private set

    @Volatile
    var paused: Boolean = false
        private set

    var charging: Boolean = false
        set(v) { field = v; publish(false) }
    var hungry: Boolean = false
        set(v) { field = v; publish(false) }
    var fading: Boolean = false
        set(v) { field = v; publish(false) }
    var sleeping: Boolean = false
        set(v) { field = v; publish(false) }
    var bored: Boolean = false
        set(v) { field = v; publish(false) }

    private val revert = Runnable {
        transient = null
        publish(false)
    }

    fun add(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
        l.onEmotion(current)
    }

    fun remove(l: Listener) {
        listeners.remove(l)
    }

    private fun baseline(): Emotion = when {
        fading -> Emotion.FADING
        charging -> Emotion.CHARGING
        hungry -> Emotion.HUNGRY
        sleeping -> Emotion.SLEEPING
        bored -> Emotion.BORED
        else -> Emotion.NEUTRAL
    }

    private fun publish(force: Boolean) {
        runMain {
            val e = transient ?: baseline()
            if (e != current || force) {
                current = e
                for (l in listeners) l.onEmotion(e)
            }
        }
    }

    /** Кратковременная реакция: показывается holdMs, затем возвращается базовое состояние. */
    fun react(e: Emotion, holdMs: Long = 2500L) {
        runMain {
            handler.removeCallbacks(revert)
            transient = e
            publish(true)
            handler.postDelayed(revert, holdMs)
        }
    }

    fun clearReaction() {
        runMain {
            handler.removeCallbacks(revert)
            transient = null
            publish(false)
        }
    }

    fun look(x: Float, y: Float) {
        runMain { for (l in listeners) l.onLook(x, y) }
    }

    fun blink() {
        runMain { for (l in listeners) l.onBlink() }
    }

    fun setPaused(p: Boolean) {
        runMain {
            paused = p
            for (l in listeners) l.onPause(p)
        }
    }
}

/** Событие для островка: короткий баннер в свёрнутом состоянии. */
class IslandEvent(
    val kind: String,        // charge, battery, music, notif, mini, info
    val title: String,
    val text: String = "",
    val holdMs: Long = 2600L
)

object IslandBus {
    interface Listener {
        fun onEvent(e: IslandEvent)
    }

    private val listeners = CopyOnWriteArrayList<Listener>()

    fun add(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun remove(l: Listener) {
        listeners.remove(l)
    }

    fun post(e: IslandEvent) {
        if (!Prefs.b(K.ISLAND_EVENTS)) return
        runMain { for (l in listeners) l.onEvent(e) }
    }
}
