package com.ismar.app.system

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import com.ismar.app.core.Perms

/** Яркость экрана: требует специального разрешения «Изменение системных настроек». */
object Brightness {
    fun canWrite(ctx: Context): Boolean = Perms.writeSettings(ctx)

    fun get(ctx: Context): Int {
        return try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
            128
        }
    }

    fun isAuto(ctx: Context): Boolean {
        return try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE) ==
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
        } catch (e: Exception) {
            false
        }
    }

    /** value 1..255. Возвращает true только если система действительно приняла значение. */
    fun set(ctx: Context, value: Int): Boolean {
        if (!canWrite(ctx)) return false
        return try {
            val v = value.coerceIn(1, 255)
            Settings.System.putInt(
                ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun setAuto(ctx: Context, auto: Boolean): Boolean {
        if (!canWrite(ctx)) return false
        return try {
            Settings.System.putInt(
                ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (auto) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    fun percent(ctx: Context): Int = (get(ctx) * 100 / 255).coerceIn(0, 100)
}

/** Фонарик (CameraManager.setTorchMode — разрешение камеры не требуется). */
object Torch {
    @Volatile
    var on: Boolean = false
        private set
    private var camId: String? = null
    private var watching = false

    private fun cm(ctx: Context): CameraManager = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private fun findId(ctx: Context): String? {
        if (camId != null) return camId
        try {
            val m = cm(ctx)
            for (id in m.cameraIdList) {
                val ch = m.getCameraCharacteristics(id)
                val flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
                val facing = ch.get(CameraCharacteristics.LENS_FACING)
                if (flash == true && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    camId = id
                    break
                }
            }
        } catch (e: Exception) {
        }
        return camId
    }

    fun available(ctx: Context): Boolean = findId(ctx) != null

    fun watch(ctx: Context) {
        if (watching) return
        if (findId(ctx) == null) return
        watching = true
        try {
            cm(ctx).registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == camId) on = enabled
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            watching = false
        }
    }

    fun set(ctx: Context, enable: Boolean): Boolean {
        val id = findId(ctx) ?: return false
        return try {
            cm(ctx).setTorchMode(id, enable)
            on = enable
            true
        } catch (e: Exception) {
            false
        }
    }

    fun toggle(ctx: Context): Boolean = set(ctx, !on)
}

object Volume {
    private fun am(ctx: Context): AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun percent(ctx: Context): Int {
        val a = am(ctx)
        val max = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max <= 0) 0 else a.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
    }

    fun setPercent(ctx: Context, pct: Int) {
        val a = am(ctx)
        val max = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val v = (pct.coerceIn(0, 100) * max / 100.0 + 0.5).toInt()
        a.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI)
    }

    fun up(ctx: Context) {
        am(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
    }

    fun down(ctx: Context) {
        am(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    fun isMuted(ctx: Context): Boolean = am(ctx).isStreamMute(AudioManager.STREAM_MUSIC)

    fun mute(ctx: Context) {
        am(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
    }

    fun unmute(ctx: Context) {
        am(ctx).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
    }
}
