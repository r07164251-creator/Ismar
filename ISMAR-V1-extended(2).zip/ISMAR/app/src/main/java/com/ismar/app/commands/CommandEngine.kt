package com.ismar.app.commands

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.ismar.app.assistant.Brain
import com.ismar.app.assistant.Calc
import com.ismar.app.core.Emotion
import com.ismar.app.core.IslandBus
import com.ismar.app.core.IslandEvent
import com.ismar.app.core.K
import com.ismar.app.core.MiniBus
import com.ismar.app.core.Perms
import com.ismar.app.core.Prefs
import com.ismar.app.media.MusicMonitor
import com.ismar.app.screens.ChatActivity
import com.ismar.app.screens.CommandsActivity
import com.ismar.app.screens.SettingsActivity
import com.ismar.app.screens.WidgetsActivity
import com.ismar.app.service.OverlayService
import com.ismar.app.system.BatteryMonitor
import com.ismar.app.system.Brightness
import com.ismar.app.system.SysInfo
import com.ismar.app.system.Torch
import com.ismar.app.system.Volume
import java.net.URLEncoder

/**
 * Итог выполнения команды. ok = true ТОЛЬКО если действие реально выполнено (или команда реально отправлена системе).
 * needPerm — runtime-разрешение, без которого команда не выполнена; soft — команда распознана, но цель не найдена.
 */
class CommandResult(
    val ok: Boolean,
    val message: String,
    val emotion: Emotion? = null,
    val launched: Boolean = false,
    val needPerm: String? = null,
    val soft: Boolean = false
)

class CommandMatch(val cmd: Cmd, val slots: Map<String, String>, val input: String)

/** Локальный распознаватель и исполнитель команд. Без облака; всё, что требует интернета, — честно сообщает. */
object CommandEngine {
    private class Entry(val cmd: Cmd, val c: CommandPattern.Compiled)

    private val entries: List<Entry> by lazy { build() }

    private fun build(): List<Entry> {
        val out = ArrayList<Entry>()
        for ((idx, cmd) in CommandCatalog.all.withIndex()) {
            for (p in cmd.patterns) {
                for (v in CommandPattern.expand(p)) out.add(Entry(cmd, CommandPattern.compile(idx, v)))
            }
        }
        return out
    }

    fun warmUp() {
        Thread { entries.size }.start()
    }

    fun commandCount(): Int = CommandCatalog.all.size

    fun variantCount(): Int = entries.size

    fun match(raw: String): CommandMatch? {
        val s = CommandPattern.normalizeInput(raw)
        if (s.isEmpty()) return null
        var best: Entry? = null
        var bestMatch: MatchResult? = null
        for (e in entries) {
            val m = e.c.regex.matchEntire(s) ?: continue
            val b = best
            if (b == null || e.c.literalLen > b.c.literalLen ||
                (e.c.literalLen == b.c.literalLen && e.c.order < b.c.order)
            ) {
                best = e
                bestMatch = m
            }
        }
        val be = best ?: return null
        val bm = bestMatch ?: return null
        val slots = HashMap<String, String>()
        for ((i, name) in be.c.slots.withIndex()) slots[name] = bm.groupValues[i + 1].trim()
        return CommandMatch(be.cmd, slots, s)
    }

    /** Распознать и выполнить. done(null) — это не команда (пусть отвечает собеседник MINI). */
    fun run(ctx: Context, raw: String, done: (CommandResult?) -> Unit) {
        val m = match(raw)
        if (m == null) {
            done(null)
            return
        }
        val r = execute(ctx, m)
        val perm = r.needPerm
        if (perm != null && !Perms.has(ctx, perm)) {
            Perms.request(ctx, perm) { granted ->
                if (granted) done(react(execute(ctx, m)))
                else done(react(CommandResult(false, "Без этого разрешения я не смогу выполнить команду.", Emotion.SAD)))
            }
            return
        }
        done(react(r))
    }

    private fun react(r: CommandResult): CommandResult {
        MiniBus.react(r.emotion ?: (if (r.ok) Emotion.HAPPY else Emotion.SAD), 1600L)
        return r
    }

    fun execute(ctx: Context, m: CommandMatch): CommandResult {
        return try {
            doExecute(ctx, m)
        } catch (e: Exception) {
            CommandResult(false, "Не получилось выполнить команду: " + (e.message ?: e.javaClass.simpleName), Emotion.SAD)
        }
    }

    // ---------- вспомогательное ----------

    private fun ok(msg: String, e: Emotion? = null, launched: Boolean = false) = CommandResult(true, msg, e, launched)
    private fun fail(msg: String, launched: Boolean = false) = CommandResult(false, msg, Emotion.SAD, launched)

    private fun start(ctx: Context, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun screen(ctx: Context, cls: Class<out Activity>, what: String): CommandResult {
        return if (start(ctx, Intent(ctx, cls))) ok("Открываю $what.", null, true) else fail("Не получилось открыть $what.")
    }

    private fun category(ctx: Context, cat: String, what: String): CommandResult {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)
        return if (start(ctx, i)) ok("Открываю $what.", null, true)
        else fail("На телефоне не нашлось приложения для запроса «$what».")
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun url(ctx: Context, u: String, what: String): CommandResult {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(u))
        return if (start(ctx, i)) ok("$what — открываю. (Для этого нужен интернет.)", null, true)
        else fail("Не нашлось приложения, которое откроет ссылку.")
    }

    private fun openKnown(ctx: Context, alias: String, title: String, fallbackUrl: String): CommandResult {
        val app = AppResolver.findAlias(ctx, alias)
        if (app != null && AppResolver.launch(ctx, app.pkg)) return ok("Открываю $title.", null, true)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl))
        return if (start(ctx, i)) ok("Приложения $title на телефоне нет — открыл сайт в браузере (нужен интернет).", null, true)
        else fail("Приложения $title нет, и открыть сайт тоже не получилось.")
    }

    private fun settings(ctx: Context, action: String, what: String, toggle: Boolean): CommandResult {
        return if (start(ctx, Intent(action))) {
            if (toggle) ok("Открыл $what. Включать и выключать это напрямую Android приложениям не позволяет — переключите вручную.", null, true)
            else ok("Открываю $what.", null, true)
        } else fail("Не получилось открыть $what.")
    }

    private val settingsMap: Map<String, Pair<String, String>> = mapOf(
        "app_settings" to Pair(Settings.ACTION_SETTINGS, "настройки телефона"),
        "settings_sound" to Pair(Settings.ACTION_SOUND_SETTINGS, "настройки звука"),
        "settings_bluetooth" to Pair(Settings.ACTION_BLUETOOTH_SETTINGS, "настройки Bluetooth"),
        "settings_wifi" to Pair(Settings.ACTION_WIFI_SETTINGS, "настройки Wi‑Fi"),
        "settings_display" to Pair(Settings.ACTION_DISPLAY_SETTINGS, "настройки экрана"),
        "settings_battery" to Pair(Settings.ACTION_BATTERY_SAVER_SETTINGS, "настройки энергосбережения"),
        "settings_apps" to Pair(Settings.ACTION_APPLICATION_SETTINGS, "список приложений"),
        "settings_location" to Pair(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "настройки геолокации"),
        "settings_airplane" to Pair(Settings.ACTION_AIRPLANE_MODE_SETTINGS, "настройки режима полёта"),
        "settings_nfc" to Pair(Settings.ACTION_NFC_SETTINGS, "настройки NFC"),
        "settings_date" to Pair(Settings.ACTION_DATE_SETTINGS, "настройки даты и времени"),
        "settings_language" to Pair(Settings.ACTION_LOCALE_SETTINGS, "настройки языка"),
        "settings_access" to Pair(Settings.ACTION_ACCESSIBILITY_SETTINGS, "специальные возможности"),
        "settings_storage" to Pair(Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "настройки памяти"),
        "settings_security" to Pair(Settings.ACTION_SECURITY_SETTINGS, "настройки безопасности"),
        "settings_mobile" to Pair(Settings.ACTION_DATA_ROAMING_SETTINGS, "настройки мобильной сети"),
        "settings_vpn" to Pair(Settings.ACTION_VPN_SETTINGS, "настройки VPN")
    )

    private val toggleRe = Regex("^(включи|выключи|подключи|отключи|включить|выключить)\\b")

    private fun setBrightness(ctx: Context, target255: Int): CommandResult {
        if (!Brightness.canWrite(ctx)) {
            Perms.openWriteSettings(ctx)
            return fail("Для изменения яркости нужно разрешение «Изменение системных настроек». Открыл экран разрешений — включите его для ISMAR и повторите команду.", true)
        }
        val okSet = Brightness.set(ctx, target255)
        val now = Brightness.percent(ctx)
        val want = target255 * 100 / 255
        return if (okSet && Math.abs(now - want) <= 8) ok("Яркость: $now%.", Emotion.HAPPY)
        else fail("Система не приняла новое значение яркости (сейчас $now%).")
    }

    private fun info(title: String, text: String) {
        IslandBus.post(IslandEvent("info", title, text, 3200L))
    }

    private fun openMusicApp(ctx: Context): CommandResult {
        val sp = AppResolver.findAlias(ctx, "спотифай")
        if (sp != null && AppResolver.launch(ctx, sp.pkg)) {
            return ok("Активного плеера нет — открыл Spotify. Запустите трек: как только он заиграет, я смогу им управлять.", null, true)
        }
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
        return if (start(ctx, i)) ok("Активного плеера нет — открыл музыкальное приложение.", null, true)
        else fail("Сейчас ничего не играет, а музыкального приложения я не нашёл.")
    }

    private fun musicGuard(ctx: Context): CommandResult? {
        MusicMonitor.ensure(ctx)
        if (!Perms.notifAccess(ctx)) {
            Perms.openNotifAccess(ctx)
            return fail("Для управления музыкой нужен «Доступ к уведомлениям». Открыл экран — включите ISMAR в списке.", true)
        }
        return null
    }

    private fun musicAction(name: String, sent: Boolean): CommandResult =
        if (sent) ok("Отправил плееру команду «$name».", Emotion.HAPPY)
        else fail("Сейчас нет активного плеера, которым я мог бы управлять.")

    // ---------- главный обработчик ----------

    private fun doExecute(ctx: Context, m: CommandMatch): CommandResult {
        val id = m.cmd.id
        val s = m.slots

        val st = settingsMap[id]
        if (st != null) return settings(ctx, st.first, st.second, toggleRe.containsMatchIn(m.input))

        when (id) {
            // ---- приложения ----
            "app_youtube" -> return openKnown(ctx, "ютуб", "YouTube", "https://www.youtube.com")
            "app_telegram" -> return openKnown(ctx, "телеграм", "Telegram", "https://web.telegram.org")
            "app_spotify" -> return openKnown(ctx, "спотифай", "Spotify", "https://open.spotify.com")
            "app_camera" -> {
                return if (start(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) ok("Открываю камеру.", null, true)
                else fail("Не нашёл приложение камеры.")
            }
            "app_browser" -> return category(ctx, Intent.CATEGORY_APP_BROWSER, "браузер")
            "app_gallery" -> return category(ctx, Intent.CATEGORY_APP_GALLERY, "галерею")
            "app_calc" -> return category(ctx, Intent.CATEGORY_APP_CALCULATOR, "калькулятор")
            "app_contacts" -> return category(ctx, Intent.CATEGORY_APP_CONTACTS, "контакты")
            "app_messages" -> return category(ctx, Intent.CATEGORY_APP_MESSAGING, "сообщения")
            "app_maps" -> return category(ctx, Intent.CATEGORY_APP_MAPS, "карты")
            "app_mail" -> return category(ctx, Intent.CATEGORY_APP_EMAIL, "почту")
            "app_market" -> return category(ctx, Intent.CATEGORY_APP_MARKET, "магазин приложений")
            "app_calendar" -> return category(ctx, Intent.CATEGORY_APP_CALENDAR, "календарь")
            "app_dialer" -> {
                return if (start(ctx, Intent(Intent.ACTION_DIAL))) ok("Открываю набор номера.", null, true)
                else fail("Не нашёл приложение для звонков.")
            }
            "app_clock" -> {
                return if (start(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))) ok("Открываю часы и будильники.", null, true)
                else fail("Не нашёл приложение часов.")
            }
            "app_generic" -> {
                val q = s["app"] ?: ""
                val app = AppResolver.find(ctx, q)
                    ?: return CommandResult(false, "Не нашёл приложение «$q» на этом телефоне.", Emotion.SAD, false, null, true)
                return if (AppResolver.launch(ctx, app.pkg)) ok("Открываю ${app.label}.", Emotion.HAPPY, true)
                else fail("Не получилось открыть ${app.label}.")
            }

            // ---- поиск ----
            "search_youtube" -> return url(ctx, "https://www.youtube.com/results?search_query=" + enc(s["query"] ?: ""), "Ищу «${s["query"]}» в YouTube")
            "search_wiki" -> return url(ctx, "https://ru.wikipedia.org/w/index.php?search=" + enc(s["query"] ?: ""), "Ищу «${s["query"]}» в Википедии")
            "search_yandex" -> return url(ctx, "https://yandex.ru/search/?text=" + enc(s["query"] ?: ""), "Ищу «${s["query"]}» в Яндексе")
            "search_web" -> return url(ctx, "https://www.google.com/search?q=" + enc(s["query"] ?: ""), "Ищу «${s["query"]}»")
            "open_google" -> return url(ctx, "https://www.google.com", "Открываю Google")
            "search_maps" -> {
                val q = s["query"] ?: ""
                if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + enc(q))))) return ok("Ищу «$q» на карте.", null, true)
                return url(ctx, "https://www.google.com/maps/search/?api=1&query=" + enc(q), "Ищу «$q» на карте")
            }
            "open_site" -> {
                val site = s["site"] ?: ""
                if (!site.contains('.')) {
                    return CommandResult(false, "Это не похоже на адрес сайта. Скажите, например: «открой сайт example.com».", Emotion.SAD, false, null, true)
                }
                val u = if (site.startsWith("http")) site else "https://$site"
                return url(ctx, u, "Открываю $site")
            }

            // ---- телефон ----
            "show_battery" -> {
                val b = BatteryMonitor.read(ctx)
                val t = "Заряд ${b.level}% — ${b.statusText()}."
                info("Батарея", "${b.level}%")
                return ok(t, Emotion.HAPPY)
            }
            "brightness_set" -> {
                val n = (s["n"] ?: "50").toInt().coerceIn(1, 100)
                return setBrightness(ctx, Math.max(1, n * 255 / 100))
            }
            "brightness_up" -> return setBrightness(ctx, Math.min(255, Brightness.get(ctx) + 40))
            "brightness_down" -> return setBrightness(ctx, Math.max(1, Brightness.get(ctx) - 40))
            "brightness_max" -> return setBrightness(ctx, 255)
            "brightness_min" -> return setBrightness(ctx, 8)
            "brightness_auto_on", "brightness_auto_off" -> {
                if (!Brightness.canWrite(ctx)) {
                    Perms.openWriteSettings(ctx)
                    return fail("Нужно разрешение «Изменение системных настроек». Открыл экран разрешений.", true)
                }
                val on = id == "brightness_auto_on"
                val done = Brightness.setAuto(ctx, on) && Brightness.isAuto(ctx) == on
                return if (done) ok(if (on) "Автояркость включена." else "Автояркость выключена.", Emotion.HAPPY)
                else fail("Система не приняла изменение автояркости.")
            }
            "volume_set" -> {
                val n = (s["n"] ?: "50").toInt().coerceIn(0, 100)
                Volume.setPercent(ctx, n)
                val now = Volume.percent(ctx)
                return if (Math.abs(now - n) <= 12) ok("Громкость мультимедиа: $now%.", Emotion.HAPPY)
                else fail("Громкость не изменилась (сейчас $now%). Возможно, её ограничивает подключённое устройство.")
            }
            "volume_up" -> {
                Volume.up(ctx)
                return ok("Прибавил громкость мультимедиа: ${Volume.percent(ctx)}%.", Emotion.HAPPY)
            }
            "volume_down" -> {
                Volume.down(ctx)
                return ok("Убавил громкость мультимедиа: ${Volume.percent(ctx)}%.", Emotion.HAPPY)
            }
            "volume_max" -> {
                Volume.setPercent(ctx, 100)
                return ok("Громкость мультимедиа: ${Volume.percent(ctx)}%.", Emotion.HAPPY)
            }
            "volume_mute" -> {
                Volume.mute(ctx)
                return if (Volume.isMuted(ctx) || Volume.percent(ctx) == 0) ok("Звук мультимедиа выключен.", Emotion.SLEEPING)
                else fail("Не удалось выключить звук мультимедиа.")
            }
            "volume_unmute" -> {
                Volume.unmute(ctx)
                return if (!Volume.isMuted(ctx)) ok("Звук мультимедиа включён: ${Volume.percent(ctx)}%.", Emotion.HAPPY)
                else fail("Не удалось включить звук мультимедиа.")
            }
            "show_time" -> {
                val t = SysInfo.timeText()
                info("Время", t)
                return ok("Сейчас $t.", Emotion.HAPPY)
            }
            "show_date" -> {
                val d = SysInfo.dateLong()
                info("Дата", SysInfo.dateText())
                return ok("Сегодня $d.", Emotion.HAPPY)
            }
            "torch_on", "torch_off" -> {
                Torch.watch(ctx)
                if (!Torch.available(ctx)) return fail("На этом устройстве нет вспышки для фонарика.")
                val on = id == "torch_on"
                return if (Torch.set(ctx, on)) ok(if (on) "Фонарик включён." else "Фонарик выключен.", Emotion.HAPPY)
                else fail("Не удалось переключить фонарик (возможно, камеру занимает другое приложение).")
            }
            "phone_state" -> return ok(SysInfo.report(ctx), Emotion.HAPPY)
            "storage_info" -> return ok("Память: " + SysInfo.storageText() + ".", Emotion.HAPPY)
            "network_info" -> {
                val net = SysInfo.network(ctx)
                val internet = SysInfo.hasInternet(ctx)
                return ok("Сеть: $net. " + (if (internet) "Интернет доступен." else "Доступа в интернет нет."), Emotion.HAPPY)
            }

            // ---- звонки и сообщения ----
            "call_number" -> {
                val num = (s["tel"] ?: "").replace(" ", "")
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
                return if (start(ctx, i)) ok("Подготовил звонок на $num. Нажмите кнопку вызова в приложении телефона.", Emotion.HAPPY, true)
                else fail("Не нашёл приложение для звонков.")
            }
            "call_contact" -> {
                if (!Perms.has(ctx, Perms.CONTACTS)) {
                    return CommandResult(false, "Нужен доступ к контактам, чтобы найти нужного человека.", Emotion.SAD, false, Perms.CONTACTS)
                }
                val q = s["contact"] ?: ""
                val c = ContactResolver.find(ctx, q)
                    ?: return CommandResult(false, "Не нашёл контакт «$q».", Emotion.SAD, false, null, true)
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(c.number)))
                return if (start(ctx, i)) ok("Подготовил звонок: ${c.name}, ${c.number}. Нажмите кнопку вызова — сам я не звоню.", Emotion.HAPPY, true)
                else fail("Не нашёл приложение для звонков.")
            }
            "sms_contact" -> {
                if (!Perms.has(ctx, Perms.CONTACTS)) {
                    return CommandResult(false, "Нужен доступ к контактам, чтобы найти получателя.", Emotion.SAD, false, Perms.CONTACTS)
                }
                val rest = s["rest"] ?: ""
                val r = ContactResolver.findWithText(ctx, rest)
                    ?: return CommandResult(false, "Не нашёл получателя в «$rest». Скажите, например: «напиши маме привет».", Emotion.SAD, false, null, true)
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(r.first.number)))
                i.putExtra("sms_body", r.second)
                return if (start(ctx, i)) ok("Подготовил сообщение для ${r.first.name}. Проверьте текст и нажмите «Отправить» — сам я ничего не отправляю.", Emotion.HAPPY, true)
                else fail("Не нашёл приложение для сообщений.")
            }

            // ---- MINI ----
            "mini_emotion" -> {
                val all = listOf(Emotion.HAPPY, Emotion.SAD, Emotion.ANGRY, Emotion.SURPRISED, Emotion.SCARED, Emotion.DANCING, Emotion.BORED, Emotion.HUNGRY)
                val e = all[(Math.random() * all.size).toInt().coerceIn(0, all.size - 1)]
                MiniBus.react(e, 3500L)
                return CommandResult(true, "Показываю: " + e.ru + ".", e)
            }
            "mini_mood" -> {
                val b = BatteryMonitor.read(ctx)
                return CommandResult(true, "Сейчас я " + MiniBus.current.ru + ". Заряд телефона ${b.level}%.", null)
            }
            "mini_happy" -> { MiniBus.react(Emotion.HAPPY, 3500L); return CommandResult(true, "Ура! Радуюсь.", Emotion.HAPPY) }
            "mini_sad" -> { MiniBus.react(Emotion.SAD, 3500L); return CommandResult(true, "Грущу…", Emotion.SAD) }
            "mini_angry" -> { MiniBus.react(Emotion.ANGRY, 3500L); return CommandResult(true, "Злюсь! Грр.", Emotion.ANGRY) }
            "mini_surprised" -> { MiniBus.react(Emotion.SURPRISED, 3500L); return CommandResult(true, "Ого!", Emotion.SURPRISED) }
            "mini_scared" -> { MiniBus.react(Emotion.SCARED, 3000L); return CommandResult(true, "Ой-ой-ой!", Emotion.SCARED) }
            "mini_dance" -> { MiniBus.react(Emotion.DANCING, 7000L); return CommandResult(true, "Танцую!", Emotion.DANCING) }
            "mini_wake" -> {
                MiniBus.sleeping = false
                MiniBus.clearReaction()
                MiniBus.react(Emotion.WAKING, 1800L)
                return CommandResult(true, "Проснулся!", Emotion.WAKING)
            }
            "mini_sleep" -> { MiniBus.react(Emotion.SLEEPING, 15000L); return CommandResult(true, "Засыпаю… Позови — проснусь.", Emotion.SLEEPING) }
            "mini_blink" -> { MiniBus.blink(); return CommandResult(true, "Подмигиваю!", Emotion.HAPPY) }
            "mini_look" -> {
                val w = m.input
                val x = if (w.contains("влево") || w.contains("налево")) -1f else if (w.contains("вправо") || w.contains("направо")) 1f else 0f
                val y = if (w.contains("вверх")) -1f else if (w.contains("вниз")) 1f else 0f
                MiniBus.look(x, y)
                return CommandResult(true, "Смотрю.", null)
            }
            "mini_joke" -> return CommandResult(true, Brain.get(ctx).forced("joke").text, Emotion.HAPPY)
            "mini_fact" -> return CommandResult(true, Brain.get(ctx).forced("fact").text, Emotion.SURPRISED)

            // ---- музыка ----
            "music_play" -> {
                val g = musicGuard(ctx)
                if (g != null) return g
                return if (MusicMonitor.hasSession()) musicAction("воспроизведение", MusicMonitor.play()) else openMusicApp(ctx)
            }
            "music_pause" -> {
                val g = musicGuard(ctx)
                if (g != null) return g
                return musicAction("пауза", MusicMonitor.pause())
            }
            "music_next" -> {
                val g = musicGuard(ctx)
                if (g != null) return g
                return musicAction("следующий трек", MusicMonitor.next())
            }
            "music_prev" -> {
                val g = musicGuard(ctx)
                if (g != null) return g
                return musicAction("предыдущий трек", MusicMonitor.prev())
            }
            "music_now" -> {
                val g = musicGuard(ctx)
                if (g != null) return g
                val st2 = MusicMonitor.state
                    ?: return CommandResult(true, "Сейчас ничего не играет.", null)
                val who = if (st2.artist.isEmpty()) st2.title else st2.artist + " — " + st2.title
                info(st2.appName, who)
                return CommandResult(true, (if (st2.playing) "Играет: " else "На паузе: ") + who + " (" + st2.appName + ").", Emotion.HAPPY)
            }

            // ---- ISMAR ----
            "ismar_panel" -> {
                return if (OverlayService.openPanel(ctx)) ok("Открываю панель.", null, true)
                else fail("Островок выключен — сначала включите его на главном экране ISMAR.")
            }
            "ismar_settings" -> return screen(ctx, SettingsActivity::class.java, "настройки ISMAR")
            "ismar_chat" -> return screen(ctx, ChatActivity::class.java, "чат с MINI")
            "ismar_widgets" -> return screen(ctx, WidgetsActivity::class.java, "редактор виджетов")
            "ismar_commands" -> return screen(ctx, CommandsActivity::class.java, "справочник команд")
            "ismar_island_off" -> {
                Prefs.setB(K.ISLAND_ENABLED, false)
                OverlayService.stop(ctx)
                return ok("Островок выключен. Вернуть его можно на главном экране ISMAR.", Emotion.SLEEPING)
            }
            "ismar_island_on" -> {
                if (!Perms.overlay(ctx)) {
                    Perms.openOverlay(ctx)
                    return fail("Для островка нужно разрешение «Поверх других приложений». Открыл экран разрешений.", true)
                }
                Prefs.setB(K.ISLAND_ENABLED, true)
                OverlayService.start(ctx, true)
                return ok("Островок включён.", Emotion.HAPPY)
            }

            // ---- калькулятор ----
            "calc_expr" -> {
                val e = s["expr"] ?: ""
                val v = Calc.eval(Calc.spokenToExpr(e))
                    ?: return CommandResult(false, "Не смог посчитать «$e». Попробуйте, например: «посчитай 15 умножить на 3».", Emotion.SAD, false, null, true)
                val shown = Calc.spokenToExpr(e).replace(" ", "")
                info("Результат", Calc.format(v))
                return ok("$shown = " + Calc.format(v), Emotion.HAPPY)
            }
        }
        return fail("Эту команду я распознал, но выполнять пока не умею.")
    }
}
