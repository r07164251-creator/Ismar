package com.ismar.app.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import com.ismar.app.core.*

class OverlayController(private val context:Context) {
    private val wm=context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var island:IslandView?=null; private var bolt:BoltView?=null; private var panel:PanelView?=null
    private fun params(w:Int,h:Int,gravity:Int):WindowManager.LayoutParams = WindowManager.LayoutParams(w,h, if(android.os.Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply{this.gravity=gravity}
    fun show(){ if(!Perms.overlay(context)) return
        if(island==null){ island=IslandView(context){togglePanel()}; bolt=BoltView(context){togglePanel()} }
        try { if(island!!.parent==null) wm.addView(island,params(context.dp(190),context.dp(52),Gravity.TOP or Gravity.CENTER_HORIZONTAL)) }catch(_:Exception){}
        try { if(Prefs.b(K.BOLT_ENABLED) && bolt!!.parent==null) wm.addView(bolt,params(context.dp(42),context.dp(42),Gravity.TOP or Gravity.RIGHT).apply{y=context.dp(92);x=context.dp(8)}) }catch(_:Exception){}
    }
    fun togglePanel(){ if(panel!=null){hidePanel();return}; val p=PanelView(context,{hidePanel()},{context.startActivity(android.content.Intent(context,com.ismar.app.screens.ChatActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));hidePanel()});panel=p
        try{wm.addView(p,params(WindowManager.LayoutParams.MATCH_PARENT,context.dp(560),Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply{flags=WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_DIM_BEHIND;dimAmount=.35f})}catch(_:Exception){panel=null}
    }
    fun hidePanel(){panel?.let{try{wm.removeView(it)}catch(_:Exception){}};panel=null}
    fun hide(){hidePanel();island?.let{try{wm.removeView(it)}catch(_:Exception){}};bolt?.let{try{wm.removeView(it)}catch(_:Exception){}}}
}
