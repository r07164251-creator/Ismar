package com.ismar.app.screens

import android.os.Bundle
import android.content.Intent
import android.view.Gravity
import android.widget.*
import com.ismar.app.core.*
import com.ismar.app.service.OverlayService
import com.ismar.app.widgets.WidgetCatalog

class OnboardingActivity: IsmarActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(24),dp(24),dp(24),dp(24));setBackgroundColor(Pal.BG)}
 val mini=com.ismar.app.mini.MiniView(this);root.addView(mini,LinearLayout.LayoutParams(dp(190),dp(150)))
 root.addView(label("Знакомься, это MINI",24f,Pal.TEXT,Fonts.bold));root.addView(label("ISMAR добавляет плавающий островок и панель быстрых виджетов. MINI и команды работают локально. Некоторые функции требуют отдельных разрешений Android.",14f,Pal.TEXT2).apply{gravity=Gravity.CENTER;textAlignment=android.view.View.TEXT_ALIGNMENT_CENTER},LinearLayout.LayoutParams(MATCH,WRAP).apply{topMargin=dp(14)})
 addButton(root,"Продолжить"){Prefs.setB(K.TERMS,true);Prefs.setB(K.ONBOARDING_DONE,true);if(Store.widgets().isEmpty())WidgetCatalog.seedDefaults();if(Perms.overlay(this)){Prefs.setB(K.ISLAND_ENABLED,true);val i=Intent(this,OverlayService::class.java);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i)}else Perms.openOverlay(this);startActivity(Intent(this,MainActivity::class.java));finish()}
 setContentView(root)}
}
