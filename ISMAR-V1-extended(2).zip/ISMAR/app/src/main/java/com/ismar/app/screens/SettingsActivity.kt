package com.ismar.app.screens

import android.os.Bundle
import android.content.Intent
import android.widget.*
import com.ismar.app.core.*
import com.ismar.app.service.OverlayService

class SettingsActivity: IsmarActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val root=page("Настройки ISMAR");val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(MATCH,0,1f))
 fun toggle(title:String,key:String){val row=LinearLayout(this).apply{gravity=android.view.Gravity.CENTER_VERTICAL;setPadding(0,dp(12),0,dp(12))};row.addView(label(title,14f,Pal.TEXT),LinearLayout.LayoutParams(0,WRAP,1f));val sw=Switch(this).apply{
            isChecked=Prefs.b(key)
            setOnCheckedChangeListener{_,v->
                if(key==K.ISLAND_ENABLED){
                    if(v && !Perms.overlay(this@SettingsActivity)){
                        isChecked=false
                        Perms.openOverlay(this@SettingsActivity)
                        return@setOnCheckedChangeListener
                    }
                    Prefs.setB(key,v)
                    val service=Intent(this@SettingsActivity,OverlayService::class.java)
                    if(v){if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(service) else startService(service)}
                    else stopService(service)
                }else{
                    Prefs.setB(key,v)
                    if(key==K.BOLT_ENABLED){
                        val service=Intent(this@SettingsActivity,OverlayService::class.java)
                        stopService(service)
                        if(Prefs.b(K.ISLAND_ENABLED)){if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(service) else startService(service)}
                    }
                }
            }
        };row.addView(sw);list.addView(row);list.addView(android.view.View(this).apply{setBackgroundColor(Pal.STROKE)},LinearLayout.LayoutParams(MATCH,dp(1)))}
 toggle("Плавающий островок",K.ISLAND_ENABLED);toggle("Кнопка-молния",K.BOLT_ENABLED);toggle("Анимации",K.ANIM_ISLAND);toggle("Моргание MINI",K.MINI_BLINK);toggle("Реакции MINI",K.ISLAND_EVENTS);toggle("Голосовое управление",K.VOICE_AUTORUN);toggle("Предпочитать офлайн-распознавание",K.VOICE_OFFLINE);toggle("Автоматический облегчённый режим",K.AUTO_LIGHT)
 addButton(list,"Разрешение показа поверх приложений"){Perms.openOverlay(this)};addButton(list,"Доступ к уведомлениям (музыка)"){Perms.openNotifAccess(this)};addButton(list,"Изменение системной яркости"){Perms.openWriteSettings(this)};addButton(list,"Доступ к использованию приложений"){Perms.openUsage(this)};addButton(list,"Проверить статус голоса"){toast(this,com.ismar.app.voice.VoiceController.statusText(this))};addButton(list,"Остановить ISMAR"){stopService(Intent(this,OverlayService::class.java));Prefs.setB(K.ISLAND_ENABLED,false);toast(this,"Островок остановлен")};setContentView(root)}
}
