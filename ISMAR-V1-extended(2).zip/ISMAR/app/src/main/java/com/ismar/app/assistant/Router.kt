package com.ismar.app.assistant

import android.content.Context
import com.ismar.app.commands.CommandEngine
import com.ismar.app.commands.CommandResult
import com.ismar.app.core.Emotion
import com.ismar.app.core.MiniBus

/** Единая точка входа: сначала пробуем выполнить команду, иначе отвечает собеседник MINI. */
object Router {
    class Reply(val text: String, val emotion: Emotion?, val result: CommandResult?, val intentId: String?)

    fun handle(ctx: Context, text: String, cb: (Reply) -> Unit) {
        CommandEngine.run(ctx, text) { r ->
            if (r != null) {
                cb(Reply(r.message, r.emotion, r, null))
            } else {
                val br = Brain.get(ctx).reply(text)
                val e = Emotion.parse(br.emotion)
                MiniBus.react(e, 2600L)
                cb(Reply(br.text, e, null, br.intentId))
            }
        }
    }
}
