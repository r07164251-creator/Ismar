package com.ismar.app.overlay

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import com.ismar.app.core.*
import com.ismar.app.widgets.*

class PanelView(ctx: Context, private val close: () -> Unit, private val onOpenChat: () -> Unit) : LinearLayout(ctx), WidgetEnv {
    private val content=LinearLayout(ctx)
    init {
        orientation=VERTICAL; setPadding(ctx.dp(16),ctx.dp(16),ctx.dp(16),ctx.dp(16))
        background=GradientDrawable().apply { setColor(0xF20D0D10.toInt()); cornerRadius=ctx.dp(28).toFloat(); setStroke(ctx.dp(1),0xFF34343A.toInt()) }
        val head=LinearLayout(ctx).apply { gravity=Gravity.CENTER_VERTICAL }
        val name=ctx.tv("ISMAR",20f,Pal.TEXT,Fonts.bold)
        head.addView(name,LayoutParams(0,WRAP,1f))
        val mini=ctx.tv("MINI  •  панель",11f,Pal.TEXT2)
        head.addView(mini)
        val x=ctx.tv("✕",20f,Pal.TEXT); x.setPadding(ctx.dp(12),0,0,0); x.setOnClickListener{close()};head.addView(x)
        addView(head,LayoutParams(MATCH,ctx.dp(36)))
        val actions=LinearLayout(ctx).apply { gravity=Gravity.CENTER_VERTICAL }
        actions.addView(action("Чат MINI"){openChat()},LayoutParams(0,ctx.dp(38),1f))
        actions.addView(action("Виджеты"){envOpenWidgets()},LayoutParams(0,ctx.dp(38),1f))
        addView(actions,LayoutParams(MATCH,ctx.dp(44)))
        val scroll=ScrollView(ctx); scroll.isFillViewport=true
        content.orientation=VERTICAL; content.setPadding(0,ctx.dp(8),0,0)
        scroll.addView(content); addView(scroll,LayoutParams(MATCH,0,1f))
        render()
    }
    private fun action(s:String, f:()->Unit)=ctxText(s).apply { gravity=Gravity.CENTER; background=rrect(0xFF222228.toInt(),context.dpf(14f)); setOnClickListener{f()} }
    private fun ctxText(s:String)=context.tv(s,12f,Pal.TEXT,Fonts.medium)
    private fun envOpenWidgets(){ context.startActivity(android.content.Intent(context,com.ismar.app.screens.WidgetsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)); close() }
    private fun render(){ content.removeAllViews(); val records=Store.widgets(); if(records.isEmpty()) WidgetCatalog.seedDefaults()
        for(rec in Store.widgets()) { val v=WidgetCatalog.create(context,rec,this); val h= context.dp((rec.h*94).coerceIn(88,280)); content.addView(v,LayoutParams(MATCH,h).apply{bottomMargin=context.dp(9)}) }
    }
    override fun saveRec(rec:WidgetRec){Store.updateWidget(rec)}
    override fun showSheet(title:String,contentView:View){ val box=LinearLayout(context).apply{orientation=VERTICAL;setPadding(context.dp(14),context.dp(12),context.dp(14),context.dp(12));background=rrect(0xFF202026.toInt(),context.dpf(20f))};box.addView(context.tv(title,16f,Pal.TEXT,Fonts.bold));box.addView(contentView); addView(box,0,LayoutParams(MATCH,WRAP)) }
    override fun hideSheet(){ if(childCount>2) removeViewAt(0) }
    override fun afterLaunch(){close()}
    override fun openChat(){onOpenChat()}
}
