package com.ismar.app.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.ismar.app.core.K
import com.ismar.app.core.Perms
import com.ismar.app.core.Prefs

/**
 * Голосовой ввод через штатный Android SpeechRecognizer.
 * Честность: если на устройстве нет офлайн-распознавателя, мы об этом прямо говорим —
 * системный сервис (обычно Google) может отправлять звук на сервер.
 */
class VoiceController(context: Context) {
    enum class Problem { NO_PERMISSION, UNAVAILABLE, NEEDS_INTERNET, NO_SPEECH, BUSY, OTHER }

    interface Callback {
        fun onListening()
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onProblem(kind: Problem, message: String)
    }

    private val ctx: Context = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var cb: Callback? = null
    private var usedOnDevice = false

    var listening: Boolean = false
        private set

    private val timeout = Runnable {
        if (listening) {
            val c = cb
            cancel()
            c?.onProblem(Problem.NO_SPEECH, "Я ничего не услышал. Нажмите на микрофон и скажите команду ещё раз.")
        }
    }

    companion object {
        fun onDeviceAvailable(ctx: Context): Boolean {
            if (Build.VERSION.SDK_INT < 33) return false
            return try {
                SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)
            } catch (e: Exception) {
                false
            }
        }

        fun serviceAvailable(ctx: Context): Boolean {
            return try {
                SpeechRecognizer.isRecognitionAvailable(ctx)
            } catch (e: Exception) {
                false
            }
        }

        /** Человекочитаемый статус для настроек и виджета. */
        fun statusText(ctx: Context): String {
            return when {
                onDeviceAvailable(ctx) ->
                    "Офлайн-распознавание речи на устройстве доступно: интернет не нужен."
                serviceAvailable(ctx) ->
                    "Гарантированного офлайн-распознавателя нет. Используется системный сервис (обычно Google): " +
                        "он работает без интернета, только если скачан офлайн-пакет русского языка, иначе нужен интернет."
                else ->
                    "Сервис распознавания речи не найден. Установите «Google» или другой голосовой ввод. " +
                        "Команды можно вводить текстом."
            }
        }
    }

    fun start(callback: Callback) {
        cancel()
        cb = callback
        if (!Perms.has(ctx, Perms.MIC)) {
            callback.onProblem(Problem.NO_PERMISSION, "Нужно разрешение на микрофон.")
            return
        }
        val preferOffline = Prefs.b(K.VOICE_OFFLINE)
        val onDev = preferOffline && onDeviceAvailable(ctx)
        if (!onDev && !serviceAvailable(ctx)) {
            callback.onProblem(Problem.UNAVAILABLE, statusText(ctx))
            return
        }
        usedOnDevice = onDev
        val r: SpeechRecognizer = try {
            if (onDev && Build.VERSION.SDK_INT >= 33) SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
            else SpeechRecognizer.createSpeechRecognizer(ctx)
        } catch (e: Exception) {
            callback.onProblem(Problem.UNAVAILABLE, "Не удалось запустить распознавание речи.")
            return
        }
        recognizer = r
        r.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.s(K.VOICE_LANG))
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        listening = true
        try {
            r.startListening(i)
        } catch (e: Exception) {
            listening = false
            destroy()
            callback.onProblem(Problem.OTHER, "Не удалось начать запись голоса.")
            return
        }
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, 15_000L)
        callback.onListening()
    }

    fun cancel() {
        handler.removeCallbacks(timeout)
        listening = false
        destroy()
    }

    private fun destroy() {
        val r = recognizer
        recognizer = null
        if (r != null) {
            try {
                r.cancel()
            } catch (e: Exception) {
            }
            try {
                r.destroy()
            } catch (e: Exception) {
            }
        }
    }

    private fun first(b: Bundle?): String {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        return if (list != null && list.isNotEmpty()) list[0] else ""
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = first(partialResults)
            if (t.isNotEmpty()) cb?.onPartial(t)
        }

        override fun onResults(results: Bundle?) {
            val t = first(results)
            val c = cb
            handler.removeCallbacks(timeout)
            listening = false
            destroy()
            if (t.isEmpty()) c?.onProblem(Problem.NO_SPEECH, "Не расслышал. Скажите ещё раз.")
            else c?.onResult(t)
        }

        override fun onError(error: Int) {
            val c = cb
            handler.removeCallbacks(timeout)
            listening = false
            destroy()
            if (c == null) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    c.onProblem(Problem.NO_SPEECH, "Я ничего не расслышал. Попробуйте ещё раз.")
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                    c.onProblem(
                        Problem.NEEDS_INTERNET,
                        "Этому распознавателю сейчас нужен интернет (или офлайн-пакет русского языка: Настройки Google → Голосовой ввод → Офлайн-распознавание). Команду можно ввести текстом."
                    )
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    c.onProblem(Problem.BUSY, "Распознаватель занят, попробуйте через секунду.")
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    c.onProblem(Problem.NO_PERMISSION, "Нужно разрешение на микрофон.")
                12, 13 ->
                    c.onProblem(
                        Problem.NEEDS_INTERNET,
                        "Русский язык не установлен для офлайн-распознавания. Скачайте офлайн-пакет в настройках голосового ввода Google или подключитесь к интернету."
                    )
                else ->
                    c.onProblem(Problem.OTHER, "Ошибка распознавания речи (код $error).")
            }
        }
    }
}
