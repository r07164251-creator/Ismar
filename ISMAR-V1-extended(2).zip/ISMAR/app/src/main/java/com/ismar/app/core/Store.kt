package com.ismar.app.core

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

class WidgetRec(
    var id: Long,
    var type: String,
    var w: Int,
    var h: Int,
    var pos: Int,
    var cfg: JSONObject
) {
    fun int(key: String, def: Int): Int = cfg.optInt(key, def)
    fun bool(key: String, def: Boolean): Boolean = cfg.optBoolean(key, def)
    fun str(key: String, def: String): String = cfg.optString(key, def)
    fun putInt(key: String, v: Int) { cfg.put(key, v) }
    fun putBool(key: String, v: Boolean) { cfg.put(key, v) }
    fun putStr(key: String, v: String) { cfg.put(key, v) }
}

class ChatMsg(val id: Long, val fromUser: Boolean, val body: String, val ts: Long)

/** Локальная база SQLite: виджеты, заметки, история чата. */
object Store {
    private lateinit var helper: Helper

    fun init(ctx: Context) {
        helper = Helper(ctx.applicationContext)
    }

    private class Helper(ctx: Context) : SQLiteOpenHelper(ctx, "ismar.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE widgets(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, w INTEGER NOT NULL, h INTEGER NOT NULL, pos INTEGER NOT NULL, cfg TEXT)")
            db.execSQL("CREATE TABLE notes(widget_id INTEGER PRIMARY KEY, body TEXT, updated INTEGER)")
            db.execSQL("CREATE TABLE chat(id INTEGER PRIMARY KEY AUTOINCREMENT, role INTEGER NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    }

    private fun parse(s: String?): JSONObject {
        return try {
            if (s.isNullOrEmpty()) JSONObject() else JSONObject(s)
        } catch (e: Exception) {
            JSONObject()
        }
    }

    // ---------- виджеты ----------

    fun widgets(): List<WidgetRec> {
        val out = ArrayList<WidgetRec>()
        val c = helper.readableDatabase.rawQuery("SELECT id,type,w,h,pos,cfg FROM widgets ORDER BY pos ASC, id ASC", null)
        try {
            while (c.moveToNext()) {
                out.add(WidgetRec(c.getLong(0), c.getString(1), c.getInt(2), c.getInt(3), c.getInt(4), parse(c.getString(5))))
            }
        } finally {
            c.close()
        }
        return out
    }

    fun insertWidget(rec: WidgetRec): Long {
        val cv = ContentValues()
        cv.put("type", rec.type)
        cv.put("w", rec.w)
        cv.put("h", rec.h)
        cv.put("pos", rec.pos)
        cv.put("cfg", rec.cfg.toString())
        val id = helper.writableDatabase.insert("widgets", null, cv)
        rec.id = id
        return id
    }

    fun updateWidget(rec: WidgetRec) {
        if (rec.id < 0) return
        val cv = ContentValues()
        cv.put("type", rec.type)
        cv.put("w", rec.w)
        cv.put("h", rec.h)
        cv.put("pos", rec.pos)
        cv.put("cfg", rec.cfg.toString())
        helper.writableDatabase.update("widgets", cv, "id=?", arrayOf(rec.id.toString()))
    }

    fun deleteWidget(id: Long) {
        val db = helper.writableDatabase
        db.delete("widgets", "id=?", arrayOf(id.toString()))
        db.delete("notes", "widget_id=?", arrayOf(id.toString()))
    }

    fun saveOrder(ids: List<Long>) {
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            for ((index, id) in ids.withIndex()) {
                val cv = ContentValues()
                cv.put("pos", index)
                db.update("widgets", cv, "id=?", arrayOf(id.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearWidgets() {
        val db = helper.writableDatabase
        db.delete("widgets", null, null)
        db.delete("notes", null, null)
    }

    // ---------- заметки ----------

    fun note(widgetId: Long): String {
        val c = helper.readableDatabase.rawQuery("SELECT body FROM notes WHERE widget_id=?", arrayOf(widgetId.toString()))
        try {
            if (c.moveToFirst()) return c.getString(0) ?: ""
        } finally {
            c.close()
        }
        return ""
    }

    fun saveNote(widgetId: Long, body: String) {
        if (widgetId < 0) return
        val cv = ContentValues()
        cv.put("widget_id", widgetId)
        cv.put("body", body)
        cv.put("updated", System.currentTimeMillis())
        helper.writableDatabase.insertWithOnConflict("notes", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ---------- чат ----------

    fun chat(limit: Int): List<ChatMsg> {
        val out = ArrayList<ChatMsg>()
        val c = helper.readableDatabase.rawQuery(
            "SELECT id,role,body,ts FROM chat ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())
        )
        try {
            while (c.moveToNext()) {
                out.add(ChatMsg(c.getLong(0), c.getInt(1) == 1, c.getString(2) ?: "", c.getLong(3)))
            }
        } finally {
            c.close()
        }
        out.reverse()
        return out
    }

    fun addChat(fromUser: Boolean, body: String) {
        val cv = ContentValues()
        cv.put("role", if (fromUser) 1 else 0)
        cv.put("body", body)
        cv.put("ts", System.currentTimeMillis())
        val db = helper.writableDatabase
        db.insert("chat", null, cv)
        // держим историю компактной
        db.execSQL("DELETE FROM chat WHERE id NOT IN (SELECT id FROM chat ORDER BY id DESC LIMIT 500)")
    }

    fun clearChat() {
        helper.writableDatabase.delete("chat", null, null)
    }
}
