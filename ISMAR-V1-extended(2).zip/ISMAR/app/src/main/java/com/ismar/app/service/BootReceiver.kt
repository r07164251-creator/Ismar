package com.ismar.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.ismar.app.core.*

class BootReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent?){if(intent?.action!=Intent.ACTION_BOOT_COMPLETED && intent?.action!=Intent.ACTION_MY_PACKAGE_REPLACED)return
  if(!Prefs.b(K.ISLAND_ENABLED)||!Perms.overlay(context))return
  val i=Intent(context,OverlayService::class.java)
  try{if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i) else context.startService(i)}catch(_:Exception){}
 }
}
