package com.ismar.app.screens

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import com.ismar.app.core.*
import com.ismar.app.service.OverlayService

class MainActivity: IsmarActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  if(!Prefs.b(K.ONBOARDING_DONE)){startActivity(Intent(this,OnboardingActivity::class.java));finish();return}
  val root=page("ISMAR");val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(0,dp(24),0,dp(24))}
  val mini=com.ismar.app.mini.MiniView(this);hero.addView(mini,LinearLayout.LayoutParams(dp(150),dp(120)))
  hero.addView(label("Твой маленький помощник MINI",16f,Pal.TEXT,Fonts.medium));hero.addView(label("Островок · команды · виджеты · офлайн-чат",12f,Pal.TEXT2))
  root.addView(hero,LinearLayout.LayoutParams(MATCH,0,1f))
  addButton(root,if(Prefs.b(K.ISLAND_ENABLED))"Остановить островок" else "Запустить островок"){toggleIsland()}
  addButton(root,"Открыть чат MINI"){startActivity(Intent(this,ChatActivity::class.java))}
  addButton(root,"Команды MINI"){startActivity(Intent(this,CommandsActivity::class.java))}
  addButton(root,"Настроить виджеты"){startActivity(Intent(this,WidgetsActivity::class.java))}
  addButton(root,"Настройки ISMAR"){startActivity(Intent(this,SettingsActivity::class.java))}
  setContentView(root)
 }
 private fun toggleIsland(){if(Prefs.b(K.ISLAND_ENABLED)){Prefs.setB(K.ISLAND_ENABLED,false);stopService(Intent(this,OverlayService::class.java));recreate()}else{if(!Perms.overlay(this)){Perms.openOverlay(this);return};Prefs.setB(K.ISLAND_ENABLED,true);val i=Intent(this,OverlayService::class.java);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i);recreate()}}
 override fun onResume(){super.onResume();if(Prefs.b(K.ONBOARDING_DONE)&&Prefs.b(K.ISLAND_ENABLED)&&Perms.overlay(this)){val i=Intent(this,OverlayService::class.java);try{if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i)}catch(_:Exception){}}}
}
