package com.ismar.app.assistant

import java.math.BigDecimal
import java.math.MathContext

/** Нормализация текста: регистр, ё, знаки, растянутые буквы, раскладка. Чистый Kotlin — без Android. */
object TextNorm {
    private val repeatRe = Regex("(\\p{L})\\1{2,}")
    private val nonWordRe = Regex("[^\\p{L}\\p{N}\\s]")
    private val spacesRe = Regex("\\s+")

    fun normalize(raw: String): String {
        var s = raw.lowercase().replace('ё', 'е')
        s = repeatRe.replace(s, "\$1")
        s = nonWordRe.replace(s, " ")
        s = spacesRe.replace(s, " ").trim()
        return s
    }

    fun tokens(norm: String): List<String> = if (norm.isEmpty()) emptyList() else norm.split(' ')

    /** Расстояние Левенштейна (строки короткие, поэтому простая реализация). */
    fun lev(a: String, b: String, max: Int): Int {
        if (Math.abs(a.length - b.length) > max) return max + 1
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = Math.min(Math.min(prev[j] + 1, cur[j - 1] + 1), prev[j - 1] + cost)
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > max) return max + 1
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }

    private const val EN_KEYS = "qwertyuiop[]asdfghjkl;'zxcvbnm,./`"
    private const val RU_KEYS = "йцукенгшщзхъфывапролджэячсмитьбю.ё"

    /** «ghbdtn» -> «привет» (текст набран в английской раскладке). */
    fun fixLayout(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val i = EN_KEYS.indexOf(ch)
            sb.append(if (i >= 0) RU_KEYS[i] else ch)
        }
        return sb.toString()
    }

    fun looksLikeWrongLayout(s: String): Boolean {
        var latin = 0
        for (ch in s) {
            if (ch in 'a'..'z' || ch in 'A'..'Z') latin++
            if (ch in 'а'..'я' || ch in 'А'..'Я') return false
        }
        return latin >= 3
    }
}

/** Небольшой калькулятор: + − × ÷ ^ % скобки, десятичные через точку или запятую. */
object Calc {
    private class P(val s: String) {
        var i = 0

        fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        fun expr(): Double {
            var v = term()
            while (true) {
                val c = peek()
                if (c == '+') { i++; v += term() }
                else if (c == '-') { i++; v -= term() }
                else break
            }
            return v
        }

        fun term(): Double {
            var v = power()
            while (true) {
                val c = peek()
                if (c == '*') { i++; v *= power() }
                else if (c == '/') {
                    i++
                    val d = power()
                    if (d == 0.0) throw ArithmeticException("div0")
                    v /= d
                } else break
            }
            return v
        }

        fun power(): Double {
            val b = unary()
            if (peek() == '^') {
                i++
                return Math.pow(b, power())
            }
            return b
        }

        fun unary(): Double {
            val c = peek()
            if (c == '-') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return postfix()
        }

        fun postfix(): Double {
            var v = primary()
            while (peek() == '%') {
                i++
                v /= 100.0
            }
            return v
        }

        fun primary(): Double {
            if (peek() == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("paren")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("num")
            return s.substring(st, i).toDouble()
        }
    }

    fun eval(input: String): Double? {
        val t = input.replace(',', '.').replace('×', '*').replace('÷', '/').replace('−', '-').replace(" ", "")
        if (t.isEmpty()) return null
        return try {
            val p = P(t)
            val v = p.expr()
            if (p.i != t.length) null else if (v.isNaN() || v.isInfinite()) null else v
        } catch (e: Exception) {
            null
        }
    }

    fun format(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "Ошибка"
        if (Math.abs(d - Math.rint(d)) < 1e-10 && Math.abs(d) < 1e15) return Math.rint(d).toLong().toString()
        val s = BigDecimal(d).round(MathContext(12)).stripTrailingZeros().toPlainString()
        return s.replace('.', ',')
    }

    /** Слова -> символы: «два плюс два» не распознаём, а вот «2 плюс 2», «15 умножить на 3» — да. */
    fun spokenToExpr(src: String): String {
        var s = " " + src.lowercase().replace('ё', 'е') + " "
        val pairs = listOf(
            " умножить на " to " * ", " умножь на " to " * ", " помножить на " to " * ",
            " разделить на " to " / ", " поделить на " to " / ", " делить на " to " / ",
            " плюс " to " + ", " минус " to " - ", " в степени " to " ^ ", " в квадрате " to " ^2 ",
            " процентов " to "% ", " процента " to "% ", " процент " to "% ", " будет " to " ", " равно " to " "
        )
        for ((a, b) in pairs) s = s.replace(a, b)
        s = Regex("(?<=\\d)\\s*[xх×]\\s*(?=\\d)").replace(s, "*")
        return s.trim()
    }

    /** Если сообщение — арифметическое выражение, вернёт (выражение, результат). */
    fun fromText(raw: String): Pair<String, Double>? {
        var s = raw.lowercase().replace('ё', 'е')
        for (w in listOf("сколько будет", "сколько", "посчитай", "вычисли", "реши", "calc")) s = s.replace(w, " ")
        s = s.replace("=", " ").replace("?", " ")
        val t = spokenToExpr(s)
        if (t.isEmpty()) return null
        if (!Regex("^[0-9+\\-*/^%().,\\s]+$").matches(t)) return null
        if (!Regex("\\d\\s*[+\\-*/^]\\s*[\\d(]").containsMatchIn(t)) return null
        val v = eval(t) ?: return null
        return Pair(t.replace(" ", ""), v)
    }
}
