package com.ismar.app.mini

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.ismar.app.core.Emotion
import com.ismar.app.core.IslandBus
import com.ismar.app.core.IslandEvent
import com.ismar.app.core.K
import com.ismar.app.core.MiniBus
import com.ismar.app.core.Perms
import com.ismar.app.core.Prefs
import com.ismar.app.media.MusicMonitor
import com.ismar.app.media.MusicState
import com.ismar.app.system.BatteryInfo
import com.ismar.app.system.BatteryMonitor
import com.ismar.app.system.ForegroundWatcher
import com.ismar.app.system.SoundMonitor
import com.ismar.app.system.SysInfo

/**
 * Автоматические реакции MINI. Каждая реакция:
 *  - отключается своим переключателем в настройках;
 *  - ограничена по частоте (персональный интервал + общий интервал «между реакциями»);
 *  - не тратит ресурсы, пока экран выключен.
 */
class ReactionEngine(private val ctx: Context) :
    BatteryMonitor.Listener, SoundMonitor.Callback, ForegroundWatcher.Callback, MusicMonitor.Listener {

    /** Выставляется службой: true, если служба получила тип foreground «microphone» и микрофон доступен из фона. */
    var micAllowed: Boolean = false

    private val handler = Handler(Looper.getMainLooper())
    private var started = false
    private var screenOn = true
    private var lastBattery: BatteryInfo? = null
    private var prevPlugged: Boolean? = null
    private var told5 = false
    private var told1 = false
    private var lastActivity = SystemClock.elapsedRealtime()
    private val last = HashMap<String, Long>()
    private var lastAny = 0L
    private var sound: SoundMonitor? = null
    private var watcher: ForegroundWatcher? = null
    private var musicInit = false

    private val idleTick = object : Runnable {
        override fun run() {
            if (!started || !screenOn) return
            checkIdle()
            handler.postDelayed(this, 30_000L)
        }
    }

    private val clearBored = Runnable { MiniBus.bored = false }

    fun start() {
        if (started) return
        started = true
        lastActivity = SystemClock.elapsedRealtime()
        BatteryMonitor.add(ctx, this)
        MusicMonitor.add(ctx, this)
        applyMonitors()
        handler.postDelayed(idleTick, 30_000L)
    }

    fun stop() {
        if (!started) return
        started = false
        BatteryMonitor.remove(ctx, this)
        MusicMonitor.remove(this)
        sound?.stop()
        sound = null
        watcher?.stop()
        watcher = null
        handler.removeCallbacksAndMessages(null)
        MiniBus.charging = false
        MiniBus.hungry = false
        MiniBus.fading = false
        MiniBus.sleeping = false
        MiniBus.bored = false
    }

    /** Применить изменённые настройки без перезапуска. */
    fun reload() {
        val b = lastBattery
        if (b != null) applyBattery(b, false)
        applyMonitors()
        if (!Prefs.b(K.R_IDLE)) MiniBus.sleeping = false
        if (!Prefs.b(K.R_BORED)) MiniBus.bored = false
    }

    fun onScreen(on: Boolean) {
        screenOn = on
        if (!started) return
        if (on) {
            lastActivity = SystemClock.elapsedRealtime()
            val wasSleeping = MiniBus.sleeping
            MiniBus.sleeping = false
            MiniBus.setPaused(false)
            if (wasSleeping) MiniBus.react(Emotion.WAKING, 1800L)
            applyMonitors()
            handler.removeCallbacks(idleTick)
            handler.postDelayed(idleTick, 30_000L)
        } else {
            MiniBus.setPaused(true)
            handler.removeCallbacks(idleTick)
            sound?.stop()
            sound = null
            watcher?.stop()
            watcher = null
        }
    }

    /** Любое действие пользователя (касание вне островка, нажатие на островок и т.п.). */
    fun noteActivity() {
        lastActivity = SystemClock.elapsedRealtime()
        if (MiniBus.sleeping) {
            MiniBus.sleeping = false
            MiniBus.react(Emotion.WAKING, 1600L)
        }
    }

    private fun applyMonitors() {
        val wantSound = screenOn && started && (Prefs.b(K.R_SCARE) || Prefs.b(K.R_LOUD)) &&
            Perms.has(ctx, Perms.MIC) && micAllowed
        if (wantSound) {
            var m = sound
            if (m == null) {
                m = SoundMonitor(ctx, this)
                sound = m
            }
            m.start()
        } else {
            sound?.stop()
            sound = null
        }

        val wantFg = screenOn && started && (Prefs.b(K.R_BORED) || Prefs.b(K.R_GAME)) && Perms.usage(ctx)
        if (wantFg) {
            var w = watcher
            if (w == null) {
                w = ForegroundWatcher(ctx, this)
                watcher = w
            }
            w.start()
        } else {
            watcher?.stop()
            watcher = null
        }
    }

    // ---------- ограничение частоты ----------

    private fun allowed(key: String, minGapMs: Long, critical: Boolean = false): Boolean {
        val now = SystemClock.elapsedRealtime()
        val l = last[key] ?: 0L
        if (l != 0L && now - l < minGapMs) return false
        if (!critical) {
            val globalGap = Prefs.i(K.REACT_COOLDOWN) * 1000L
            if (lastAny != 0L && now - lastAny < globalGap) return false
            lastAny = now
        }
        last[key] = now
        return true
    }

    // ---------- батарея ----------

    override fun onBattery(info: BatteryInfo) {
        lastBattery = info
        applyBattery(info, true)
    }

    private fun applyBattery(info: BatteryInfo, transitions: Boolean) {
        val chargeOn = Prefs.b(K.R_CHARGING)
        MiniBus.charging = chargeOn && info.plugged

        if (transitions) {
            val pp = prevPlugged
            if (pp != null && pp != info.plugged && chargeOn && allowed("plug", 8000L, true)) {
                if (info.plugged) {
                    IslandBus.post(IslandEvent("charge", "Зарядка подключена", info.level.toString() + "%"))
                    MiniBus.react(Emotion.HAPPY, 1800L)
                } else {
                    IslandBus.post(IslandEvent("charge", "Зарядку отключили", "Мне это не нравится…", 3000L))
                    MiniBus.react(Emotion.ANNOYED, 3500L)
                }
            }
        }
        prevPlugged = info.plugged

        val onBattery = !info.plugged
        val fade = onBattery && info.level <= 1 && Prefs.b(K.R_BAT1)
        val hungry = onBattery && info.level <= 5 && !fade && Prefs.b(K.R_BAT5)
        MiniBus.fading = fade
        MiniBus.hungry = hungry

        if (transitions) {
            if (hungry && !told5) {
                told5 = true
                IslandBus.post(IslandEvent("battery", "Хочу кушать!", "Осталось " + info.level + "%", 3600L))
            }
            if (fade && !told1) {
                told1 = true
                IslandBus.post(IslandEvent("battery", "Засыпаю…", "Заряд " + info.level + "%", 3600L))
            }
        }
        if (info.level > 6 || info.plugged) {
            told5 = false
            told1 = false
        }
    }

    // ---------- звук ----------

    override fun onSpike() {
        if (Prefs.b(K.R_SCARE) && allowed("scare", 20_000L)) MiniBus.react(Emotion.SCARED, 1800L)
    }

    override fun onLoud() {
        if (Prefs.b(K.R_LOUD) && allowed("loud", 60_000L)) MiniBus.react(Emotion.SAD, 4000L)
    }

    // ---------- приложения ----------

    override fun onSwitch(pkg: String, isGame: Boolean) {
        lastActivity = SystemClock.elapsedRealtime()
        handler.removeCallbacks(clearBored)
        MiniBus.bored = false
        if (MiniBus.sleeping) MiniBus.sleeping = false
        if (isGame && Prefs.b(K.R_GAME) && allowed("game", 120_000L)) {
            MiniBus.react(Emotion.HAPPY, 3500L)
            IslandBus.post(IslandEvent("game", "Игра! Ура!", SysInfo.appLabel(ctx, pkg), 3000L))
        }
    }

    override fun onStay(pkg: String, stayedMs: Long) {
        if (!Prefs.b(K.R_BORED)) return
        if (stayedMs >= Prefs.i(K.BORED_MIN) * 60_000L && !MiniBus.bored && allowed("bored", 600_000L)) {
            MiniBus.bored = true
            IslandBus.post(IslandEvent("mini", "Скучно…", "Давно сидим в одном приложении", 3000L))
            handler.removeCallbacks(clearBored)
            handler.postDelayed(clearBored, 120_000L)
        }
    }

    // ---------- музыка ----------

    override fun onMusic(s: MusicState?) {
        // событие трека приходит в onTrackChange
    }

    override fun onTrackChange(s: MusicState) {
        if (!musicInit) {
            musicInit = true
            return
        }
        if (allowed("musicEvt", 3000L, true)) {
            IslandBus.post(IslandEvent("music", s.title, s.artist, 2800L))
        }
        if (Prefs.b(K.R_MUSIC) && allowed("dance", 45_000L)) {
            MiniBus.react(Emotion.DANCING, 6000L)
        }
    }

    // ---------- бездействие ----------

    private fun checkIdle() {
        if (!Prefs.b(K.R_IDLE)) {
            if (MiniBus.sleeping) MiniBus.sleeping = false
            return
        }
        val idle = SystemClock.elapsedRealtime() - lastActivity
        if (idle >= Prefs.i(K.IDLE_MIN) * 60_000L && !MiniBus.sleeping) {
            MiniBus.sleeping = true
        }
    }
}
