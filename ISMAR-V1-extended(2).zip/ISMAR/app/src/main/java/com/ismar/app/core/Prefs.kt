package com.ismar.app.core

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import com.ismar.app.system.BatteryMonitor

/** Ключи настроек. Значения по умолчанию лежат в Prefs.defB / defI / defS. */
object K {
    const val ONBOARDING_DONE = "onboarding_done"
    const val TERMS = "terms_accepted"
    const val WIDGETS_SEEDED = "widgets_seeded"

    const val ISLAND_ENABLED = "island_enabled"
    const val ISLAND_EVENTS = "island_events"
    const val ISLAND_NOTIFS = "island_notifs"
    const val SHOW_MUSIC = "show_music"
    const val SHOW_BRIGHT = "show_bright"
    const val SHOW_QUICK = "show_quick"
    const val SHOW_STATE = "show_state"
    const val HIDE_LANDSCAPE = "hide_landscape"
    const val ISLAND_SCALE = "island_scale"
    const val ISLAND_TOP = "island_top"
    const val AUTO_COLLAPSE = "auto_collapse"

    const val BOLT_ENABLED = "bolt_enabled"
    const val BOLT_HAPTIC = "bolt_haptic"
    const val BOLT_SIDE = "bolt_side"
    const val BOLT_SIZE = "bolt_size"

    const val MINI_COLOR = "mini_color"
    const val MINI_LOOK = "mini_look"
    const val MINI_BLINK = "mini_blink"

    const val PANEL_DIM = "panel_dim"
    const val PANEL_COLS = "panel_cols"
    const val PANEL_SIZE = "panel_size"

    const val VOICE_OFFLINE = "voice_offline"
    const val VOICE_AUTORUN = "voice_autorun"
    const val VOICE_LANG = "voice_lang"

    const val R_CHARGING = "r_charging"
    const val R_BAT5 = "r_bat5"
    const val R_BAT1 = "r_bat1"
    const val R_SCARE = "r_scare"
    const val R_LOUD = "r_loud"
    const val R_BORED = "r_bored"
    const val R_GAME = "r_game"
    const val R_IDLE = "r_idle"
    const val R_MUSIC = "r_music"
    const val REACT_COOLDOWN = "react_cooldown"
    const val IDLE_MIN = "idle_min"
    const val BORED_MIN = "bored_min"

    const val ANIM_ISLAND = "anim_island"
    const val ANIM_SPEED = "anim_speed"

    const val LIGHT_MODE = "light_mode"
    const val AUTO_LIGHT = "auto_light"

    const val SPOTIFY_FIRST = "spotify_first"
    const val USER_NAME = "user_name"
}

object Prefs {
    private lateinit var sp: SharedPreferences

    private val defB: Map<String, Boolean> = mapOf(
        K.ONBOARDING_DONE to false, K.TERMS to false, K.WIDGETS_SEEDED to false,
        K.ISLAND_ENABLED to true, K.ISLAND_EVENTS to true, K.ISLAND_NOTIFS to false,
        K.SHOW_MUSIC to true, K.SHOW_BRIGHT to true, K.SHOW_QUICK to true, K.SHOW_STATE to true,
        K.HIDE_LANDSCAPE to false,
        K.BOLT_ENABLED to true, K.BOLT_HAPTIC to true,
        K.MINI_LOOK to true, K.MINI_BLINK to true,
        K.PANEL_DIM to true,
        K.VOICE_OFFLINE to true, K.VOICE_AUTORUN to true,
        K.R_CHARGING to true, K.R_BAT5 to true, K.R_BAT1 to true,
        K.R_SCARE to false, K.R_LOUD to false,
        K.R_BORED to true, K.R_GAME to true, K.R_IDLE to true, K.R_MUSIC to true,
        K.ANIM_ISLAND to true,
        K.LIGHT_MODE to false, K.AUTO_LIGHT to true,
        K.SPOTIFY_FIRST to true
    )

    private val defI: Map<String, Int> = mapOf(
        K.ISLAND_SCALE to 1, K.ISLAND_TOP to 8, K.AUTO_COLLAPSE to 10,
        K.BOLT_SIDE to 1, K.BOLT_SIZE to 1,
        K.MINI_COLOR to 0,
        K.PANEL_COLS to 0, K.PANEL_SIZE to 1,
        K.REACT_COOLDOWN to 30, K.IDLE_MIN to 3, K.BORED_MIN to 10,
        K.ANIM_SPEED to 1
    )

    private val defS: Map<String, String> = mapOf(
        K.VOICE_LANG to "ru-RU",
        K.USER_NAME to ""
    )

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("ismar_prefs", Context.MODE_PRIVATE)
    }

    fun b(key: String): Boolean = sp.getBoolean(key, defB[key] ?: false)
    fun setB(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }

    fun i(key: String): Int = sp.getInt(key, defI[key] ?: 0)
    fun setI(key: String, v: Int) { sp.edit().putInt(key, v).apply() }

    fun s(key: String): String = sp.getString(key, defS[key] ?: "") ?: ""
    fun setS(key: String, v: String) { sp.edit().putString(key, v).apply() }

    /** Множитель длительности анимаций (меньше = быстрее). */
    fun animScale(): Float = when (i(K.ANIM_SPEED)) {
        0 -> 0.7f
        2 -> 1.6f
        else -> 1f
    }

    private var lightCachedAt = 0L
    private var lightCached = false

    /** Облегчённый режим: вручную или автоматически при низком заряде (без зарядки). */
    fun light(ctx: Context): Boolean {
        if (b(K.LIGHT_MODE)) return true
        if (!b(K.AUTO_LIGHT)) return false
        val now = SystemClock.uptimeMillis()
        if (now - lightCachedAt > 20_000L) {
            lightCachedAt = now
            val bi = BatteryMonitor.read(ctx)
            lightCached = bi.level in 0..15 && !bi.plugged
        }
        return lightCached
    }
}
