package com.ismar.app.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import com.ismar.app.core.K
import com.ismar.app.core.Prefs
import com.ismar.app.system.SysInfo
import java.util.concurrent.CopyOnWriteArrayList

class MusicState(
    val title: String,
    val artist: String,
    val album: String,
    val art: Bitmap?,
    val playing: Boolean,
    val posMs: Long,
    val durMs: Long,
    val speed: Float,
    val pkg: String,
    val appName: String
) {
    private val stamp: Long = SystemClock.elapsedRealtime()

    fun positionNow(): Long {
        if (!playing) return posMs
        val p = posMs + ((SystemClock.elapsedRealtime() - stamp) * speed).toLong()
        return if (durMs > 0L) Math.min(p, durMs) else p
    }

    fun progress(): Float = if (durMs > 0L) (positionNow().toFloat() / durMs.toFloat()).coerceIn(0f, 1f) else 0f

    fun key(): String = pkg + "|" + title + "|" + artist
}

/**
 * Музыка и Spotify через MediaSession.
 * Для чтения активных сессий Android требует включённый «Доступ к уведомлениям» (NotificationListenerService).
 * Тексты песен Spotify через этот интерфейс не отдаёт — они не поддерживаются.
 */
object MusicMonitor {
    const val SPOTIFY = "com.spotify.music"

    interface Listener {
        fun onMusic(s: MusicState?)
        fun onTrackChange(s: MusicState) {}
    }

    private val listeners = CopyOnWriteArrayList<Listener>()
    private var appCtx: Context? = null
    private var msm: MediaSessionManager? = null
    private var controller: MediaController? = null
    private var started = false
    private var registeredListener = false
    private var lastKey = ""

    @Volatile
    var state: MusicState? = null
        private set

    @Volatile
    var access: Boolean = false
        private set

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        onSessions(list)
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            refresh()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            refresh()
        }

        override fun onSessionDestroyed() {
            reselect()
        }
    }

    fun add(ctx: Context, l: Listener) {
        appCtx = ctx.applicationContext
        if (!listeners.contains(l)) listeners.add(l)
        if (!started) {
            started = true
            msm = ctx.applicationContext.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        }
        connect()
        l.onMusic(state)
    }

    fun remove(l: Listener) {
        listeners.remove(l)
        if (listeners.isEmpty() && started) {
            val m = msm
            if (m != null && registeredListener) {
                try {
                    m.removeOnActiveSessionsChangedListener(sessionsListener)
                } catch (e: Exception) {
                }
            }
            registeredListener = false
            detach()
            started = false
        }
    }

    private val keepAlive = object : Listener {
        override fun onMusic(s: MusicState?) {}
    }

    /** Подключает монитор постоянно (нужно командам «пауза», «следующий трек» и т.п. из любого места). */
    fun ensure(ctx: Context) {
        add(ctx, keepAlive)
    }

    /** Пробует (пере)подключиться; вызывается при старте и когда включили доступ к уведомлениям. */
    fun connect() {
        val c = appCtx ?: return
        val m = msm ?: return
        val comp = ComponentName(c, IsmarNotificationListener::class.java)
        try {
            if (!registeredListener) {
                m.addOnActiveSessionsChangedListener(sessionsListener, comp)
                registeredListener = true
            }
            access = true
            onSessions(m.getActiveSessions(comp))
        } catch (e: SecurityException) {
            access = false
            registeredListener = false
            detach()
            publish(null)
        } catch (e: Exception) {
            access = false
        }
    }

    private fun reselect() {
        val c = appCtx ?: return
        val m = msm ?: return
        try {
            onSessions(m.getActiveSessions(ComponentName(c, IsmarNotificationListener::class.java)))
        } catch (e: Exception) {
        }
    }

    private fun detach() {
        try {
            controller?.unregisterCallback(controllerCallback)
        } catch (e: Exception) {
        }
        controller = null
    }

    private fun onSessions(list: List<MediaController>?) {
        val best = pick(list)
        val cur = controller
        if (best == null) {
            detach()
            publish(null)
            return
        }
        if (cur == null || cur.sessionToken != best.sessionToken) {
            detach()
            controller = best
            try {
                best.registerCallback(controllerCallback)
            } catch (e: Exception) {
            }
        }
        refresh()
    }

    private fun isPlaying(c: MediaController): Boolean = c.playbackState?.state == PlaybackState.STATE_PLAYING

    private fun pick(list: List<MediaController>?): MediaController? {
        if (list == null) return null
        val me = appCtx?.packageName
        val cands = list.filter { it.packageName != me }
        if (cands.isEmpty()) return null
        val spotifyFirst = Prefs.b(K.SPOTIFY_FIRST)
        val playingList = cands.filter { isPlaying(it) }
        if (spotifyFirst) {
            val sp = playingList.firstOrNull { it.packageName == SPOTIFY }
            if (sp != null) return sp
        }
        if (playingList.isNotEmpty()) return playingList[0]
        if (spotifyFirst) {
            val sp = cands.firstOrNull { it.packageName == SPOTIFY && it.metadata != null }
            if (sp != null) return sp
        }
        return cands.firstOrNull { it.metadata != null } ?: cands[0]
    }

    private fun refresh() {
        val c = controller
        val ctx = appCtx
        if (c == null || ctx == null) {
            publish(null)
            return
        }
        val md = c.metadata
        val ps = c.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val playing = ps?.state == PlaybackState.STATE_PLAYING
        var pos = ps?.position ?: 0L
        if (pos < 0L) pos = 0L
        val speed = if (ps != null && ps.playbackSpeed > 0f) ps.playbackSpeed else 1f
        if (title.isEmpty() && artist.isEmpty() && !playing) {
            publish(null)
            return
        }
        val s = MusicState(
            title.ifEmpty { "Без названия" }, artist, album, art, playing, pos, dur, speed,
            c.packageName, SysInfo.appLabel(ctx, c.packageName)
        )
        publish(s)
    }

    private fun publish(s: MusicState?) {
        state = s
        for (l in listeners) l.onMusic(s)
        if (s != null) {
            val k = s.key()
            if (k != lastKey) {
                lastKey = k
                if (s.playing) for (l in listeners) l.onTrackChange(s)
            }
        } else {
            lastKey = ""
        }
    }

    // ---------- управление ----------

    fun hasSession(): Boolean = controller != null

    fun playPause(): Boolean {
        val c = controller ?: return false
        return try {
            if (isPlaying(c)) c.transportControls.pause() else c.transportControls.play()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun play(): Boolean {
        val c = controller ?: return false
        return try {
            c.transportControls.play()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun pause(): Boolean {
        val c = controller ?: return false
        return try {
            c.transportControls.pause()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun next(): Boolean {
        val c = controller ?: return false
        return try {
            c.transportControls.skipToNext()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun prev(): Boolean {
        val c = controller ?: return false
        return try {
            c.transportControls.skipToPrevious()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun seekTo(ms: Long): Boolean {
        val c = controller ?: return false
        return try {
            c.transportControls.seekTo(ms)
            true
        } catch (e: Exception) {
            false
        }
    }
}
