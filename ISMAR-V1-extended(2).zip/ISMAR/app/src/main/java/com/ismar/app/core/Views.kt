package com.ismar.app.core

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.ScrollView
import java.util.Calendar

/** Квадратная картинка со скруглёнными углами (обложки, иконки). */
fun Context.roundedImage(radiusDp: Int): ImageView {
    val iv = ImageView(this)
    iv.scaleType = ImageView.ScaleType.CENTER_CROP
    iv.background = rrect(0xFF26262C.toInt(), dpf(radiusDp.toFloat()))
    iv.clipToOutline = true
    iv.outlineProvider = ViewOutlineProvider.BACKGROUND
    return iv
}

fun fmtTime(ms: Long): String {
    val total = (ms / 1000L).toInt().coerceAtLeast(0)
    val m = total / 60
    val s = total % 60
    return m.toString() + ":" + (if (s < 10) "0" else "") + s
}

/** Кольцевой индикатор (батарея). */
class RingView(ctx: Context) : View(ctx) {
    var progress: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var color: Int = Pal.GREEN
        set(v) {
            field = v
            invalidate()
        }
    var label: String = ""
        set(v) {
            field = v
            invalidate()
        }
    var sub: String = ""
        set(v) {
            field = v
            invalidate()
        }
    var strokeDp: Float = 7f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Math.min(w, h)
        val sw = dpf(strokeDp)
        r.set((w - d) / 2f + sw / 2f, (h - d) / 2f + sw / 2f, (w + d) / 2f - sw / 2f, (h + d) / 2f - sw / 2f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFF26262C.toInt()
        c.drawArc(r, 0f, 360f, false, p)
        p.color = color
        if (progress > 0.005f) c.drawArc(r, -90f, 360f * progress, false, p)
        p.style = Paint.Style.FILL
        p.color = Pal.TEXT
        p.textAlign = Paint.Align.CENTER
        p.typeface = Fonts.medium
        p.textSize = d * (if (sub.isEmpty()) 0.27f else 0.25f)
        val cy = h / 2f + (if (sub.isEmpty()) p.textSize * 0.35f else p.textSize * 0.1f)
        c.drawText(label, w / 2f, cy, p)
        if (sub.isNotEmpty()) {
            p.color = Pal.TEXT2
            p.typeface = Fonts.regular
            p.textSize = d * 0.12f
            c.drawText(sub, w / 2f, cy + d * 0.17f, p)
        }
    }
}

/** Аналоговые часы. */
class AnalogClockView(ctx: Context) : View(ctx) {
    var accent: Int = Pal.ORANGE
    var seconds: Boolean = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val rad = Math.min(w, h) / 2f - dpf(2f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dpf(1.5f)
        p.color = 0xFF3A3A42.toInt()
        c.drawCircle(cx, cy, rad, p)
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0 - 90.0)
            val isMain = i % 3 == 0
            val r1 = rad - dpf(if (isMain) 9f else 5f)
            p.strokeWidth = dpf(if (isMain) 2.2f else 1.2f)
            p.color = if (isMain) Pal.TEXT else Pal.TEXT3
            c.drawLine(
                cx + (Math.cos(a) * r1).toFloat(), cy + (Math.sin(a) * r1).toFloat(),
                cx + (Math.cos(a) * (rad - dpf(2f))).toFloat(), cy + (Math.sin(a) * (rad - dpf(2f))).toFloat(), p
            )
        }
        val cal = Calendar.getInstance()
        val hh = cal.get(Calendar.HOUR) + cal.get(Calendar.MINUTE) / 60.0
        val mm = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60.0
        hand(c, cx, cy, hh * 30.0, rad * 0.5f, dpf(4f), Pal.TEXT)
        hand(c, cx, cy, mm * 6.0, rad * 0.75f, dpf(2.6f), Pal.TEXT)
        if (seconds) hand(c, cx, cy, cal.get(Calendar.SECOND) * 6.0, rad * 0.85f, dpf(1.4f), accent)
        p.style = Paint.Style.FILL
        p.color = accent
        c.drawCircle(cx, cy, dpf(3.5f), p)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Double, len: Float, w: Float, col: Int) {
        val a = Math.toRadians(deg - 90.0)
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.color = col
        c.drawLine(cx, cy, cx + (Math.cos(a) * len).toFloat(), cy + (Math.sin(a) * len).toFloat(), p)
    }
}

/** Три-четыре «эквалайзерные» полоски для свёрнутого островка (анимируются только пока играет музыка). */
class EqView(ctx: Context) : View(ctx) {
    var active: Boolean = false
        set(v) {
            field = v
            kick()
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hs = FloatArray(4) { 0.4f }
    private var t = 0f
    private val tick = Runnable { step() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        kick()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(tick)
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        kick()
    }

    private fun kick() {
        removeCallbacks(tick)
        if (isAttachedToWindow && active && isShown) postDelayed(tick, 70L)
    }

    private fun step() {
        t += 0.45f
        for (i in hs.indices) hs[i] = 0.3f + 0.7f * Math.abs(Math.sin((t + i * 1.3f).toDouble())).toFloat()
        invalidate()
        kick()
    }

    override fun onDraw(c: Canvas) {
        val bw = dpf(2.6f)
        val gap = dpf(2.4f)
        val total = hs.size * bw + (hs.size - 1) * gap
        var x = (width - total) / 2f
        p.color = Pal.ORANGE
        p.style = Paint.Style.FILL
        val maxH = height * 0.8f
        for (i in hs.indices) {
            val hh = if (active) maxH * hs[i] else dpf(3f)
            val top = (height - hh) / 2f
            c.drawRoundRect(x, top, x + bw, top + hh, bw / 2f, bw / 2f, p)
            x += bw + gap
        }
    }
}

/** ScrollView с ограничением по высоте (для шторок). */
class MaxHeightScroll(ctx: Context, private val maxPx: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxPx, MeasureSpec.AT_MOST))
    }
}

/** Контейнер, переносящий дочерние элементы на новые строки (для «чипов»). */
class FlowLayout(ctx: Context) : ViewGroup(ctx) {
    var gapPx: Int = 0

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec)
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            c.measure(MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            val cw = c.measuredWidth
            if (x > 0 && x + cw > maxW) {
                x = 0
                y += rowH + gapPx
                rowH = 0
            }
            x += cw + gapPx
            rowH = Math.max(rowH, c.measuredHeight)
        }
        setMeasuredDimension(maxW, y + rowH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            val cw = c.measuredWidth
            if (x > 0 && x + cw > maxW) {
                x = 0
                y += rowH + gapPx
                rowH = 0
            }
            c.layout(x, y, x + cw, y + c.measuredHeight)
            x += cw + gapPx
            rowH = Math.max(rowH, c.measuredHeight)
        }
    }
}
