package com.ismar.app.widgets

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.*
import com.ismar.app.assistant.Router
import com.ismar.app.assistant.Calc
import com.ismar.app.core.*
import com.ismar.app.voice.VoiceController

private fun IsmarWidget.base(title:String):LinearLayout { val l=root(); header(title, when(rec.type){"notes"->Ic.NOTE;"calc"->Ic.CALC;"voice"->Ic.MIC;"commands"->Ic.CMD;else->Ic.CHAT})?.let{l.addView(it,lin(MATCH,WRAP,0f,0,0,0,dp(8)))};return l }
private fun IsmarWidget.actionButton(text:String,click:()->Unit):TextView= context.tv(text,12f,Pal.TEXT,Fonts.medium).apply{gravity=Gravity.CENTER;setPadding(dp(10),dp(9),dp(10),dp(9));background=rrect(0xFF292930.toInt(),dpf(12f));setOnClickListener{click()}}

class NotesWidget(ctx:Context,rec:WidgetRec,env:WidgetEnv):IsmarWidget(ctx,rec,env){
 override fun build(){removeAllViews();val l=base("Заметки");val input=EditText(context).apply{setTextColor(Pal.TEXT);setHintTextColor(Pal.TEXT3);hint="Запишите что-нибудь…";textSize=13f;minLines=2;maxLines=5;setText(Store.note(rec.id));background=rrect(0xFF19191F.toInt(),dpf(12f));setPadding(dp(10),dp(8),dp(10),dp(8));addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){Store.saveNote(rec.id,s?.toString()?:"")};override fun afterTextChanged(s:android.text.Editable?){} })};l.addView(input,lin(MATCH,0,1f));addView(l,MATCH,MATCH)}
}
class CalcWidget(ctx:Context,rec:WidgetRec,env:WidgetEnv):IsmarWidget(ctx,rec,env){
 override fun build(){removeAllViews();val l=base("Калькулятор");val input=EditText(context).apply{hint="Например: 12 × 4 + 8";setTextColor(Pal.TEXT);setHintTextColor(Pal.TEXT3);setSingleLine(true);background=rrect(0xFF19191F.toInt(),dpf(12f));setPadding(dp(10),dp(8),dp(10),dp(8))};val result=context.tv("Результат появится здесь",15f,Pal.TEXT,Fonts.medium);l.addView(input,lin(MATCH,dp(42)));l.addView(actionButton("Вычислить"){val v=Calc.eval(input.text.toString());result.text=if(v==null)"Не удалось разобрать выражение" else v.toString()}.apply{layoutParams=lin(MATCH,dp(38),0f,0,dp(6))});l.addView(result,lin(MATCH,WRAP,0f,0,dp(8)));addView(l,MATCH,MATCH)}
}
class AssistantWidget(ctx:Context,rec:WidgetRec,env:WidgetEnv):IsmarWidget(ctx,rec,env){
 override fun build(){removeAllViews();val l=base("MINI Assistant");val preview=context.tv("Привет! Я MINI. Напиши мне что-нибудь.",12f,Pal.TEXT2);l.addView(preview,lin(MATCH,0,1f));l.addView(actionButton("Открыть чат MINI"){env.openChat()},lin(MATCH,dp(40)));addView(l,MATCH,MATCH)}
}
class CommandsWidget(ctx:Context,rec:WidgetRec,env:WidgetEnv):IsmarWidget(ctx,rec,env){
 override fun build(){removeAllViews();val l=base("Команды MINI");val input=EditText(context).apply{hint="Например: открой YouTube";setTextColor(Pal.TEXT);setHintTextColor(Pal.TEXT3);setSingleLine(true);background=rrect(0xFF19191F.toInt(),dpf(12f));setPadding(dp(10),dp(8),dp(10),dp(8))};val out=context.tv("Команда готова",11f,Pal.TEXT2);l.addView(input,lin(MATCH,dp(42)));l.addView(actionButton("Выполнить"){val s=input.text.toString().trim();if(s.isNotEmpty())Router.handle(context,s){out.text=it.text}},lin(MATCH,dp(38),0f,0,dp(6)));l.addView(out,lin(MATCH,WRAP,0f,0,dp(6)));addView(l,MATCH,MATCH)}
}
class VoiceWidget(ctx:Context,rec:WidgetRec,env:WidgetEnv):IsmarWidget(ctx,rec,env){
 private var voice:VoiceController?=null
 override fun build(){removeAllViews();val l=base("Голосовое управление");val status=context.tv("Нажмите, чтобы сказать команду",12f,Pal.TEXT2);val btn=actionButton("●  Говорить"){if(!Perms.has(context,Perms.MIC)){Perms.request(context,Perms.MIC){granted->status.text=if(granted)"Разрешение получено. Нажмите ещё раз." else "Нет доступа к микрофону."}}else{if(voice==null)voice=VoiceController(context);voice?.start(object:VoiceController.Callback{override fun onListening(){status.text="Слушаю…"};override fun onPartial(text:String){status.text=text};override fun onResult(text:String){status.text="Вы сказали: $text";Router.handle(context,text){status.text=it.text}};override fun onProblem(kind:VoiceController.Problem,message:String){status.text=message}})}};l.addView(status,lin(MATCH,0,1f));l.addView(btn,lin(MATCH,dp(40)));addView(l,MATCH,MATCH)}
 override fun onHide(){voice?.cancel();voice=null}
}
