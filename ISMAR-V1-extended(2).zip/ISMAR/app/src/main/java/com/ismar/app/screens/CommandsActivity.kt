package com.ismar.app.screens

import android.os.Bundle
import android.widget.*
import com.ismar.app.commands.CommandEngine
import com.ismar.app.core.*

class CommandsActivity: IsmarActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val root=page("Команды MINI");root.addView(label("В базе: ${CommandEngine.commandCount()} команд · ${CommandEngine.variantCount()} вариантов фраз",12f,Pal.TEXT2));val input=EditText(this).apply{hint="Введите команду";setTextColor(Pal.TEXT);setHintTextColor(Pal.TEXT3);setBackground(rrect(0xFF1B1B20.toInt(),dpf(14f)));setPadding(dp(12),dp(10),dp(12),dp(10))};root.addView(input,LinearLayout.LayoutParams(MATCH,dp(48)));val out=label("Результат выполнения появится здесь",13f,Pal.TEXT2);addButton(root,"Выполнить команду"){CommandEngine.run(this,input.text.toString()){out.text=it?.message?:"Не распознана команда. Попробуйте другую формулировку."}};root.addView(out);addButton(root,"Открыть чат MINI"){startActivity(android.content.Intent(this,ChatActivity::class.java))};setContentView(root)}
}
