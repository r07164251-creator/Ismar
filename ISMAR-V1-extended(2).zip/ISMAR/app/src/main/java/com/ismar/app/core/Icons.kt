package com.ismar.app.core

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

enum class Ic {
    BOLT, BATTERY, SUN, NOTE, CALC, CLOCK, MUSIC, MIC, APPS, STAR, CHAT, CMD, SLIDERS,
    PLAY, PAUSE, NEXT, PREV, WIFI, BLUETOOTH, VOLUME, TORCH, PLUS, MINUS, CLOSE, GEAR,
    PENCIL, DRAG, SEND, CHECK, CHEVRON_DOWN, CHEVRON_UP, SEARCH, PHONE, BACK, BELL
}

/** Монолинейные иконки, нарисованные Canvas на сетке 24x24. */
object IconPainter {
    private val path = Path()
    private val rect = RectF()

    private fun poly(c: Canvas, p: Paint, vararg xy: Float) {
        path.reset()
        path.moveTo(xy[0], xy[1])
        var i = 2
        while (i < xy.size) {
            path.lineTo(xy[i], xy[i + 1])
            i += 2
        }
        c.drawPath(path, p)
    }

    private fun rr(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, p)
    }

    fun draw(c: Canvas, ic: Ic, cx: Float, cy: Float, size: Float, p: Paint) {
        val s = size / 24f
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        c.scale(s, s)
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.style = Paint.Style.STROKE
        when (ic) {
            Ic.BOLT -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(13f, 2f)
                path.lineTo(4.5f, 13.5f)
                path.lineTo(11f, 13.5f)
                path.lineTo(10f, 22f)
                path.lineTo(19.5f, 10.5f)
                path.lineTo(13f, 10.5f)
                path.close()
                c.drawPath(path, p)
            }
            Ic.BATTERY -> {
                rr(c, p, 2f, 7f, 19f, 17f, 2.8f)
                p.style = Paint.Style.FILL
                rr(c, p, 20.5f, 10f, 22.5f, 14f, 1f)
            }
            Ic.SUN -> {
                c.drawCircle(12f, 12f, 4.2f, p)
                for (k in 0 until 8) {
                    val a = Math.toRadians(k * 45.0)
                    val x1 = 12f + (7.2 * Math.cos(a)).toFloat()
                    val y1 = 12f + (7.2 * Math.sin(a)).toFloat()
                    val x2 = 12f + (9.6 * Math.cos(a)).toFloat()
                    val y2 = 12f + (9.6 * Math.sin(a)).toFloat()
                    c.drawLine(x1, y1, x2, y2, p)
                }
            }
            Ic.NOTE -> {
                rr(c, p, 5f, 3f, 19f, 21f, 2.8f)
                c.drawLine(8.5f, 9f, 15.5f, 9f, p)
                c.drawLine(8.5f, 13f, 15.5f, 13f, p)
                c.drawLine(8.5f, 17f, 12.5f, 17f, p)
            }
            Ic.CALC -> {
                rr(c, p, 5f, 2.5f, 19f, 21.5f, 2.8f)
                rr(c, p, 8f, 5.5f, 16f, 9.5f, 1f)
                p.style = Paint.Style.FILL
                for (row in 0 until 2) for (col in 0 until 3) {
                    c.drawCircle(9f + col * 3f, 13.5f + row * 4f, 1.1f, p)
                }
            }
            Ic.CLOCK -> {
                c.drawCircle(12f, 12f, 9f, p)
                poly(c, p, 12f, 7f, 12f, 12f, 15.2f, 14f)
            }
            Ic.MUSIC -> {
                poly(c, p, 9f, 18f, 9f, 5.5f, 20f, 3.5f, 20f, 16f)
                c.drawCircle(6.2f, 18f, 2.8f, p)
                c.drawCircle(17.2f, 16f, 2.8f, p)
            }
            Ic.MIC -> {
                rr(c, p, 9f, 2f, 15f, 13f, 3f)
                path.reset()
                path.moveTo(5f, 11f)
                rect.set(5f, 4f, 19f, 18f)
                path.arcTo(rect, 180f, -180f)
                c.drawPath(path, p)
                c.drawLine(12f, 18f, 12f, 22f, p)
                c.drawLine(8.5f, 22f, 15.5f, 22f, p)
            }
            Ic.APPS -> {
                rr(c, p, 3.5f, 3.5f, 10f, 10f, 2f)
                rr(c, p, 14f, 3.5f, 20.5f, 10f, 2f)
                rr(c, p, 3.5f, 14f, 10f, 20.5f, 2f)
                rr(c, p, 14f, 14f, 20.5f, 20.5f, 2f)
            }
            Ic.STAR -> {
                p.style = Paint.Style.FILL
                path.reset()
                for (i in 0 until 10) {
                    val a = -Math.PI / 2 + i * Math.PI / 5
                    val r = if (i % 2 == 0) 10.0 else 4.3
                    val x = 12f + (r * Math.cos(a)).toFloat()
                    val y = 12.8f + (r * Math.sin(a)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                c.drawPath(path, p)
            }
            Ic.CHAT -> {
                rr(c, p, 3f, 4f, 21f, 17f, 3.5f)
                poly(c, p, 9f, 17f, 9f, 21f, 13.5f, 17f)
            }
            Ic.CMD -> {
                rr(c, p, 2.5f, 4f, 21.5f, 20f, 3.5f)
                poly(c, p, 6.5f, 9f, 10.5f, 12f, 6.5f, 15f)
                c.drawLine(12.5f, 15.5f, 17.5f, 15.5f, p)
            }
            Ic.SLIDERS -> {
                c.drawLine(4f, 6f, 20f, 6f, p)
                c.drawLine(4f, 12f, 20f, 12f, p)
                c.drawLine(4f, 18f, 20f, 18f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(9f, 6f, 2.6f, p)
                c.drawCircle(15f, 12f, 2.6f, p)
                c.drawCircle(8f, 18f, 2.6f, p)
            }
            Ic.PLAY -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(7f, 4.5f)
                path.lineTo(19f, 12f)
                path.lineTo(7f, 19.5f)
                path.close()
                c.drawPath(path, p)
            }
            Ic.PAUSE -> {
                p.style = Paint.Style.FILL
                rr(c, p, 6.5f, 4.5f, 10.5f, 19.5f, 1.5f)
                rr(c, p, 13.5f, 4.5f, 17.5f, 19.5f, 1.5f)
            }
            Ic.NEXT -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(5f, 5f)
                path.lineTo(15.5f, 12f)
                path.lineTo(5f, 19f)
                path.close()
                c.drawPath(path, p)
                rr(c, p, 17f, 5f, 19.8f, 19f, 1.2f)
            }
            Ic.PREV -> {
                p.style = Paint.Style.FILL
                path.reset()
                path.moveTo(19f, 5f)
                path.lineTo(8.5f, 12f)
                path.lineTo(19f, 19f)
                path.close()
                c.drawPath(path, p)
                rr(c, p, 4.2f, 5f, 7f, 19f, 1.2f)
            }
            Ic.WIFI -> {
                for (r in floatArrayOf(4.5f, 8.5f, 12.5f)) {
                    rect.set(12f - r, 18.5f - r, 12f + r, 18.5f + r)
                    c.drawArc(rect, 225f, 90f, false, p)
                }
                p.style = Paint.Style.FILL
                c.drawCircle(12f, 18.5f, 1.4f, p)
            }
            Ic.BLUETOOTH -> {
                poly(c, p, 6.5f, 6.5f, 17.5f, 17.5f, 12f, 23f, 12f, 1f, 17.5f, 6.5f, 6.5f, 17.5f)
            }
            Ic.VOLUME -> {
                path.reset()
                path.moveTo(4f, 9f)
                path.lineTo(8f, 9f)
                path.lineTo(13f, 5f)
                path.lineTo(13f, 19f)
                path.lineTo(8f, 15f)
                path.lineTo(4f, 15f)
                path.close()
                c.drawPath(path, p)
                rect.set(8f, 7f, 18f, 17f)
                c.drawArc(rect, -45f, 90f, false, p)
                rect.set(4f, 3f, 22f, 21f)
                c.drawArc(rect, -45f, 90f, false, p)
            }
            Ic.TORCH -> {
                path.reset()
                path.moveTo(7f, 2f)
                path.lineTo(17f, 2f)
                path.lineTo(14.5f, 8f)
                path.lineTo(9.5f, 8f)
                path.close()
                c.drawPath(path, p)
                poly(c, p, 9.5f, 8f, 9.5f, 22f, 14.5f, 22f, 14.5f, 8f)
                p.style = Paint.Style.FILL
                c.drawCircle(12f, 13.5f, 1.2f, p)
            }
            Ic.PLUS -> {
                c.drawLine(12f, 5f, 12f, 19f, p)
                c.drawLine(5f, 12f, 19f, 12f, p)
            }
            Ic.MINUS -> c.drawLine(5f, 12f, 19f, 12f, p)
            Ic.CLOSE -> {
                c.drawLine(6f, 6f, 18f, 18f, p)
                c.drawLine(18f, 6f, 6f, 18f, p)
            }
            Ic.GEAR -> {
                c.drawCircle(12f, 12f, 3.2f, p)
                c.drawCircle(12f, 12f, 7f, p)
                for (k in 0 until 8) {
                    val a = Math.toRadians(k * 45.0)
                    c.drawLine(
                        12f + (7.0 * Math.cos(a)).toFloat(), 12f + (7.0 * Math.sin(a)).toFloat(),
                        12f + (10.3 * Math.cos(a)).toFloat(), 12f + (10.3 * Math.sin(a)).toFloat(), p
                    )
                }
            }
            Ic.PENCIL -> {
                path.reset()
                path.moveTo(4f, 20f)
                path.lineTo(5.5f, 14.5f)
                path.lineTo(15.5f, 4.5f)
                path.lineTo(19.5f, 8.5f)
                path.lineTo(9.5f, 18.5f)
                path.close()
                c.drawPath(path, p)
                c.drawLine(13.5f, 6.5f, 17.5f, 10.5f, p)
            }
            Ic.DRAG -> {
                p.style = Paint.Style.FILL
                for (row in 0 until 3) for (col in 0 until 2) {
                    c.drawCircle(9f + col * 6f, 6f + row * 6f, 1.6f, p)
                }
            }
            Ic.SEND -> {
                path.reset()
                path.moveTo(21f, 3f)
                path.lineTo(3f, 11f)
                path.lineTo(11f, 13f)
                path.lineTo(13f, 21f)
                path.close()
                c.drawPath(path, p)
                c.drawLine(11f, 13f, 21f, 3f, p)
            }
            Ic.CHECK -> poly(c, p, 5f, 12.5f, 10f, 17.5f, 19f, 7f)
            Ic.CHEVRON_DOWN -> poly(c, p, 6f, 9f, 12f, 15f, 18f, 9f)
            Ic.CHEVRON_UP -> poly(c, p, 6f, 15f, 12f, 9f, 18f, 15f)
            Ic.SEARCH -> {
                c.drawCircle(11f, 11f, 6.5f, p)
                c.drawLine(16f, 16f, 21f, 21f, p)
            }
            Ic.PHONE -> {
                rr(c, p, 7f, 2f, 17f, 22f, 3f)
                c.drawLine(10.5f, 18.5f, 13.5f, 18.5f, p)
            }
            Ic.BACK -> poly(c, p, 14.5f, 5.5f, 8f, 12f, 14.5f, 18.5f)
            Ic.BELL -> {
                path.reset()
                rect.set(6f, 4f, 18f, 16f)
                path.arcTo(rect, 180f, 180f)
                path.lineTo(18f, 15f)
                path.lineTo(20f, 18f)
                path.lineTo(4f, 18f)
                path.lineTo(6f, 15f)
                path.close()
                c.drawPath(path, p)
                c.drawLine(10.5f, 21f, 13.5f, 21f, p)
            }
        }
        c.restore()
    }
}

class IconView(ctx: Context, var icon: Ic = Ic.BOLT, var tint: Int = Pal.TEXT) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(ic: Ic, color: Int = tint) {
        icon = ic
        tint = color
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        p.color = tint
        val s = Math.min(width, height).toFloat()
        IconPainter.draw(c, icon, width / 2f, height / 2f, s, p)
    }
}
