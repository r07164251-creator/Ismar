package com.ismar.app

import com.ismar.app.assistant.Calc
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CalcTest {
    @Test fun arithmeticAndPrecedence() { assertEquals(56.0, Calc.eval("12 × 4 + 8")!!, 0.000001) }
    @Test fun parentheses() { assertEquals(20.0, Calc.eval("(2+3)*4")!!, 0.000001) }
    @Test fun divisionByZeroIsRejected() { assertNull(Calc.eval("10/0")) }
    @Test fun malformedInputIsRejected() { assertNull(Calc.eval("hello")) }
}
