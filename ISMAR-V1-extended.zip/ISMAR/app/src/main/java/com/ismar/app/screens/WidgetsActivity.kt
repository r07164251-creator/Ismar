package com.ismar.app.screens

import android.app.AlertDialog
import android.content.ClipData
import android.os.Bundle
import android.view.DragEvent
import android.view.View
import android.widget.*
import com.ismar.app.core.*
import com.ismar.app.widgets.WidgetCatalog
import com.ismar.app.widgets.WidgetRec

/** Локальный редактор: добавление, удаление, drag-and-drop, порядок, размер и параметры. */
class WidgetsActivity : IsmarActivity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = page("Редактор виджетов")
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addButton(root, "Вернуть стандартный набор") {
            Store.clearWidgets()
            WidgetCatalog.seedDefaults()
            render()
        }
        setContentView(root)
        render()
    }

    private fun render() {
        list.removeAllViews()
        val records = Store.widgets()
        if (records.isEmpty()) {
            list.addView(label("Пока нет виджетов. Добавьте первый ниже.", 13f, Pal.TEXT2))
        }
        for ((index, rec) in records.withIndex()) {
            val type = WidgetCatalog.type(rec.type) ?: continue
            val row = LinearLayout(this).apply {
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(9), dp(8), dp(9))
                background = rrect(0xFF17171D.toInt(), dpf(14f))
                setOnLongClickListener {
                    startDragAndDrop(ClipData.newPlainText("widget", rec.id.toString()),
                        View.DragShadowBuilder(this), rec.id, 0)
                }
                setOnDragListener { _, event ->
                    if (event.action == DragEvent.ACTION_DROP) {
                        val from = event.localState as? Long
                        if (from != null && from != rec.id) moveBefore(from, rec.id)
                    }
                    true
                }
            }
            val name = label("${type.title}\n${rec.w} × ${rec.h}  ·  удерживайте для перетаскивания", 13f, Pal.TEXT)
            row.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(smallButton("⚙") { configure(rec) })
            row.addView(smallButton("×") { Store.deleteWidget(rec.id); render() })
            list.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(7) })
        }
        list.addView(label("Добавить виджет", 18f, Pal.TEXT, Fonts.bold).apply {
            setPadding(0, dp(18), 0, dp(8))
        })
        for (type in WidgetCatalog.all) {
            list.addView(button("＋  ${type.title}") {
                val rec = WidgetCatalog.newRec(type, Store.widgets().size)
                Store.insertWidget(rec)
                render()
            }, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(6) })
        }
    }

    private fun smallButton(text: String, click: () -> Unit): TextView =
        button(text, click).apply { textSize = 13f; minWidth = dp(38); setPadding(dp(8), 0, dp(8), 0) }

    private fun moveBefore(fromId: Long, toId: Long) {
        val ids = Store.widgets().map { it.id }.toMutableList()
        val from = ids.indexOf(fromId)
        val to = ids.indexOf(toId)
        if (from < 0 || to < 0) return
        val moving = ids.removeAt(from)
        ids.add(to.coerceAtMost(ids.size), moving)
        Store.saveOrder(ids)
        render()
    }

    private fun configure(rec: WidgetRec) {
        val type = WidgetCatalog.type(rec.type) ?: return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(4))
        }
        val sizeOptions = type.sizes.map { "${it[0]} × ${it[1]}" }
        val sizeLabel = label("Размер", 13f, Pal.TEXT)
        box.addView(sizeLabel)
        val sizeSpinner = Spinner(this)
        sizeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sizeOptions)
        val currentSize = type.sizes.indexOfFirst { it[0] == rec.w && it[1] == rec.h }.coerceAtLeast(0)
        sizeSpinner.setSelection(currentSize)
        box.addView(sizeSpinner, LinearLayout.LayoutParams(MATCH, dp(46)))

        for (opt in (WidgetCatalog.common + type.options)) {
            box.addView(label(opt.title, 13f, Pal.TEXT).apply { setPadding(0, dp(10), 0, dp(4)) })
            if (opt.choices != null) {
                val spinner = Spinner(this)
                spinner.tag = opt.key
                spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opt.choices)
                spinner.setSelection(rec.int(opt.key, opt.def).coerceIn(0, opt.choices.lastIndex))
                box.addView(spinner, LinearLayout.LayoutParams(MATCH, dp(44)))
            } else {
                val sw = Switch(this).apply {
                    tag = opt.key
                    isChecked = rec.bool(opt.key, opt.def == 1)
                }
                box.addView(sw)
            }
        }

        AlertDialog.Builder(this)
            .setTitle("${type.title} · настройки")
            .setView(box)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                val chosen = sizeSpinner.selectedItemPosition.coerceIn(0, type.sizes.lastIndex)
                rec.w = type.sizes[chosen][0]
                rec.h = type.sizes[chosen][1]
                for (i in 0 until box.childCount) {
                    when (val child = box.getChildAt(i)) {
                        is Spinner -> if (child !== sizeSpinner) rec.putInt(child.tag as String, child.selectedItemPosition)
                        is Switch -> rec.putBool(child.tag as String, child.isChecked)
                    }
                }
                Store.updateWidget(rec)
                render()
            }.show()
    }
}
