package com.ismar.app.screens

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import com.ismar.app.assistant.Router
import com.ismar.app.core.*

class ChatActivity: IsmarActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val root=page("Чат с MINI");val scroll=ScrollView(this);val messages=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(messages);root.addView(scroll,LinearLayout.LayoutParams(MATCH,0,1f));fun draw(){messages.removeAllViews();for(m in Store.chat(100)){val t=label((if(m.fromUser)"Вы: " else "MINI: ")+m.body,13f,if(m.fromUser)Pal.TEXT else Pal.TEXT2);t.setPadding(dp(10),dp(9),dp(10),dp(9));t.background=rrect(if(m.fromUser)0xFF25252C.toInt() else 0xFF17171D.toInt(),dpf(14f));messages.addView(t,LinearLayout.LayoutParams(MATCH,WRAP).apply{bottomMargin=dp(7)})};scroll.post{scroll.fullScroll(ScrollView.FOCUS_DOWN)}}
 draw();val row=LinearLayout(this);val input=EditText(this).apply{hint="Сообщение MINI…";setTextColor(Pal.TEXT);setHintTextColor(Pal.TEXT3);singleLine=true;setBackground(rrect(0xFF1C1C22.toInt(),dpf(14f)));setPadding(dp(10),dp(8),dp(10),dp(8))};row.addView(input,LinearLayout.LayoutParams(0,dp(48),1f));val send=button("➤"){val s=input.text.toString().trim();if(s.isNotEmpty()){Store.addChat(true,s);input.setText("");Router.handle(this,s){Store.addChat(false,it.text);draw()};draw()}};row.addView(send,LinearLayout.LayoutParams(dp(58),dp(48)).apply{leftMargin=dp(8)});root.addView(row);setContentView(root)}
}
