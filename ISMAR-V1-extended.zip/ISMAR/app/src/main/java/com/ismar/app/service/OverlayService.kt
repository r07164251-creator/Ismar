package com.ismar.app.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.content.BroadcastReceiver
import android.content.IntentFilter
import com.ismar.app.mini.ReactionEngine
import com.ismar.app.overlay.OverlayController
import com.ismar.app.core.*

class OverlayService:Service(){
    private var controller:OverlayController?=null
    private var reactions:ReactionEngine?=null
    private val screenReceiver=object:BroadcastReceiver(){override fun onReceive(context:android.content.Context?,intent:Intent?){when(intent?.action){Intent.ACTION_SCREEN_OFF->reactions?.onScreen(false);Intent.ACTION_SCREEN_ON->reactions?.onScreen(true)}}}
    override fun onCreate(){super.onCreate();startForeground(NOTIF_ID,notification());controller=OverlayController(this);controller?.show();reactions=ReactionEngine(this).also{it.start()};registerReceiver(screenReceiver,IntentFilter().apply{addAction(Intent.ACTION_SCREEN_ON);addAction(Intent.ACTION_SCREEN_OFF)})}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { if(intent?.action==ACTION_STOP){controller?.hide();stopSelf();return START_NOT_STICKY};controller?.show();return START_STICKY }
    override fun onDestroy(){try{unregisterReceiver(screenReceiver)}catch(_:Exception){};reactions?.stop();reactions=null;controller?.hide();controller=null;super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
    private fun notification():Notification{
        if(Build.VERSION.SDK_INT>=26){val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager;nm.createNotificationChannel(NotificationChannel(CHANNEL,"ISMAR",NotificationManager.IMPORTANCE_LOW))}
        val pi=PendingIntent.getActivity(this,0,Intent(this,com.ismar.app.screens.MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or if(Build.VERSION.SDK_INT>=23)PendingIntent.FLAG_IMMUTABLE else 0)
        return if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL).setSmallIcon(com.ismar.app.R.drawable.ic_stat_bolt).setContentTitle("ISMAR работает").setContentText("Плавающий островок активен").setContentIntent(pi).setOngoing(true).build() else Notification.Builder(this).setSmallIcon(com.ismar.app.R.drawable.ic_stat_bolt).setContentTitle("ISMAR работает").setContentText("Плавающий островок активен").setContentIntent(pi).build()
    }
    companion object{const val ACTION_STOP="com.ismar.app.STOP_OVERLAY";private const val CHANNEL="ismar_overlay";private const val NOTIF_ID=702}
}
